# Provenance reconciliation

This release was assembled from the two archives supplied in the conversation:

- `PythonProject3.zip` SHA-256: `58de4db5c5cca771f4d85e40fe3f7d9f19d951926f54998a57b8fe464fef2225`
- `PythonProject8.zip` SHA-256: `d73b78614834242589ac3cb77cc210d824ad28b71e2e1403f58f8d369404e620`

The supplied `results/reanalysis/source_evidence/source_provenance.json` records an earlier `PythonProject8.zip` SHA-256 of `bc442dbe0143e22543ed93fa0e44934617e387d5beab65deb3248a55f45d5a49`. That value does **not** match the currently uploaded `PythonProject8.zip` (`d73b78614834242589ac3cb77cc210d824ad28b71e2e1403f58f8d369404e620`). The provenance file is preserved unchanged; this discrepancy is disclosed rather than silently rewritten.

The same provenance file refers to a manuscript file `Manuscript-1112.docx` with SHA-256 `e00c639120f1d1fadf45ddab1604d922adcac6ba98662963bafc2f5cfaf76f7c`. That DOCX was not present in either supplied ZIP archive, so this package cannot independently verify that manuscript file or its exact version.

The main experiment plan and run records contain source and graph-instance hashes. The selected CPRNPS source SHA-256 is `4703a36a491df9e51194aa9317610000f36bd4a8d53b52d21925cc512ba3c02e`; the six-city run manifest records the script SHA-256 and the graph SHA-256 values. The included audit script checks these internal identities.

The package does not claim that every historical experiment in the 812 MB extracted source archive is part of the manuscript. It includes the experiment suite identified by the supplied reanalysis provenance, the six-city mechanism audit, and selected development diagnostics. Other experimental kits in the source archive (including alternate comparison suites and unrelated benchmark material) are intentionally excluded from this paper-focused release.


## Internal scope-note inconsistency

The included `main_algorithm/DELIVERY_SCOPE.json` and `main_algorithm/VERIFICATION_RESULTS_CN.md` state that the full nine-graph, five-seed, 60-second V21 study was not executed in that delivery. This appears inconsistent with the separately included `main_algorithm/results/v21_formal/` archive: its protocol identifies the stage as `exploratory_three_city_v21_formal`, its plan records the V21 source hash, and the independent reanalysis completed checks on 108 physical run folders. These scope-note files have been preserved unchanged. The authors should reconcile whether those notes describe an earlier delivery snapshot or a different experiment package before making the repository public; this release does not silently rewrite the original notes.
