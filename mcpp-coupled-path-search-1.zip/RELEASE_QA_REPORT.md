# Release QA report

The release package was assembled locally from the two supplied ZIP archives. It has **not** been pushed to GitHub or made public.

## Checks completed

- Main V21 package integrity checker: PASS, 753 delivered files matched the package's SHA-256 manifest.
- Reanalysis script: completed successfully against the assembled repository.
- Main experiment run folders: 108 `result.json` records audited; the generated checkpoint audit contains 108 entries and all are marked `passed: true`.
- Selected primary comparison subset: 99 physical run records, 2,012 checkpoint candidates, and 131,861 Euler-walk steps in the recomputed summary.
- Six-city mechanism audit: 122,880 pair-audit rows; 270 saved route witnesses; the recomputation script validated the pair definitions, centre denominators, and route witnesses.
- Development diagnostics included: 90 five-seed large-graph ablation run records and 9 separate one-seed large-graph diagnostic run records.
- The full archived experiment also contains an auxiliary Modified Mixed comparator: 9 physical runs, 9/9 graph-level wins, and a 2.03662% descriptive macro mean cost reduction. It is retained in the raw tables but is not named in the manuscript abstract's stated 99-run comparison scope; the authors should reconcile this before final submission.
- Figure regeneration: Fig. 3–Fig. 6 generated from the archived reanalysis tables; Fig. 1–Fig. 2 preserved from supplied assets.
- No single file exceeds 100 MiB. Largest file is `mechanism_audit/results/20261117_100618_122852/pair_audit.csv` (about 27.58 MiB).

## Important qualifications

1. The 99-run main comparison is a selected subset of the full protocol. The full archive has 180 method/seed labels and 108 physical executions; 9 Modified Mixed physical executions are retained separately.
2. The three-city results are marked exploratory, not frozen confirmatory evidence. Seeds are nested within graph instances and the inference unit is the graph/instance.
3. The six-city experiment is a bounded, sampled-neighborhood audit. It is not proof that every possible single-path reversal was exhausted.
4. The supplied provenance JSON records a different SHA-256 for the earlier PythonProject8 archive and refers to a manuscript DOCX not included in the supplied ZIP files. The included delivery-scope notes also say the V21 60-second study was not run, while the selected formal-results folder contains 108 run folders that passed the reanalysis. See `PROVENANCE_RECONCILIATION.md`.
5. The license scheme is separated: original source code is MIT; authors' original non-code research materials are CC BY 4.0; OSM-derived graph databases and extracted OSM content remain ODbL 1.0. Mixed artifacts are subject to both notices for their respective components. See `LICENSE_SCOPE.md`, `LICENSE-CC-BY-4.0.md`, and `OSM_DATA_LICENSE.md`.
6. The current package has not been checked by running the optimization jobs again on the author's Windows machine. The reanalysis script validates archived records and does not rerun the optimizer.

## License update

The authors subsequently confirmed that their original non-OSM experimental outputs (results, logs, route records, and figures) may be released under CC BY 4.0. The repository notices were updated accordingly. This does not extend CC BY 4.0 to OSM-derived database content or third-party material. The rebuilt upload ZIP contains 9,095 files; the refreshed SHA-256 manifest verifies 9,092 payload files (excluding the manifest and inventory files), and the ZIP integrity test passes. The package remains local and has not been published to GitHub.
