from pathlib import Path
import pandas as pd, numpy as np, json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image
R=Path(__file__).resolve().parents[1];O=R/'deliverables/package/figures';E=R/'deliverables/package/evidence'
plt.rcParams.update({'font.family':'Liberation Sans','font.size':9,'axes.titlesize':10,'axes.labelsize':9,'legend.fontsize':8,'axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white'})
colors={'beijing':'#256999','shanghai':'#ce7930','chongqing':'#47866b'}
for i in [1,2]:
 im=Image.open(R/f'work/original_figures/Fig{i}.png').convert('RGB');dpi=300 if i==1 else 600
 if im.width>7.5*dpi:im=im.resize((int(7.5*dpi),round(im.height*7.5*dpi/im.width)),Image.Resampling.LANCZOS)
 im.save(O/f'Fig{i}.tif',compression='tiff_lzw',dpi=(dpi,dpi));im.save(O/f'Fig{i}.png')
def save(fig,n):
 fig.savefig(O/f'Fig{n}.png',dpi=300,bbox_inches='tight',pad_inches=.08)
 im=Image.open(O/f'Fig{n}.png').convert('RGB');im.save(O/f'Fig{n}.tif',compression='tiff_lzw',dpi=(300,300));plt.close(fig)
d=pd.read_csv(E/'primary_runs_recomputed.csv');c=d[d.method=='cprnps'];s=pd.read_csv(E/'primary_graph_summary.csv');s=s[s.method=='cprnps']
f,ax=plt.subplots(1,2,figsize=(7.2,3.15),layout='constrained')
for city,col in colors.items():
 z=s[s.city==city].sort_values('nodes'); ax[0].errorbar(z.nodes,z.first_median,yerr=[z.first_median-z.first_min,z.first_max-z.first_median],fmt='o',color=col,capsize=3,label=city.title())
 z=c[c.city==city].groupby('nodes').joint_evaluations.agg(['mean','min','max']);ax[1].errorbar(z.index,z['mean'],yerr=[z['mean']-z['min'],z['max']-z['mean']],fmt='o',color=col,capsize=3)
for a in ax:a.set_xlabel('Actual vertices');a.set_yscale('log');a.grid(axis='y',alpha=.18)
ax[0].set_ylabel('First eligible checkpoint (s)');ax[1].set_ylabel('Joint repair attempts per run');ax[0].set_title('A  Feasible route availability',loc='left');ax[1].set_title('B  Work under a 60 s allowance',loc='left');ax[0].legend(frameon=False);save(f,3)
red=pd.read_csv(E/'relative_reductions.csv');order=[(ct,t) for ct in colors for t in [100,300,1000]];red=red.set_index(['city','target']).loc[order]
f,ax=plt.subplots(1,2,figsize=(7.2,3.4),layout='constrained',gridspec_kw={'width_ratios':[1.08,1]})
y=np.arange(9);ax[0].barh(y-.17,red.frederickson_1979,height=.32,label='Frederickson port',color='#93acc1');ax[0].barh(y+.17,red.grasp_mcpp_2002,height=.32,label='GRASP port',color='#286b91');ax[0].set_yticks(y,[f'{ct.title()} {t}' for ct,t in order]);ax[0].invert_yaxis();ax[0].set_xlabel('Cost reduction at 60 s (%)');ax[0].axvline(0,color='.4',lw=.7);ax[0].legend(frameon=False);ax[0].set_title('A  All nine extracts',loc='left')
for city,col in colors.items():
 z=d[(d.city==city)&(d.target==1000)];vals=[]
 for t in [10,30,60]:
  means=z.groupby('method')[f'cost_{t}'].mean();assert z[z.method!='frederickson_1979'][f'cost_{t}'].notna().all(); vals.append(100*(means['grasp_mcpp_2002']-means['cprnps'])/means['grasp_mcpp_2002'])
 ax[1].plot([10,30,60],vals,'o-',color=col,label=city.title())
ax[1].set_xlabel('Eligible method time (s)');ax[1].set_ylabel('Reduction relative to GRASP (%)');ax[1].set_xticks([10,30,60]);ax[1].set_title('B  Target 1000 extracts',loc='left');ax[1].legend(frameon=False);ax[1].grid(alpha=.18);save(f,4)
f,ax=plt.subplots(figsize=(7.2,3.1),layout='constrained');cols=['phase_joint_seconds','phase_chain_seconds','phase_parity_seconds','phase_descent_seconds'];m=c.groupby('target')[cols].mean();m['Other / unallocated']=60-m.sum(axis=1);left=np.zeros(3)
for key,label,col in zip(m.columns,['Joint paths','Single paths','Parity','Single edges','Other / unallocated'],['#286b91','#90b9c5','#b8c99d','#ce9c57','#d9dde1']):
 vals=m[key].to_numpy();ax.barh(range(3),vals,left=left,label=label,color=col,height=.55)
 for i,(v,st) in enumerate(zip(vals,left)):
  if v>=2.5:ax.text(st+v/2,i,f'{v:.1f}',ha='center',va='center',color='white' if label=='Joint paths' else '#222',fontsize=9)
 left+=vals
ax.set_yticks(range(3),['Target 100','Target 300','Target 1000']);ax.invert_yaxis();ax.set_xlim(0,60);ax.set_xlabel('Mean seconds per run within nominal allowance');ax.legend(loc='upper center',bbox_to_anchor=(.5,-.2),ncol=3,frameon=False);save(f,5)
new=pd.read_csv(R/'source/mixed_postman_pycharm/results/20261117_100618_122852/city_summary.csv');ct=pd.read_csv(R/'source/mixed_postman_pycharm/results/20261117_100618_122852/centres.csv');cities=sorted(new.city.unique());f,ax=plt.subplots(1,2,figsize=(7.2,3.25),layout='constrained')
x=np.arange(6)
for off,stage,col,label in [(-.18,'initial','#286b91','Initial'),(.18,'after_single_descent','#ce7930','After single descent')]:
 z=new[new.stage==stage].set_index('city').loc[cities];ax[0].bar(x+off,z.strict_pair_rate_pct,width=.34,color=col,label=label)
ax[0].set_xticks(x,[c.title() for c in cities],rotation=40,ha='right');ax[0].set_ylabel('Strict pair-specific improvements (%)');ax[0].legend(frameon=False);ax[0].set_title('A  Frequency in capped pair pools',loc='left')
z=new[new.stage=='after_single_descent'].set_index('city').loc[cities];ax[1].bar(x,z.stalled_centres_with_pairs,color='#d9dde1',label='Stalled centres');ax[1].bar(x,z.escaped_stalled_centres,color='#47866b',label='Escaped by a pair');ax[1].set_xticks(x,[c.title() for c in cities],rotation=40,ha='right');ax[1].set_yticks(range(6));ax[1].set_ylabel('Number of centres (five per city)');ax[1].legend(frameon=False);ax[1].set_title('B  Escape from sampled-pool stagnation',loc='left');save(f,6)
print('Figures created',[(p.name,p.stat().st_size) for p in O.glob('*.tif')])
