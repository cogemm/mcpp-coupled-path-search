# Analysis scripts

## `recompute_audit.py`

Recomputes the supplied archive audit from the files in this repository. It checks:

- source and graph-instance SHA-256 identities against the archived run tasks;
- every archived checkpoint candidate and its feasibility/cost audit;
- every archived Euler walk against the audited service and extra-traversal counts;
- the six-city run-script and graph hashes;
- pair-audit definitions, centre-level denominators, and saved route witnesses;
- the selected five-seed large-graph ablation summaries.

Run from the repository root:

```bash
python analysis/recompute_audit.py
```

Outputs are written to `results/reanalysis/`. The script does not run the optimizer.

## `make_figures.py`

Preserves supplied Fig. 1 and Fig. 2 and regenerates Fig. 3–Fig. 6 from the reanalysis tables and six-city summaries. Run after `recompute_audit.py`:

```bash
python analysis/make_figures.py
```

The original scripts supplied in the archive are retained as `*_original.py` for provenance. The active scripts only adjust repository paths and output locations to this release layout.
