from pathlib import Path
import json, hashlib, csv, collections, numpy as np, pandas as pd
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
ROOT=Path(__file__).resolve().parents[1]
KIT=ROOT/'source/V21_Coupled_Path_MCPP_Kit/V21_Coupled_Path_MCPP_Kit'
FORMAL=KIT/'results/v21_formal/experiment'
NEW=ROOT/'source/mixed_postman_pycharm/results/20261117_100618_122852'
OUT=ROOT/'deliverables/package/evidence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def old_graph(name):
 p=KIT/'osm_data/instances'/f'{name}.json';g=read(p)
 dr=[(a['tail'],a['head'],int(a['cost']),a['source_id']) for a in g['directed']]
 un=[(a['u'],a['v'],int(a['cost']),a['source_id']) for a in g['undirected']]
 tr=dr+[(u,v,c,k) for a in un for u,v,c,k in [a,(a[1],a[0],a[2],a[3])]]
 tr += [(a['tail'],a['head'],int(a['cost']),a['source_id']) for a in g['optional_travel']]
 return p,g,dr,un,tr
GC={}
def audit_candidate(p,name,expected):
 if name not in GC:GC[name]=old_graph(name)
 gp,g,dr,un,tr=GC[name]
 with np.load(p,allow_pickle=False) as z:
  x=z['orientation']; f=z['extra_counts'];assert len(x)==len(un) and len(f)==len(tr)
  assert np.isin(x,[0,1]).all() and (f>=0).all() and (np.rint(f)==f).all()
  serv=dr+[(a if b else (a[1],a[0],a[2],a[3])) for a,b in zip(un,x)]
  cnt=collections.Counter((*a,True) for a in serv)
  for a,q in zip(tr,f):
   if q:cnt[(*a,False)]+=int(q)
  bal=collections.Counter();total=0; adj=collections.defaultdict(set)
  for (u,v,c,k,s),q in cnt.items():bal[u]+=q;bal[v]-=q;total+=q*c;adj[u].add(v);adj[v].add(u)
  assert all(v==0 for v in bal.values()) and total==int(z['total_cost'])==int(expected)
  assert sum(int(q)*a[2] for q,a in zip(f,tr))==int(z['scaled_extra_cost'])
  seen=set();todo=[next(iter(adj))]
  while todo:
   u=todo.pop()
   if u not in seen:seen.add(u);todo.extend(adj[u]-seen)
  assert len(seen)==len(adj)
 return cnt
rows=[]; audits=[]; ncan=0;nsteps=0
for f in sorted(FORMAL.glob('runs/*/result.json')):
 r=read(f); t=read(f.with_name('task.json'));cp=read(f.with_name('checkpoint.json'));name=r['instance']
 assert r['task_digest']==hashlib.sha256(json.dumps(t,sort_keys=True).encode()).hexdigest()
 assert r['source_sha256']==t['source_sha256']==sha(KIT/'V21_Coupled_RNPS_MCPP.py')
 assert sha(KIT/'osm_data/instances'/f'{name}.json')==r['instance_sha256']==t['instance_sha256']
 prev=-1;best=float('inf')
 for e in cp['events']:
  assert prev<=e['elapsed_seconds']<=60 and e['best_cost']<=best
  p=f.parent/e['candidate'];assert sha(p)==e['candidate_sha256']
  cnt=audit_candidate(p,name,e['best_cost']);prev=e['elapsed_seconds'];best=e['best_cost']
 assert best==r['cost'] and cp['events'][-1]==cp['event']
 actual=collections.Counter();start=None;last=None;steps=0
 with f.with_name('euler_tour.csv').open(encoding='utf-8-sig') as fh:
  for i,w in enumerate(csv.DictReader(fh)):
   assert int(w['step'])==i and (last is None or last==w['tail']);start=start or w['tail'];last=w['head']
   actual[(w['tail'],w['head'],int(float(w['cost'])),w['source_id'],w['service']=='True')]+=1;steps+=1
 assert start==last and actual==cnt
 r['first_s']=cp['events'][0]['elapsed_seconds'];r['events']=len(cp['events']);r['euler_steps']=steps
 for tt in [1,5,10,30,60]:r[f'cost_{tt}']=min((e['best_cost'] for e in cp['events'] if e['elapsed_seconds']<=tt),default=np.nan)
 r['city']=name.split('_')[1];r['target']=int(name.split('_')[2][1:]);rows.append(r)
 audits.append({'execution_id':r['execution_id'],'method':r['method'],'instance':name,'seed':r['seed'],'candidates':len(cp['events']),'steps':steps,'passed':True})
d=pd.DataFrame(rows); primary=d[d.method.isin(['cprnps','frederickson_1979','grasp_mcpp_2002'])].copy()
primary.to_csv(OUT/'primary_runs_recomputed.csv',index=False)
s=primary.groupby(['city','target','instance','method'],sort=False).agg(mean_cm=('cost','mean'),sd_cm=('cost','std'),n=('cost','count'),nodes=('nodes','first'),links=('required_links','first'),first_median=('first_s','median'),first_min=('first_s','min'),first_max=('first_s','max')).reset_index();s.to_csv(OUT/'primary_graph_summary.csv',index=False)
piv=s.pivot(index=['city','target'],columns='method',values='mean_cm');red=(piv[['frederickson_1979','grasp_mcpp_2002']].sub(piv.cprnps,axis=0)/piv[['frederickson_1979','grasp_mcpp_2002']]*100);red.to_csv(OUT/'relative_reductions.csv')
metric={'primary_runs':len(primary),'candidates':int(primary.events.sum()),'euler_steps':int(primary.euler_steps.sum()),'macro_reductions':red.mean().to_dict(),'largest_reductions':red.loc[(slice(None),1000),:].to_dict(),'largest_mean_grasp':red.loc[(slice(None),1000),'grasp_mcpp_2002'].mean()}
metric['runtime']=primary.groupby('method').agg(wall_mean=('solver_wall_seconds','mean'),first_median=('first_s','median'),first_max=('first_s','max'),startup=('import_startup_seconds','mean'),post=('post_audit_and_export_seconds','mean'),capped=('watchdog_terminated','sum')).to_dict('index')
cpr=primary[primary.method=='cprnps'];metric['first_graph_range']=s[s.method=='cprnps'].first_median.agg(['min','max']).to_dict()
metric['counters']=cpr.filter(regex='joint|phase_.*seconds').fillna(0).sum().to_dict();metric['phase_means']=cpr.groupby('target').mean(numeric_only=True).filter(regex='joint|phase_.*seconds').to_dict('index')
metric['max_eligible_s']=float(primary.incumbent_seconds.max());metric['max_watchdog_s']=float(primary.watchdog_latency_seconds.max())
# Re-solve logged joint orientations with an independent LP network-flow solver.
def flow_cost(dr,un,tr,x):
 nodes=sorted({a[0] for a in tr}|{a[1] for a in tr});idx={v:i for i,v in enumerate(nodes)};m=len(tr); rr=[];cc=[];vv=[]
 for j,(u,v,c,k) in enumerate(tr):rr.extend([idx[u],idx[v]]);cc.extend([j,j]);vv.extend([1,-1])
 A=coo_matrix((vv,(rr,cc)),shape=(len(nodes),m)).tocsr();b=np.zeros(len(nodes))
 for u,v,c,k in dr+[(a if bit else (a[1],a[0],a[2],a[3])) for a,bit in zip(un,x)]:b[idx[u]]-=1;b[idx[v]]+=1
 res=linprog([a[2] for a in tr],A_eq=A,b_eq=b,bounds=(0,None),method='highs');assert res.success and np.max(abs(res.x-np.rint(res.x)))<1e-5
 return sum(a[2] for a in dr+un)+round(res.fun)
joint=[]
for f in FORMAL.glob('runs/*/joint_moves.jsonl'):
 t=read(f.with_name('task.json'));_,g,dr,un,tr=GC[t['instance']]
 for line in f.read_text().splitlines():
  e=json.loads(line);x=np.array(e['center_orientation']);costs=[flow_cost(dr,un,tr,x)]
  for inds in [e['paths'][0]['edges'],e['paths'][1]['edges'],e['paths'][0]['edges']+e['paths'][1]['edges']]:
   xx=x.copy();xx[inds]=1-xx[inds];costs.append(flow_cost(dr,un,tr,xx))
  assert costs[0]==e['cost_before'] and costs[-1]==e['cost_after']
  joint.append({'instance':t['instance'],'seed':t['seed'],'C_base':costs[0],'C_a':costs[1],'C_b':costs[2],'C_ab':costs[3],'strict':costs[1]>=costs[0] and costs[2]>=costs[0] and costs[3]<costs[0]})
pd.DataFrame(joint).to_csv(OUT/'primary_joint_moves_audit.csv',index=False);metric['joint_moves']=joint
# Check new-city identities, raw pair definitions, and saved physical route witnesses.
manifest=read(NEW/'run_manifest.json');assert sha(ROOT/'source/mixed_postman_pycharm/run_postman_experiment.py')==manifest['script_sha256']
for g in manifest['graphs']:assert sha(ROOT/'source/mixed_postman_pycharm/data'/g['file'])==g['graph_sha256']
pairs=pd.read_csv(NEW/'pair_audit.csv');cent=pd.read_csv(NEW/'centres.csv'); print('pair columns',pairs.columns.tolist())
strict=(pairs.single_a_cm>=pairs.base_cm)&(pairs.single_b_cm>=pairs.base_cm)&(pairs.pair_cm<pairs.base_cm)
assert (strict.astype(int)==pairs.strict_constituent_gain).all()
assert ((pairs.single_a_cm+pairs.single_b_cm-pairs.base_cm-pairs.pair_cm)==pairs.interaction_cm).all()
for key,z in pairs.groupby(['city','seed','stage']):
 cr=cent[(cent.city==key[0])&(cent.seed==key[1])&(cent.stage==key[2])].iloc[0];assert z.strict_constituent_gain.sum()==cr.strict_pairs and len(z)==cr.audited_pairs
wn=0
for f in NEW.glob('evidence/*/*/*.json'):
 e=read(f);g=read(ROOT/'source/mixed_postman_pycharm/data'/f"{e['city']}.json");links={a['id']:a for a in g['links']}
 for w in e['route_witnesses'].values():
  total=0;last=None;start=None;seen=set()
  for k,direction in w['route']:
   a=links[k]; assert direction in [1,-1] and (direction==1 or a['direction']=='twoway')
   u,v=(a['u'],a['v']) if direction==1 else (a['v'],a['u']);assert last is None or last==u;start=start or u;last=v;seen.add(k);total+=a['cost_cm']
  assert last==start and len(seen)==len(links) and total==w['cost_cm'];wn+=1
metric['new_city_pair_rows']=len(pairs);metric['new_city_route_witnesses']=wn;metric['new_city_stage_summary']=pd.read_csv(NEW/'stage_summary.csv').fillna('').to_dict('records')
metric['new_city_times']=cent.groupby('stage')[['single_wall_s','coupled_wall_s']].agg(['min','median','max']).to_dict()
# The archived 90-run large-graph controls differ from the unsupported source Table 3.
abl=ROOT/'source/V21_Coupled_Path_MCPP_Kit/results/v21_large_ablation_5seed_60s/experiment'
a=pd.DataFrame([read(f) for f in abl.glob('runs/*/result.json')]); a.groupby(['instance','method']).agg(mean_cm=('cost','mean'),sd_cm=('cost','std'),n=('cost','size')).reset_index().to_csv(OUT/'large_graph_controls.csv',index=False)
a.to_csv(OUT/'large_graph_control_runs.csv',index=False)
match=pd.read_csv(abl/'ablation_start_match_audit.csv');metric['ablation_match_records']=len(match);metric['ablation_match_columns']=match.columns.tolist();metric['ablation_methods']=a.groupby('method').size().to_dict()
# JSON-safe serialization for tuple keys from grouped summaries.
def safe(o):
 if isinstance(o,dict):return {str(k):safe(v) for k,v in o.items()}
 if isinstance(o,(list,tuple)):return [safe(v) for v in o]
 if isinstance(o,np.generic):return o.item()
 return o
(OUT/'audit_summary.json').write_text(json.dumps(safe(metric),indent=2))
(OUT/'primary_checkpoint_audit.json').write_text(json.dumps(audits,indent=2))
print(json.dumps(safe(metric),indent=2))
