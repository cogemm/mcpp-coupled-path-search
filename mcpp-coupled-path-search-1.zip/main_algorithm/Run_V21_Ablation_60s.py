"""Separate nine-graph mechanism study; includes the old search as a control."""
import sys
from ThreeCity_Experiment import main
if __name__ == '__main__':
    main(['--version', 'v21', '--profile', 'ablation', *sys.argv[1:]])
