#!/usr/bin/env python3
"""V21 coupled-path RNPS experimental implementation for MCPP.

Adds four-terminal, edge-disjoint service-path pair proposals to the frozen
V20 components. Sequential residual repair evaluates the joint objective with
updated shared capacities. Dual screening and center-local balance-signature
reuse have explicit ablations. These are candidate research mechanisms, not
claims of established literature novelty or universal performance superiority.

For the nine three-city 60-second experiment run Run_V21_ThreeCity_60s.py.
Use Run_V20_ThreeCity_60s.py to rerun the manuscript's original V20 method.
The two experiments have distinct source identities and output directories.
"""
from __future__ import annotations
import argparse
import copy
import csv
import dataclasses
import fnmatch
import hashlib
import heapq
import json
import math
import os
import platform
import random
import re
import statistics
import subprocess
import sys
import time
import traceback
import zipfile
import importlib.metadata as importlib_metadata
from collections import OrderedDict, defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Optional, Sequence

# ------------------------ PyCharm settings ------------------------
PAPER_MODE = "smoke"
LOCAL_DATASET_PATH = None   # e.g. r"E:\\PythonProject8\\corberan_mcpp_benchmark"
HISTORICAL_RESULTS_PATH = None  # e.g. r"E:\\PythonProject8\\cor_paper_results"
SCRIPT_DIR = Path(__file__).resolve().parent
OUTPUT_ROOT = SCRIPT_DIR / "v21_results"
SMOKE_BUDGET = 8.0
DEVELOPMENT_BUDGET = 60.0
CONFIRMATORY_BUDGET = 300.0
COST_SCALE = 1  # Corberan and supplied synthetic data have integer costs.
RNPS_REGION_SIZES = (12, 24, 32, 16)
RNPS_PHASE_SECONDS = 0.12
RNPS_DESCENT_SECONDS = 0.30
RNPS_FACE_NODES = 128
RNPS_CHAIN_LENGTH = 4
RNPS_CHAIN_CHECKS = 800
RNPS_INITIALIZER_FRACTION = 0.40
RNPS_INITIALIZER_MAX_FRACTION = 0.65
RNPS_LEGACY_INITIALIZER_MAX_FRACTION = 0.55
RNPS_INITIAL_DESCENT_FRACTION = 0.10
RNPS_INITIAL_DESCENT_MAX_SECONDS = 0.30
RNPS_SEARCH_RESERVE_FRACTION = 0.30
RNPS_FINAL_RESERVE = 0.12
ORIENTATION_CACHE_SIZE = 512
IMPORT_STARTUP_LIMIT = 90.0
BOOTSTRAP_REPEATS = 10000
STATISTICAL_SEED = 1802026
FRESH_GENERATOR_SEED = 18102026
FRESH_NODE_SIZES = (60, 150, 400, 1000, 2000)
FRESH_REPLICATES = 3  # 2 graph families x 5 sizes x 2 ratios x 3 = 60 instances.
DEVELOPMENT_INSTANCES = (
    "MA0532", "MB0532", "MA0545", "MB0545", "MA1032", "MB1032",
    "MA1045", "MB1045", "MA1532", "MB1532", "MA1545", "MB1545",
    "MA2032", "MB2032", "MA2045", "MB2045", "MA3032", "MB3032",
    "MA3045", "MB3045",
)
DEVELOPMENT_SEEDS = (180101, 180102, 180103, 180104, 180105)
CONFIRMATORY_SEEDS = (180201, 180202, 180203, 180204, 180205)
PROPOSED_METHOD = "cprnps"
# Only published MCPP journal algorithms belong in the external comparison.
# Our variants and the independently encoded CP-SAT model have other suites.
PUBLISHED_METHODS = ("modified_mixed", "frederickson_1979", "grasp_mcpp_2002", "aco_mcpp_2026")
SCI_MAIN_PUBLISHED_METHODS = ("modified_mixed", "frederickson_1979", "grasp_mcpp_2002")
LITERATURE_METHODS = (PROPOSED_METHOD, *SCI_MAIN_PUBLISHED_METHODS)
RECENT_COMPARISON_METHODS = (PROPOSED_METHOD, *PUBLISHED_METHODS)
ABLATION_METHODS = (PROPOSED_METHOD, "rnps", "cprnps_no_joint",
                   "cprnps_no_screen", "cprnps_no_signature", "cprnps_cold_joint")
VALIDATION_METHODS = ("full_mip", PROPOSED_METHOD, *PUBLISHED_METHODS)
SUITE_METHODS = {"literature": LITERATURE_METHODS, "ablation": ABLATION_METHODS,
                 "validation": VALIDATION_METHODS, "recent": RECENT_COMPARISON_METHODS}
METHODS = tuple(dict.fromkeys((*LITERATURE_METHODS, *ABLATION_METHODS, *VALIDATION_METHODS, *RECENT_COMPARISON_METHODS)))
GRASP_CANDIDATE_LIST = 10
GRASP_STAGNATION_LIMIT = 1000
ACO_2026_PARAMETERS = {
    'imb_ants': 10, 'imb_iterations': 10,
    'odd_ants': 50, 'odd_iterations': 100,
    'alpha': 1.0, 'beta': 1.0, 'tau0': 1.0, 'rho': 0.1, 'q': 1.0,
    'probability_formula': 'published_equation_2_scalar_multiplication',
    'imbalance_representation': 'repeated_unit_tokens',
    'shortest_paths': 'permitted_travel_network_with_physical_link_ids',
    'sgs': 'published_positive_imbalance_and_minimum_neighbor_rule; reject_failure',
    'restart_policy': 'one_published_two_colony_run; no_RNPS_or_exact_repair',
}

PUBLISHED_REFERENCES = {
    "modified_mixed": {
        "display_name": "Raghavachari-Veerasamy Modified Mixed (1999), Python reimplementation",
        "authors": "Balaji Raghavachari; Jeyakesavan Veerasamy", "year": 1999,
        "title": "A 3/2-Approximation Algorithm for the Mixed Postman Problem",
        "journal": "SIAM Journal on Discrete Mathematics", "volume_pages": "12(4):425-433",
        "doi": "10.1137/S0895480197331454",
        "implementation": "Independent structural reimplementation; not official author software",
        "mechanism": "Modified-cost EVENDEGREE, INOUTDEGREE, EVENPARITY, unchanged MIXED2; choose cheaper branch",
        "differences": "Integer native flow and exact blossom T-join solvers; deterministic tie breaking; budgeted branch checkpoints",
        "reference_equivalence": "Structural steps checked; numerical agreement with author software unavailable",
    },
    "frederickson_1979": {
        "display_name": "Frederickson Mixed (1979), Python reimplementation",
        "authors": "Greg N. Frederickson", "year": 1979,
        "title": "Approximation Algorithms for Some Postman Problems",
        "journal": "Journal of the ACM", "volume_pages": "26(3):538-554",
        "doi": "10.1145/322139.322150",
        "implementation": "Independent structural reimplementation; not official author software",
        "mechanism": "Original-cost MIXED1 and INOUTDEGREE/LARGECYCLES MIXED2; choose cheaper branch",
        "differences": "Exact flow/T-join engine, deterministic tie breaking and budgeted branch checkpoints",
        "reference_equivalence": "Steps also cross-checked against the GRASP authors' published-algorithm description; author software unavailable",
    },
    "grasp_mcpp_2002": {
        "display_name": "Corberan-Marti-Sanchis GRASP (2002), Python reimplementation",
        "authors": "Angel Corberan; Rafael Marti; Jose Maria Sanchis", "year": 2002,
        "title": "A GRASP heuristic for the mixed Chinese postman problem",
        "journal": "European Journal of Operational Research", "volume_pages": "142(1):70-80",
        "doi": "10.1016/S0377-2217(01)00296-X",
        "author_archive": "https://hdl.handle.net/10251/100592",
        "implementation": "Independent reimplementation checked against Sections 3.1 and 3.2 of the authors' archived manuscript",
        "mechanism": "Published weights, CL=10, forced orientation, exact flow construction; opposite-copy cancellation and leaf-pair path replacement",
        "differences": "Rebuild duplicate components after accepted switches instead of the C pointer structure; lazy shortest paths; native exact flow; wall-clock cap",
        "reference_equivalence": "Algorithmic steps checked against archived manuscript linked to the journal DOI; author C software unavailable",
    },
    "aco_mcpp_2026": {
        "display_name": "Sgarro-Santoro-Grilli ACO-MCPP (2026), checked independent port",
        "authors": "Giacinto Angelo Sgarro; Domenico Santoro; Luca Grilli", "year": 2026,
        "title": "Ant colony optimization for solving mixed Chinese postman problem on open real world data",
        "journal": "Neural Computing and Applications", "volume_pages": "38:134",
        "doi": "10.1007/s00521-026-11846-1",
        "author_repository": "https://github.com/hyacintus/ACO-MCPP-Daunian-Mountains",
        "author_repository_commit": "aa1fac183c6e5b25c780ddbd5335816aa3edfaba",
        "implementation": "Independent port of Sections 6.1-6.4 and Figure 11; author optimizer unavailable",
        "mechanism": "Imbalance ACO, odd-degree ACO, retained path augmentations, SGS, independently audited Euler circuit",
        "differences": "Unit-token multiplicities; main diagonal excludes self-pairs; disclosed fixed parameters; deadline checkpoints; explicit SGS failure rejection",
        "reference_equivalence": "Pipeline and equations inspected; no numerical author-code equivalence; see Recent_Comparison_Notes.md",
        "validity_policy": "No exact-flow rescue, common fallback or RNPS improvement; incomplete or invalid paper constructions remain failures",
        "scie_status": "Not confirmed: current publisher index list does not list SCIE; Clarivate record not accessible",
        "eligible_for_sci_main": False,
    },
}
EXCLUDED_LITERATURE_ADAPTATIONS = {
    "yaoyuenyong_mcpp_2002": {
        "title": "A Heuristic Algorithm for the Mixed Chinese Postman Problem",
        "journal": "Optimization and Engineering", "year": 2002,
        "doi": "10.1023/A:1020915403051",
        "reason": "Old Python code uses positive-cost discounted paths and random diversification. OARLib SAPH instead uses CostMod1/2, link types and cycle deletion. Full port/equivalence validation remains necessary.",
    },
    "unverified_aco_adaptation": {
        "title": "Ant colony optimization for solving mixed Chinese postman problem on open real world data",
        "journal": "Neural Computing and Applications", "year": 2026,
        "doi": "10.1007/s00521-026-11846-1",
        "reason": "Old code samples pairing candidates, drops explicit augmented paths, changes SGS ties and replaces the final augmented-route construction with exact recourse. This is an adaptation, not a verified reproduction of the published pipeline.",
    },
    "alns_mcpp": {
        "reason": "General ALNS for other routing problems adapted to MCPP; no corresponding published MCPP journal algorithm was established.",
    },
}


def validate_suite_methods(methods, suite):
    if suite not in SUITE_METHODS:
        raise ValueError("Unknown experiment suite: " + str(suite))
    if not methods or len(set(methods)) != len(methods):
        raise ValueError("Methods must be a nonempty list without duplicates")
    disallowed = set(methods) - set(SUITE_METHODS[suite])
    if disallowed:
        raise ValueError("Methods not allowed in %s suite: %s. Allowed: %s" %
                         (suite, sorted(disallowed), list(SUITE_METHODS[suite])))
    return list(methods)


def method_provenance(method):
    if method in PUBLISHED_REFERENCES:
        return dict(PUBLISHED_REFERENCES[method], method_category="published_journal_reimplementation")
    controls = {
        'rnps': 'Frozen V20 RNPS search/schedule internal development comparator',
        'cprnps_no_joint': 'Coupled RNPS with joint slots reassigned to single service paths',
        'cprnps_no_screen': 'Coupled RNPS without joint dual-bound rejection',
        'cprnps_no_signature': 'Coupled RNPS without center-local balance-signature reuse',
        'cprnps_cold_joint': 'Coupled RNPS with fresh exact MCF for the same joint proposals',
        'legacy_initializer': 'RNPS with V19 initializer allocation only',
        'legacy_phase_schedule': 'RNPS with V19 search scheduling only',
        'legacy_both': 'RNPS with both V19 scheduling policies',
        'without_chain': 'RNPS without service-path reversal',
        'without_parity': 'RNPS without parity faces or global orientation relaxation',
        'cold_repair': 'RNPS with independent cold MCF for the same proposed moves',
        'rv_singleflip': 'Random single-orientation-flip internal control',
    }
    return {"display_name": "Experimental coupled-path RNPS V21" if method == PROPOSED_METHOD else controls.get(method, method),
            "method_category": "proposed" if method == PROPOSED_METHOD else
                               "independent_complete_model" if method == "full_mip" else "internal_control",
            "doi": "", "journal": "", "year": "",
            "implementation": "This research kit; no claim of a published external method"}

# Force one native-library thread per process before third-party imports.
for _key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
             "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ[_key] = "1"
try:
    import numpy as np
    import pandas as pd
    import networkx as nx
    import rustworkx
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    from scipy.spatial import cKDTree
    from scipy.stats import wilcoxon, binomtest
    from ortools.graph.python import min_cost_flow
    from ortools.sat.python import cp_model
except ImportError as exc:
    raise SystemExit("Missing dependency: " + str(exc) +
        "\nIn this PyCharm interpreter run: python -m pip install numpy pandas networkx scipy ortools rustworkx matplotlib")

INF_SENTINEL = 9_999_999
OARLIB_REPO = "Olibear/ArcRoutingLibrary"
OARLIB_COMMIT = "db407dfa776977fd0ecede430c9d8f57efdf78cf"
RV_NETWORKX_MATCHING_TERMINAL_LIMIT = 160

@dataclass
class SearchConfig:
    seed: int = 180101
    cost_scale: int = COST_SCALE
    budget_mode: str = "time"
    budget_seconds: float = 60.0

# ------------------ Retained published comparator ------------------
@dataclass(frozen=True)
class DirectedRequired:
    tail: str
    head: str
    cost: float
    source_id: str


@dataclass(frozen=True)
class UndirectedRequired:
    u: str
    v: str
    cost: float
    source_id: str


@dataclass(frozen=True)
class TravelArc:
    tail: str
    head: str
    cost: float
    source_kind: str
    source_id: str


@dataclass
class MCPPInstance:
    name: str
    directed: list[DirectedRequired]
    undirected: list[UndirectedRequired]
    optional_travel: list[TravelArc] = field(default_factory=list)
    coordinates: dict[str, tuple[float, float]] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def node_ids(self) -> list[str]:
        nodes: set[str] = set(self.coordinates)
        for a in self.directed:
            nodes.update((a.tail, a.head))
        for e in self.undirected:
            nodes.update((e.u, e.v))
        for a in self.optional_travel:
            nodes.update((a.tail, a.head))
        return sorted(nodes, key=natural_key)

    @property
    def mandatory_cost(self) -> float:
        return float(sum(a.cost for a in self.directed) + sum(e.cost for e in self.undirected))

    @property
    def n_required(self) -> int:
        return len(self.directed) + len(self.undirected)

    def travel_arcs(self) -> list[TravelArc]:
        arcs = [TravelArc(a.tail, a.head, a.cost, "required_directed", a.source_id) for a in self.directed]
        for e in self.undirected:
            arcs.append(TravelArc(e.u, e.v, e.cost, "required_undirected", e.source_id))
            arcs.append(TravelArc(e.v, e.u, e.cost, "required_undirected", e.source_id))
        arcs.extend(self.optional_travel)
        return arcs


@dataclass
class CandidateSolution:
    orientation: np.ndarray
    extra_counts: np.ndarray
    total_cost: float
    extra_cost: float
    scaled_extra_cost: int
    dual_potential: np.ndarray
    feasible: bool
    balanced: bool
    connected: bool
    mcf_engine: str
    status: str = ""


@dataclass
class SearchOutcome:
    solution: CandidateSolution
    metrics: dict[str, Any]
    convergence: list[dict[str, Any]]
    neighborhood_log: list[dict[str, Any]]
    cut_log: list[dict[str, Any]]


def natural_key(value: str) -> list[Any]:
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r"(\d+)", str(value))]


def sha256_file(path: Path, chunk_size: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            block = f.read(chunk_size)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


EDGE_RE = re.compile(
    r"\(\s*([^,()]+?)\s*,\s*([^,()]+?)\s*\)\s*"
    r"(?:coste|cost|costo)?\s*"
    r"([+-]?\d+(?:\.\d+)?)\s+([+-]?\d+(?:\.\d+)?)",
    re.IGNORECASE,
)


COORD_RE = re.compile(r"^\s*([^\s]+)\s+([+-]?\d+(?:\.\d+)?)\s+([+-]?\d+(?:\.\d+)?)\s*$")


def _is_infinite_cost(value: float) -> bool:
    return (not math.isfinite(value)) or value >= INF_SENTINEL


def _read_text_auto(path: Path) -> str:
    data = path.read_bytes()
    for enc in ("utf-8-sig", "utf-8", "latin-1", "cp1252"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("latin-1", errors="replace")


def load_corberan_instance(path: Path) -> MCPPInstance:
    path = path.expanduser().resolve()
    text = _read_text_auto(path)
    lines = text.splitlines()
    name = path.name
    declared_vertices: Optional[int] = None
    declared_required: Optional[int] = None
    declared_nonrequired: Optional[int] = None

    state = "header"
    required_rows: list[tuple[str, str, float, float, int]] = []
    nonrequired_rows: list[tuple[str, str, float, float, int]] = []
    coordinates: dict[str, tuple[float, float]] = {}

    for line_no, raw in enumerate(lines, start=1):
        line = raw.strip()
        upper = line.upper()
        if not line:
            continue
        if upper.startswith("NOMBRE") or upper.startswith("NAME"):
            if ":" in line:
                name = line.split(":", 1)[1].strip() or name
            continue
        if upper.startswith("VERTICES"):
            nums = re.findall(r"\d+", line)
            if nums:
                declared_vertices = int(nums[-1])
            continue
        if "ARISTAS_REQ" in upper and "LISTA" not in upper:
            nums = re.findall(r"\d+", line)
            if nums:
                declared_required = int(nums[-1])
            continue
        if "ARISTAS_NOREQ" in upper and "LISTA" not in upper:
            nums = re.findall(r"\d+", line)
            if nums:
                declared_nonrequired = int(nums[-1])
            continue
        if "LISTA_ARISTAS_REQ" in upper:
            state = "required"
            continue
        if "LISTA_ARISTAS_NOREQ" in upper:
            state = "nonrequired"
            continue
        if "COORDENADAS" in upper or "COORDINATES" in upper:
            state = "coordinates"
            continue
        if set(line) <= {"=", "-", " ", "\t"}:
            continue

        match = EDGE_RE.search(line)
        if match and state in {"required", "nonrequired"}:
            row = (
                match.group(1).strip(), match.group(2).strip(),
                float(match.group(3)), float(match.group(4)), line_no,
            )
            if state == "required":
                required_rows.append(row)
            else:
                nonrequired_rows.append(row)
            continue

        if state == "coordinates":
            cm = COORD_RE.match(line)
            if cm:
                coordinates[cm.group(1).strip()] = (float(cm.group(2)), float(cm.group(3)))

    if not required_rows:
        raise ValueError(f"No required-link rows parsed from {path}")

    directed: list[DirectedRequired] = []
    undirected: list[UndirectedRequired] = []
    optional: list[TravelArc] = []

    for row_index, (u, v, c_uv, c_vu, line_no) in enumerate(required_rows):
        inf_uv, inf_vu = _is_infinite_cost(c_uv), _is_infinite_cost(c_vu)
        source = f"corberan:{name}:required:{row_index}"
        if not inf_uv and not inf_vu:
            if not math.isclose(c_uv, c_vu, rel_tol=0.0, abs_tol=1e-8):
                raise ValueError(
                    f"{path.name}:{line_no} has unequal finite directional costs "
                    f"({c_uv}, {c_vu}); this is windy rather than pure MCPP"
                )
            if c_uv <= 0:
                raise ValueError(f"{path.name}:{line_no} has nonpositive cost")
            undirected.append(UndirectedRequired(u, v, float(c_uv), source))
        elif not inf_uv and inf_vu:
            if c_uv <= 0:
                raise ValueError(f"{path.name}:{line_no} has nonpositive cost")
            directed.append(DirectedRequired(u, v, float(c_uv), source))
        elif inf_uv and not inf_vu:
            if c_vu <= 0:
                raise ValueError(f"{path.name}:{line_no} has nonpositive cost")
            directed.append(DirectedRequired(v, u, float(c_vu), source))
        else:
            raise ValueError(f"{path.name}:{line_no} prohibits both directions")

    for row_index, (u, v, c_uv, c_vu, line_no) in enumerate(nonrequired_rows):
        source = f"corberan:{name}:nonrequired:{row_index}"
        if not _is_infinite_cost(c_uv):
            if c_uv <= 0:
                raise ValueError(f"{path.name}:{line_no} has nonpositive optional cost")
            optional.append(TravelArc(u, v, float(c_uv), "optional", source + ":uv"))
        if not _is_infinite_cost(c_vu):
            if c_vu <= 0:
                raise ValueError(f"{path.name}:{line_no} has nonpositive optional cost")
            optional.append(TravelArc(v, u, float(c_vu), "optional", source + ":vu"))

    observed_nodes: set[str] = set()
    for a in directed:
        observed_nodes.update((a.tail, a.head))
    for e in undirected:
        observed_nodes.update((e.u, e.v))
    for a in optional:
        observed_nodes.update((a.tail, a.head))

    if declared_required is not None and declared_required != len(required_rows):
        raise ValueError(
            f"{path.name}: declared {declared_required} required links but parsed {len(required_rows)}"
        )
    if declared_nonrequired is not None and declared_nonrequired != len(nonrequired_rows):
        raise ValueError(
            f"{path.name}: declared {declared_nonrequired} nonrequired links but parsed {len(nonrequired_rows)}"
        )
    if declared_vertices is not None and declared_vertices < len(observed_nodes):
        raise ValueError(
            f"{path.name}: declared {declared_vertices} vertices but observed {len(observed_nodes)}"
        )

    metadata = {
        "dataset": "Corberan_MCPP_OARLib",
        "source_file": str(path),
        "source_sha256": sha256_file(path),
        "declared_vertices": declared_vertices,
        "declared_required_links": declared_required,
        "declared_nonrequired_links": declared_nonrequired,
        "parsed_required_links": len(required_rows),
        "parsed_nonrequired_links": len(nonrequired_rows),
        "oarlib_repository": OARLIB_REPO,
        "oarlib_commit": OARLIB_COMMIT,
    }
    return MCPPInstance(name, directed, undirected, optional, coordinates, metadata)


RV_PAPER_CITATION = (
    "B. Raghavachari and J. Veerasamy, A 3/2-Approximation Algorithm for the "
    "Mixed Postman Problem, SIAM Journal on Discrete Mathematics 12(4) (1999) "
    "425-433. DOI: 10.1137/S0895480197331454."
)


RV_IMPLEMENTATION_ID = "RV1999-MODIFIED-MIXED-3/2-STRUCTURAL-REIMPLEMENTATION-V3-EXACT-TJOIN-BLOSSOM"


@dataclass(frozen=True)
class RVArcCopy:
    uid: int
    tail: int
    head: int
    cost: float
    scaled_cost: int
    origin_kind: str       # directed | undirected
    origin_index: int
    is_base: bool


@dataclass(frozen=True)
class RVEdgeCopy:
    uid: int
    u: int
    v: int
    cost: float
    scaled_cost: int
    origin_index: int
    is_base: bool


@dataclass
class RVInOutResult:
    M: list[RVArcCopy]
    U: list[RVEdgeCopy]
    M_extra: list[RVArcCopy]
    augmentation_scaled: int
    flow_seconds: float
    augmentations: int


class RVUid:
    def __init__(self, start: int = 0) -> None:
        self.value = int(start)

    def next(self) -> int:
        value = self.value
        self.value += 1
        return value


@dataclass
class _RVResidualEdge:
    to: int
    rev: int
    cap: int
    cost: int
    arc_id: int
    direction: int


def _rv_check_deadline(deadline: float, where: str) -> None:
    if math.isfinite(deadline) and time.perf_counter() >= deadline:
        raise TimeoutError(f"Modified-Mixed exceeded the formal wall-clock budget during {where}")


def _rv_min_cost_flow_finite_ssp_fallback(
    n: int,
    arcs: Sequence[tuple[int, int, int, int]],
    supply: np.ndarray,
    deadline: float,
) -> tuple[np.ndarray, int, int, float]:
    """Exact integral finite-capacity min-cost flow used by INOUTDEGREE.

    Every cost is nonnegative in the constructed network, so zero initial
    potentials are dual feasible. The solver is deterministic and does not use
    any information from the proposed G-FRQ-SM-PB-LNS method.
    """
    supply = np.asarray(supply, dtype=np.int64)
    if len(supply) != n or int(supply.sum()) != 0:
        raise ValueError("RV INOUTDEGREE received an invalid supply vector")
    total = int(np.maximum(supply, 0).sum())
    if total == 0:
        return np.zeros(len(arcs), dtype=np.int64), 0, 0, 0.0

    source, sink, n_all = n, n + 1, n + 2
    graph: list[list[_RVResidualEdge]] = [[] for _ in range(n_all)]

    def add_edge(u: int, v: int, cap: int, cost: int, arc_id: int = -1, direction: int = 0) -> None:
        forward = _RVResidualEdge(v, len(graph[v]), int(cap), int(cost), int(arc_id), int(direction))
        backward = _RVResidualEdge(u, len(graph[u]), 0, -int(cost), int(arc_id), -int(direction))
        graph[u].append(forward)
        graph[v].append(backward)

    for arc_id, (u, v, cap, cost) in enumerate(arcs):
        if cap < 0 or cost < 0:
            raise ValueError("RV finite MCF requires nonnegative capacities and costs")
        add_edge(int(u), int(v), int(cap), int(cost), arc_id, 1)
    for vertex, amount in enumerate(supply):
        if amount > 0:
            add_edge(source, vertex, int(amount), 0)
        elif amount < 0:
            add_edge(vertex, sink, int(-amount), 0)

    started = time.perf_counter()
    potential = [0] * n_all
    flow = np.zeros(len(arcs), dtype=np.int64)
    sent = 0
    objective = 0
    augmentations = 0
    infinity = 10 ** 40

    while sent < total:
        _rv_check_deadline(deadline, "INOUTDEGREE min-cost flow")
        dist = [infinity] * n_all
        prev_node = [-1] * n_all
        prev_edge = [-1] * n_all
        dist[source] = 0
        queue: list[tuple[int, int]] = [(0, source)]
        popped = 0
        while queue:
            distance, u = heapq.heappop(queue)
            if distance != dist[u]:
                continue
            popped += 1
            if (popped & 1023) == 0:
                _rv_check_deadline(deadline, "INOUTDEGREE shortest path")
            for edge_index, edge in enumerate(graph[u]):
                if edge.cap <= 0:
                    continue
                reduced = edge.cost + potential[u] - potential[edge.to]
                if reduced < 0:
                    raise RuntimeError(f"RV finite MCF negative reduced cost {reduced}")
                candidate = distance + reduced
                if candidate < dist[edge.to]:
                    dist[edge.to] = candidate
                    prev_node[edge.to] = u
                    prev_edge[edge.to] = edge_index
                    heapq.heappush(queue, (candidate, edge.to))
        if dist[sink] >= infinity:
            raise RuntimeError("RV INOUTDEGREE min-cost flow is infeasible")
        for vertex in range(n_all):
            if dist[vertex] < infinity:
                potential[vertex] += int(dist[vertex])
        amount = total - sent
        vertex = sink
        while vertex != source:
            u = prev_node[vertex]
            if u < 0:
                raise RuntimeError("RV INOUTDEGREE augmenting path is broken")
            edge = graph[u][prev_edge[vertex]]
            amount = min(amount, edge.cap)
            vertex = u
        vertex = sink
        while vertex != source:
            u = prev_node[vertex]
            edge = graph[u][prev_edge[vertex]]
            edge.cap -= amount
            graph[vertex][edge.rev].cap += amount
            if edge.arc_id >= 0:
                flow[edge.arc_id] += amount * edge.direction
            objective += amount * edge.cost
            vertex = u
        sent += amount
        augmentations += 1

    if np.any(flow < 0):
        raise RuntimeError("RV INOUTDEGREE recovered a negative arc flow")
    return flow, int(objective), int(augmentations), time.perf_counter() - started


def _rv_min_cost_flow_finite(
    n: int,
    arcs: Sequence[tuple[int, int, int, int]],
    supply: np.ndarray,
    deadline: float,
) -> tuple[np.ndarray, int, int, float]:
    """Exact finite-capacity min-cost flow for RV INOUTDEGREE.

    The preferred backend is OR-Tools SimpleMinCostFlow (integer C++ solver).
    When that API is unavailable, SciPy/HiGHS solves the equivalent network LP.
    The node-arc incidence matrix is totally unimodular, so an integral optimum
    exists; the returned HiGHS solution is accepted only after an explicit
    integrality and conservation check.  The legacy Python SSP remains only as
    a final exact fallback for environments lacking both compiled backends.
    """
    supply = np.asarray(supply, dtype=np.int64)
    if len(supply) != n or int(supply.sum()) != 0:
        raise ValueError("RV INOUTDEGREE received an invalid supply vector")
    if any(int(cap) < 0 or int(cost) < 0 for _, _, cap, cost in arcs):
        raise ValueError("RV finite MCF requires nonnegative capacities and costs")
    if int(np.maximum(supply, 0).sum()) == 0:
        return np.zeros(len(arcs), dtype=np.int64), 0, 0, 0.0
    _rv_check_deadline(deadline, "INOUTDEGREE compiled min-cost flow setup")
    started = time.perf_counter()

    # Preferred exact integer backend.
    try:
        from ortools.graph.python import min_cost_flow as _ortools_mcf  # type: ignore
        solver = _ortools_mcf.SimpleMinCostFlow()
        for u, v, cap, cost in arcs:
            solver.add_arc_with_capacity_and_unit_cost(int(u), int(v), int(cap), int(cost))
        for vertex, amount in enumerate(supply):
            solver.set_node_supply(int(vertex), int(amount))
        status = solver.solve()
        if status != solver.OPTIMAL:
            label = str(status)
            raise RuntimeError(f"OR-Tools SimpleMinCostFlow failed to prove optimality: {label}")
        flow = np.asarray([int(solver.flow(i)) for i in range(solver.num_arcs())], dtype=np.int64)
        objective = int(solver.optimal_cost())
        elapsed = time.perf_counter() - started
        if math.isfinite(deadline) and time.perf_counter() > deadline:
            raise TimeoutError("Modified-Mixed exceeded the formal budget in INOUTDEGREE")
        # Verify exact conservation under the same sign convention as the legacy SSP.
        balance = np.zeros(n, dtype=np.int64)
        for f, (u, v, _, _) in zip(flow, arcs):
            if f:
                balance[int(u)] += int(f)
                balance[int(v)] -= int(f)
        if not np.array_equal(balance, supply):
            raise RuntimeError("OR-Tools RV min-cost-flow conservation verification failed")
        return flow, objective, 0, elapsed
    except ImportError:
        pass

    # Exact network-LP fallback through compiled HiGHS.  TU + integer RHS/bounds
    # implies an integral optimum; fail closed if numerical output is not integral.
    try:
        from scipy.optimize import linprog  # type: ignore
        from scipy.sparse import coo_matrix  # type: ignore
        m = len(arcs)
        rows: list[int] = []
        cols: list[int] = []
        data: list[int] = []
        for j, (u, v, _, _) in enumerate(arcs):
            rows.extend((int(u), int(v)))
            cols.extend((j, j))
            data.extend((1, -1))
        incidence = coo_matrix((data, (rows, cols)), shape=(n, m)).tocsr()
        objective_vector = np.asarray([int(cost) for _, _, _, cost in arcs], dtype=float)
        bounds = [(0.0, float(int(cap))) for _, _, cap, _ in arcs]
        remaining = max(0.0, deadline - time.perf_counter()) if math.isfinite(deadline) else None
        if remaining is not None and remaining <= 0.02:
            raise TimeoutError("No time remains for RV INOUTDEGREE")
        options = {"presolve": True}
        if remaining is not None:
            options["time_limit"] = float(remaining)
        result = linprog(
            objective_vector, A_eq=incidence, b_eq=supply.astype(float),
            bounds=bounds, method="highs", options=options,
        )
        if not bool(result.success) or result.x is None:
            raise RuntimeError(f"HiGHS RV min-cost flow failed: {result.message}")
        rounded = np.rint(result.x).astype(np.int64)
        if float(np.max(np.abs(result.x - rounded), initial=0.0)) > 1e-6:
            raise RuntimeError("HiGHS network-flow optimum was not numerically integral")
        balance = np.zeros(n, dtype=np.int64)
        for f, (u, v, cap, _) in zip(rounded, arcs):
            if f < 0 or f > int(cap):
                raise RuntimeError("HiGHS RV flow violates an arc capacity")
            if f:
                balance[int(u)] += int(f)
                balance[int(v)] -= int(f)
        if not np.array_equal(balance, supply):
            raise RuntimeError("HiGHS RV min-cost-flow conservation verification failed")
        exact_objective = int(sum(int(f) * int(cost) for f, (_, _, _, cost) in zip(rounded, arcs)))
        elapsed = time.perf_counter() - started
        if math.isfinite(deadline) and time.perf_counter() > deadline:
            raise TimeoutError("Modified-Mixed exceeded the formal budget in INOUTDEGREE")
        return rounded, exact_objective, 0, elapsed
    except ImportError:
        return _rv_min_cost_flow_finite_ssp_fallback(n, arcs, supply, deadline)


class RVPreparedLite:
    """Minimal prepared representation for the published Modified-Mixed comparator.

    The frozen G-FRQ code's ``PreparedInstance`` precomputes all-pairs shortest
    paths for Lipschitz/Benders guidance.  Raghavachari--Veerasamy never uses
    those quantities, and constructing them on 3000-node instances can consume
    most of the 300-s comparator budget.  This lightweight representation keeps
    only arrays required by INOUTDEGREE, route reconstruction, and the strict
    Euler audit.  It therefore changes no mathematical step of Modified-Mixed.
    """
    def __init__(self, instance: MCPPInstance, cost_scale: int) -> None:
        self.instance = instance
        self.nodes = instance.node_ids
        self.idx = {node: i for i, node in enumerate(self.nodes)}
        self.n = len(self.nodes)
        self.m = len(instance.undirected)
        self.cost_scale = int(cost_scale)
        self.edge_u = np.asarray([self.idx[e.u] for e in instance.undirected], dtype=np.int64)
        self.edge_v = np.asarray([self.idx[e.v] for e in instance.undirected], dtype=np.int64)
        self.fixed_balance = np.zeros(self.n, dtype=np.int64)
        for a in instance.directed:
            self.fixed_balance[self.idx[a.tail]] += 1
            self.fixed_balance[self.idx[a.head]] -= 1
        self.travel = instance.travel_arcs()
        self.travel_tail = np.asarray([self.idx[a.tail] for a in self.travel], dtype=np.int64)
        self.travel_head = np.asarray([self.idx[a.head] for a in self.travel], dtype=np.int64)
        self.travel_cost = np.asarray([float(a.cost) for a in self.travel], dtype=float)
        self.travel_scaled = np.asarray(
            [max(1, int(round(float(a.cost) * self.cost_scale))) for a in self.travel],
            dtype=np.int64,
        )
        required_graph = nx.Graph()
        required_graph.add_nodes_from(self.nodes)
        required_graph.add_edges_from((a.tail, a.head) for a in instance.directed)
        required_graph.add_edges_from((e.u, e.v) for e in instance.undirected)
        active = [v for v in required_graph.nodes if required_graph.degree(v) > 0]
        self.required_connected = bool(active) and nx.is_connected(
            required_graph.subgraph(active).copy()
        )
        if not self.required_connected:
            raise ValueError(
                f"Instance {instance.name} has a disconnected mandatory physical graph"
            )

    def mandatory_balance(self, orientation: np.ndarray) -> np.ndarray:
        x = np.asarray(orientation, dtype=np.int8)
        if len(x) != self.m:
            raise ValueError("RV orientation length mismatch")
        balance = self.fixed_balance.copy()
        if self.m:
            sign = np.where(x > 0, 1, -1).astype(np.int64)
            np.add.at(balance, self.edge_u, sign)
            np.add.at(balance, self.edge_v, -sign)
        return balance


def _rv_audit_candidate_light(
    instance: MCPPInstance,
    prep: RVPreparedLite,
    solution: CandidateSolution,
) -> dict[str, Any]:
    """Strict Euler/coverage/cost audit without proposed-method preprocessing."""
    balance = prep.mandatory_balance(solution.orientation).astype(np.int64)
    positive = np.flatnonzero(solution.extra_counts > 0)
    if len(positive):
        q = solution.extra_counts[positive].astype(np.int64)
        np.add.at(balance, prep.travel_tail[positive], q)
        np.add.at(balance, prep.travel_head[positive], -q)
    balanced = bool(np.all(balance == 0))

    support = nx.DiGraph()
    support.add_nodes_from(prep.nodes)
    for a in instance.directed:
        support.add_edge(a.tail, a.head)
    for bit, e in zip(np.asarray(solution.orientation, dtype=np.int8), instance.undirected):
        support.add_edge(e.u, e.v) if int(bit) else support.add_edge(e.v, e.u)
    for j in positive:
        arc = prep.travel[int(j)]
        support.add_edge(arc.tail, arc.head)
    active = [v for v in support.nodes if support.in_degree(v) + support.out_degree(v) > 0]
    connected = bool(active) and nx.is_strongly_connected(support.subgraph(active).copy())

    recomputed_extra = float(np.dot(solution.extra_counts.astype(float), prep.travel_cost))
    recomputed_total = float(instance.mandatory_cost + recomputed_extra)
    graph_cost = float(instance.mandatory_cost + recomputed_extra)
    cost_consistent = (
        math.isclose(recomputed_total, float(solution.total_cost), rel_tol=0.0, abs_tol=1e-6)
        and math.isclose(graph_cost, float(solution.total_cost), rel_tol=0.0, abs_tol=1e-6)
    )
    theorem_conditions = bool(prep.required_connected and balanced)
    theorem_verified = (not theorem_conditions) or connected
    return {
        "balanced": balanced,
        "strongly_connected": connected,
        "eulerian": bool(balanced and connected),
        "directed_required_covered": True,
        "undirected_required_covered": bool(len(solution.orientation) == prep.m and np.all(solution.orientation >= 0)),
        "cost_consistent": cost_consistent,
        "recomputed_total_cost": recomputed_total,
        "recomputed_graph_cost": graph_cost,
        "max_abs_vertex_imbalance": int(np.max(np.abs(balance), initial=0)),
        "mandatory_physical_graph_connected": prep.required_connected,
        "balance_implies_strong_connectivity_condition": theorem_conditions,
        "balance_connectivity_theorem_verified": theorem_verified,
    }


def _rv_original_model(
    instance: MCPPInstance, cfg: SearchConfig, uid: RVUid,
) -> tuple[RVPreparedLite, list[RVArcCopy], list[RVEdgeCopy]]:
    if instance.optional_travel:
        raise ValueError(
            "The formal Raghavachari-Veerasamy comparator is defined for the mixed "
            "postman graph itself. Corberan benchmark instances have no nonrequired "
            "travel links; optional travel arcs are therefore rejected rather than "
            "silently changing the published algorithm."
        )
    prep = RVPreparedLite(instance, cfg.cost_scale)
    arcs: list[RVArcCopy] = []
    edges: list[RVEdgeCopy] = []
    for index, arc in enumerate(instance.directed):
        arcs.append(RVArcCopy(
            uid.next(), prep.idx[arc.tail], prep.idx[arc.head], float(arc.cost),
            max(1, int(round(float(arc.cost) * cfg.cost_scale))),
            "directed", index, True,
        ))
    for index, edge in enumerate(instance.undirected):
        edges.append(RVEdgeCopy(
            uid.next(), prep.idx[edge.u], prep.idx[edge.v], float(edge.cost),
            max(1, int(round(float(edge.cost) * cfg.cost_scale))), index, True,
        ))
    return prep, arcs, edges


def _rv_inoutdegree(
    n: int,
    arcs: Sequence[RVArcCopy],
    edges: Sequence[RVEdgeCopy],
    uid: RVUid,
    deadline: float,
) -> RVInOutResult:
    """Exact INOUTDEGREE construction from Frederickson/Raghavachari-Veerasamy.

    Directed arcs and E1 copies carry their true cost; E2 variables are unit-
    capacity, zero-cost variables that orient each original undirected copy.
    """
    balance = np.zeros(n, dtype=np.int64)  # indegree(A)-outdegree(A)
    for arc in arcs:
        balance[arc.head] += 1
        balance[arc.tail] -= 1
    total = int(np.maximum(balance, 0).sum())
    infinite_capacity = max(1, total)
    network: list[tuple[int, int, int, int]] = []
    metadata: list[tuple[str, int, int]] = []

    for index, arc in enumerate(arcs):
        network.append((arc.tail, arc.head, infinite_capacity, arc.scaled_cost))
        metadata.append(("A", index, 0))
    arc_count = len(arcs)
    for index, edge in enumerate(edges):
        network.extend([
            (edge.u, edge.v, infinite_capacity, edge.scaled_cost),
            (edge.v, edge.u, infinite_capacity, edge.scaled_cost),
            (edge.u, edge.v, 1, 0),
            (edge.v, edge.u, 1, 0),
        ])
        metadata.extend([
            ("E1", index, 1), ("E1", index, -1),
            ("E2", index, 1), ("E2", index, -1),
        ])

    flow, objective, augmentations, flow_seconds = _rv_min_cost_flow_finite(
        n, network, balance, deadline
    )
    M = list(arcs)
    M_extra: list[RVArcCopy] = []
    U: list[RVEdgeCopy] = []

    # Additional directed-arc copies.
    for network_index in range(arc_count):
        count = int(flow[network_index])
        source = arcs[network_index]
        for _ in range(count):
            duplicate = RVArcCopy(
                uid.next(), source.tail, source.head, source.cost, source.scaled_cost,
                source.origin_kind, source.origin_index, False,
            )
            M.append(duplicate)
            M_extra.append(duplicate)

    base = arc_count
    for edge_index, edge in enumerate(edges):
        values = flow[base + 4 * edge_index: base + 4 * edge_index + 4].copy()
        # Cancel two opposite zero-cost E2 orientations; this leaves the original
        # undirected copy unoriented and preserves every vertex balance.
        cancel_e2 = min(int(values[2]), int(values[3]))
        values[2] -= cancel_e2
        values[3] -= cancel_e2
        # Opposite positive-cost E1 copies form a removable 2-cycle. An exact
        # optimum never needs it, but deterministic cancellation makes mapping
        # robust to degenerate optimal flows.
        cancel_e1 = min(int(values[0]), int(values[1]))
        values[0] -= cancel_e1
        values[1] -= cancel_e1
        objective -= 2 * cancel_e1 * edge.scaled_cost

        for direction, count in ((1, int(values[0])), (-1, int(values[1]))):
            tail, head = (edge.u, edge.v) if direction == 1 else (edge.v, edge.u)
            for _ in range(count):
                duplicate = RVArcCopy(
                    uid.next(), tail, head, edge.cost, edge.scaled_cost,
                    "undirected", edge.origin_index, False,
                )
                M.append(duplicate)
                M_extra.append(duplicate)

        e2_total = int(values[2]) + int(values[3])
        if e2_total == 0:
            U.append(edge)
        elif e2_total == 1:
            direction = 1 if int(values[2]) else -1
            tail, head = (edge.u, edge.v) if direction == 1 else (edge.v, edge.u)
            M.append(RVArcCopy(
                uid.next(), tail, head, edge.cost, edge.scaled_cost,
                "undirected", edge.origin_index, edge.is_base,
            ))
        else:
            raise RuntimeError("RV INOUTDEGREE E2 orientation mapping is inconsistent")

    directed_balance = np.zeros(n, dtype=np.int64)
    for arc in M:
        directed_balance[arc.tail] += 1
        directed_balance[arc.head] -= 1
    if np.any(directed_balance != 0):
        raise RuntimeError(
            f"RV INOUTDEGREE failed symmetry: max imbalance={int(np.max(np.abs(directed_balance)))}"
        )
    return RVInOutResult(M, U, M_extra, int(objective), flow_seconds, augmentations)


def _rv_total_degree(n: int, arcs: Sequence[RVArcCopy], edges: Sequence[RVEdgeCopy]) -> np.ndarray:
    degree = np.zeros(n, dtype=np.int64)
    for arc in arcs:
        degree[arc.tail] += 1
        degree[arc.head] += 1
    for edge in edges:
        degree[edge.u] += 1
        degree[edge.v] += 1
    return degree


class _RVDSU:
    def __init__(self, n: int) -> None:
        self.parent = list(range(n))
        self.rank = [0] * n

    def find(self, x: int) -> int:
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: int, b: int) -> None:
        a, b = self.find(a), self.find(b)
        if a == b:
            return
        if self.rank[a] < self.rank[b]:
            a, b = b, a
        self.parent[b] = a
        if self.rank[a] == self.rank[b]:
            self.rank[a] += 1


def _rv_link_endpoints(link: RVArcCopy | RVEdgeCopy) -> tuple[int, int]:
    if isinstance(link, RVArcCopy):
        return int(link.tail), int(link.head)
    return int(link.u), int(link.v)


def _rv_exact_parity_subset_blossom(
    node_count: int,
    edges: Sequence[tuple[int, int, int, int]],
    terminals: set[int],
    deadline: float,
) -> tuple[list[int], int, str]:
    """Exact minimum-cost T-join via metric closure + perfect matching.

    For nonnegative undirected edge costs, a minimum T-join is obtained by:
      1. shortest-path distances between the even-cardinality terminal set T;
      2. an exact minimum-weight perfect matching in that metric closure; and
      3. symmetric-difference expansion of the matched shortest paths.

    Small terminal sets use NetworkX's exact blossom implementation. Formal
    large paper instances require ``rustworkx`` so the same Edmonds/primal-dual
    weighted-matching algorithm runs in compiled Rust. ``verify_optimum=True``
    is enabled for the large backend. No heuristic or merely-feasible matching
    is ever accepted.
    """
    if not terminals:
        return [], 0, "empty"
    terminals = {int(v) for v in terminals}
    if len(terminals) % 2:
        raise RuntimeError("RV T-join terminal set has odd cardinality")
    if not edges:
        raise RuntimeError("RV T-join has terminals but no connecting edges")
    _rv_check_deadline(deadline, "T-join blossom setup")

    try:
        from scipy.sparse import coo_matrix  # type: ignore
        from scipy.sparse.csgraph import connected_components, dijkstra  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "SciPy is required for the exact Raghavachari-Veerasamy T-join "
            "metric-closure backend."
        ) from exc

    # Edges reaching this routine are already the cheapest representative of
    # each contracted component pair. Re-apply the rule defensively so that the
    # shortest-path graph is a simple undirected graph with deterministic edge
    # identifiers for path expansion.
    cheapest: dict[tuple[int, int], tuple[int, int]] = {}
    for u, v, weight, original_index in edges:
        u, v, weight, original_index = int(u), int(v), int(weight), int(original_index)
        if weight < 0:
            raise ValueError("RV exact T-join requires nonnegative weights")
        if u == v:
            continue
        key = (min(u, v), max(u, v))
        candidate = (weight, original_index)
        if key not in cheapest or candidate < cheapest[key]:
            cheapest[key] = candidate
    if not cheapest:
        raise RuntimeError("RV T-join has terminals but no positive connecting edges")

    rows: list[int] = []
    cols: list[int] = []
    vals: list[float] = []
    original_by_pair: dict[tuple[int, int], int] = {}
    weight_by_original: dict[int, int] = {}
    for (u, v), (weight, original_index) in sorted(cheapest.items()):
        rows.extend((u, v)); cols.extend((v, u)); vals.extend((float(weight), float(weight)))
        original_by_pair[(u, v)] = int(original_index)
        weight_by_original[int(original_index)] = int(weight)
    graph = coo_matrix(
        (np.asarray(vals, dtype=float), (np.asarray(rows), np.asarray(cols))),
        shape=(int(node_count), int(node_count)),
    ).tocsr()

    component_count, labels = connected_components(graph, directed=False, return_labels=True)
    selected: set[int] = set()
    matching_backend_names: list[str] = []

    for component in range(int(component_count)):
        component_terminals = sorted(v for v in terminals if int(labels[v]) == component)
        if not component_terminals:
            continue
        if len(component_terminals) % 2:
            raise RuntimeError(
                "RV exact T-join is infeasible: a connected component contains an odd "
                "number of T terminals"
            )
        if len(component_terminals) == 2:
            backend = "direct_shortest_path_pair"
        elif len(component_terminals) <= int(RV_NETWORKX_MATCHING_TERMINAL_LIMIT):
            backend = "networkx_exact_blossom"
        else:
            backend = "rustworkx_exact_blossom_verified"
        matching_backend_names.append(backend)

        _rv_check_deadline(deadline, "T-join metric closure shortest paths")
        terminal_array = np.asarray(component_terminals, dtype=np.int64)
        distances, predecessors = dijkstra(
            graph, directed=False, indices=terminal_array,
            return_predecessors=True, unweighted=False,
        )
        k = len(component_terminals)
        closure_cost = np.zeros((k, k), dtype=np.int64)
        for i in range(k):
            for j in range(i + 1, k):
                value = float(distances[i, component_terminals[j]])
                if not math.isfinite(value):
                    raise RuntimeError("RV exact T-join terminal pair is disconnected")
                rounded = int(round(value))
                if abs(value - rounded) > 1e-6:
                    raise RuntimeError("RV exact T-join shortest-path cost lost integer exactness")
                closure_cost[i, j] = closure_cost[j, i] = rounded
        _rv_check_deadline(deadline, "T-join exact perfect matching")

        if k == 2:
            pairs = {(0, 1)}
        elif backend == "networkx_exact_blossom":
            metric = nx.Graph()
            metric.add_nodes_from(range(k))
            for i in range(k):
                for j in range(i + 1, k):
                    metric.add_edge(i, j, weight=int(closure_cost[i, j]))
            pairs = {
                (min(int(a), int(b)), max(int(a), int(b)))
                for a, b in nx.algorithms.matching.min_weight_matching(metric, weight="weight")
            }
        else:
            try:
                import rustworkx as rx  # type: ignore
            except ImportError as exc:
                raise RuntimeError(
                    "Large exact RV T-joins require rustworkx==0.18.1 for the compiled "
                    "Edmonds blossom solver. Install it in the selected PyCharm interpreter "
                    "with: python -m pip install rustworkx==0.18.1"
                ) from exc
            metric = rx.PyGraph(multigraph=False)
            metric.add_nodes_from(list(range(k)))
            max_cost = int(np.max(closure_cost))
            weighted_edges: list[tuple[int, int, int]] = []
            transform = max_cost + 1
            for i in range(k):
                for j in range(i + 1, k):
                    # Every perfect matching has k/2 edges, so maximizing this
                    # transformed integer weight is exactly equivalent to minimizing
                    # the original metric-closure distance.
                    weighted_edges.append((i, j, int(transform - closure_cost[i, j])))
            metric.extend_from_weighted_edge_list(weighted_edges)
            raw_pairs = rx.max_weight_matching(
                metric,
                max_cardinality=True,
                weight_fn=lambda value: int(value),
                verify_optimum=True,
            )
            pairs = {
                (min(int(a), int(b)), max(int(a), int(b))) for a, b in raw_pairs
            }

        if len(pairs) * 2 != k:
            raise RuntimeError(
                f"RV exact matching is not perfect: terminals={k}, matched={2 * len(pairs)}"
            )
        matched_vertices = {v for pair in pairs for v in pair}
        if matched_vertices != set(range(k)):
            raise RuntimeError("RV exact matching omitted or repeated a terminal")
        _rv_check_deadline(deadline, "T-join shortest-path expansion")

        # Expand every matched metric edge back to an original path. Symmetric
        # difference is used because an undirected T-join is an edge subset; if
        # two shortest paths share an edge, two copies cancel without changing
        # terminal parity and can only reduce a nonnegative-cost solution.
        for i, j in sorted(pairs):
            source = int(component_terminals[i])
            current = int(component_terminals[j])
            guard = 0
            while current != source:
                guard += 1
                if guard > int(node_count) + 1:
                    raise RuntimeError("RV exact T-join predecessor chain contains a cycle")
                previous = int(predecessors[i, current])
                if previous < 0:
                    raise RuntimeError("RV exact T-join predecessor chain is broken")
                pair_key = (min(previous, current), max(previous, current))
                if pair_key not in original_by_pair:
                    raise RuntimeError("RV exact T-join path edge cannot be mapped to original link")
                original_index = int(original_by_pair[pair_key])
                if original_index in selected:
                    selected.remove(original_index)
                else:
                    selected.add(original_index)
                current = previous

    parity = np.zeros(int(node_count), dtype=np.int8)
    exact_cost = 0
    endpoints_by_original = {
        int(original_index): (int(u), int(v), int(weight))
        for u, v, weight, original_index in edges
    }
    for original_index in selected:
        if original_index not in endpoints_by_original:
            raise RuntimeError("RV exact T-join selected an unknown original edge")
        u, v, weight = endpoints_by_original[original_index]
        parity[u] ^= 1; parity[v] ^= 1
        exact_cost += int(weight)
    observed = {int(i) for i in np.flatnonzero(parity)}
    if observed != terminals:
        raise RuntimeError(
            f"RV exact blossom T-join parity audit failed: expected={len(terminals)}, "
            f"observed={len(observed)}"
        )
    if math.isfinite(deadline) and time.perf_counter() > deadline:
        raise TimeoutError("Modified-Mixed exceeded the formal budget in exact blossom T-join")
    backend_label = "+".join(sorted(set(matching_backend_names))) or "empty"
    return sorted(selected), int(exact_cost), backend_label


def _rv_exact_tjoin(
    n: int,
    links: Sequence[RVArcCopy | RVEdgeCopy],
    terminals: set[int],
    scaled_weight: Sequence[int],
    deadline: float,
) -> tuple[list[int], int, dict[str, Any]]:
    """Exact T-join with zero-cost component contraction.

    Zero-cost links are contracted before exact parity optimization. Residual
    parity inside each zero component is then satisfied on a zero-cost spanning
    tree. This is an exact reduction and is especially important for Modified
    Mixed1, where links used by preliminary M are deliberately assigned cost 0.
    """
    started = time.perf_counter()
    if len(links) != len(scaled_weight):
        raise ValueError("RV T-join link/weight length mismatch")
    terminals = {int(v) for v in terminals}
    if not terminals:
        return [], 0, {"solver": "empty", "seconds": 0.0, "contracted_nodes": n, "variables": 0}
    if len(terminals) % 2:
        raise RuntimeError("RV T-join terminal set must have even size")

    dsu = _RVDSU(n)
    zero_indices: list[int] = []
    for index, (link, weight) in enumerate(zip(links, scaled_weight)):
        if int(weight) == 0:
            u, v = _rv_link_endpoints(link)
            dsu.union(u, v)
            zero_indices.append(index)
    roots = sorted({dsu.find(v) for v in range(n)})
    root_to_component = {root: index for index, root in enumerate(roots)}
    component_of = [root_to_component[dsu.find(v)] for v in range(n)]
    component_count = len(roots)

    component_terminal_parity = np.zeros(component_count, dtype=np.int8)
    for vertex in terminals:
        component_terminal_parity[component_of[vertex]] ^= 1
    contracted_terminals = {int(i) for i in np.flatnonzero(component_terminal_parity)}

    # Parallel positive links between two contracted components: selecting two
    # is never optimal with nonnegative costs because the pair can be removed
    # without changing parity. Keep only the cheapest deterministic representative.
    cheapest: dict[tuple[int, int], tuple[int, int]] = {}
    for index, (link, weight) in enumerate(zip(links, scaled_weight)):
        weight = int(weight)
        if weight <= 0:
            continue
        u, v = _rv_link_endpoints(link)
        cu, cv = component_of[u], component_of[v]
        if cu == cv:
            continue
        key = (min(cu, cv), max(cu, cv))
        candidate = (weight, index)
        if key not in cheapest or candidate < cheapest[key]:
            cheapest[key] = candidate
    positive_edges = [
        (a, b, weight, index)
        for (a, b), (weight, index) in sorted(cheapest.items())
    ]

    selected_positive, positive_cost, solver_name = _rv_exact_parity_subset_blossom(
        component_count, positive_edges, contracted_terminals, deadline
    )
    selected: set[int] = set(selected_positive)

    # Compute residual vertex parity after the selected positive links.
    residual = np.zeros(n, dtype=np.int8)
    for vertex in terminals:
        residual[vertex] ^= 1
    for index in selected_positive:
        u, v = _rv_link_endpoints(links[index])
        residual[u] ^= 1
        residual[v] ^= 1

    # Satisfy residual parity inside each zero component on a deterministic
    # zero-cost spanning forest using leaf elimination.
    zero_adjacency: list[list[tuple[int, int]]] = [[] for _ in range(n)]
    for index in zero_indices:
        u, v = _rv_link_endpoints(links[index])
        zero_adjacency[u].append((v, index))
        zero_adjacency[v].append((u, index))
    for row in zero_adjacency:
        row.sort(key=lambda item: (item[0], item[1]))

    vertices_by_component: dict[int, list[int]] = defaultdict(list)
    for vertex, component in enumerate(component_of):
        vertices_by_component[int(component)].append(vertex)
    for component, vertices in vertices_by_component.items():
        if not np.any(residual[vertices]):
            continue
        root = min(vertices)
        parent = {root: -1}
        parent_edge: dict[int, int] = {}
        order = [root]
        stack = [root]
        while stack:
            u = stack.pop()
            for v, edge_index in zero_adjacency[u]:
                if component_of[v] != component or v in parent:
                    continue
                parent[v] = u
                parent_edge[v] = edge_index
                order.append(v)
                stack.append(v)
        if len(parent) != len(vertices):
            raise RuntimeError("RV zero-cost contraction component is disconnected")
        for vertex in reversed(order[1:]):
            if residual[vertex]:
                edge_index = parent_edge[vertex]
                selected.add(edge_index)
                residual[vertex] ^= 1
                residual[parent[vertex]] ^= 1
        if residual[root]:
            raise RuntimeError("RV zero-cost parity completion failed")

    if np.any(residual):
        raise RuntimeError("RV exact T-join residual parity is nonzero")
    exact_cost = int(sum(int(scaled_weight[i]) for i in selected))
    if exact_cost != int(positive_cost):
        raise RuntimeError("RV T-join contraction cost accounting mismatch")
    return sorted(selected), exact_cost, {
        "solver": solver_name,
        "seconds": time.perf_counter() - started,
        "contracted_nodes": component_count,
        "variables": len(positive_edges),
        "zero_links": len(zero_indices),
    }


def _rv_evendegree_modified(
    n: int,
    original_arcs: Sequence[RVArcCopy],
    original_edges: Sequence[RVEdgeCopy],
    uid: RVUid,
    zero_directed_origins: set[int],
    zero_undirected_origins: set[int],
    deadline: float,
) -> tuple[list[RVArcCopy], list[RVEdgeCopy], dict[str, Any]]:
    degree = _rv_total_degree(n, original_arcs, original_edges)
    terminals = {int(v) for v in np.flatnonzero(degree % 2)}
    links: list[RVArcCopy | RVEdgeCopy] = [*original_arcs, *original_edges]
    weights: list[int] = []
    for link in links:
        if isinstance(link, RVArcCopy):
            is_zero = (
                (link.origin_kind == "directed" and link.origin_index in zero_directed_origins)
                or (link.origin_kind == "undirected" and link.origin_index in zero_undirected_origins)
            )
        else:
            is_zero = link.origin_index in zero_undirected_origins
        weights.append(0 if is_zero else int(link.scaled_cost))
    selected, _, info = _rv_exact_tjoin(n, links, terminals, weights, deadline)
    arcs = list(original_arcs)
    edges = list(original_edges)
    for index in selected:
        link = links[index]
        if isinstance(link, RVArcCopy):
            arcs.append(RVArcCopy(
                uid.next(), link.tail, link.head, link.cost, link.scaled_cost,
                link.origin_kind, link.origin_index, False,
            ))
        else:
            edges.append(RVEdgeCopy(
                uid.next(), link.u, link.v, link.cost, link.scaled_cost,
                link.origin_index, False,
            ))
    if np.any(_rv_total_degree(n, arcs, edges) % 2):
        raise RuntimeError("RV EVENDEGREE failed to make all degrees even")
    return arcs, edges, info


def _rv_evenparity(
    n: int, inout: RVInOutResult, uid: RVUid, deadline: float,
) -> tuple[list[RVArcCopy], list[RVEdgeCopy]]:
    """Frederickson ADJUSTCYCLES / EVENPARITY step used by Modified Mixed1."""
    M = {arc.uid: arc for arc in inout.M}
    U = {edge.uid: edge for edge in inout.U}
    extra = {arc.uid: arc for arc in inout.M_extra}

    degree = _rv_total_degree(n, list(M.values()), list(U.values()))
    odd: set[int] = {int(v) for v in np.flatnonzero(degree % 2)}
    extra_adj: dict[int, list[int]] = defaultdict(list)
    undirected_adj: dict[int, list[int]] = defaultdict(list)
    for arc in extra.values():
        extra_adj[arc.tail].append(arc.uid)
        extra_adj[arc.head].append(arc.uid)
    for edge in U.values():
        undirected_adj[edge.u].append(edge.uid)
        undirected_adj[edge.v].append(edge.uid)
    for row in extra_adj.values():
        row.sort(reverse=True)
    for row in undirected_adj.values():
        row.sort(reverse=True)

    def pop_extra(vertex: int) -> RVArcCopy:
        row = extra_adj[vertex]
        while row and row[-1] not in extra:
            row.pop()
        if not row:
            raise RuntimeError(f"RV EVENPARITY cannot continue from vertex {vertex}: no unused M'' link")
        return extra.pop(row.pop())

    def pop_u(vertex: int) -> RVEdgeCopy:
        row = undirected_adj[vertex]
        while row and row[-1] not in U:
            row.pop()
        if not row:
            raise RuntimeError(f"RV EVENPARITY cannot continue from vertex {vertex}: no unused U edge")
        return U.pop(row.pop())

    while odd:
        _rv_check_deadline(deadline, "EVENPARITY")
        vertex = min(odd)
        start_vertex = vertex
        while vertex in odd:
            odd.remove(vertex)
            # Traverse M'' without regard to direction until the next odd vertex.
            while True:
                arc = pop_extra(vertex)
                next_vertex = arc.head if arc.tail == vertex else arc.tail
                if arc.tail == vertex:
                    duplicate = RVArcCopy(
                        uid.next(), arc.tail, arc.head, arc.cost, arc.scaled_cost,
                        arc.origin_kind, arc.origin_index, False,
                    )
                    M[duplicate.uid] = duplicate
                else:
                    if arc.uid not in M:
                        raise RuntimeError("RV EVENPARITY selected M'' copy is missing from M")
                    del M[arc.uid]
                vertex = next_vertex
                if vertex in odd:
                    break
            odd.remove(vertex)

            # Traverse U, orienting each used edge, until another odd vertex or
            # the cycle start is reached.
            while True:
                edge = pop_u(vertex)
                next_vertex = edge.v if edge.u == vertex else edge.u
                directed = RVArcCopy(
                    uid.next(), vertex, next_vertex, edge.cost, edge.scaled_cost,
                    "undirected", edge.origin_index, edge.is_base,
                )
                M[directed.uid] = directed
                vertex = next_vertex
                if vertex in odd or vertex == start_vertex:
                    break

    arcs = list(M.values())
    edges = list(U.values())
    directed_balance = np.zeros(n, dtype=np.int64)
    for arc in arcs:
        directed_balance[arc.tail] += 1
        directed_balance[arc.head] -= 1
    if np.any(directed_balance):
        raise RuntimeError("RV EVENPARITY failed to preserve symmetry")
    if np.any(_rv_total_degree(n, arcs, edges) % 2):
        raise RuntimeError("RV EVENPARITY failed to preserve even total degree")
    return arcs, edges


def _rv_orient_even_undirected_components(
    n: int, arcs: Sequence[RVArcCopy], edges: Sequence[RVEdgeCopy], uid: RVUid,
) -> list[RVArcCopy]:
    directed = list(arcs)
    degree = np.zeros(n, dtype=np.int64)
    graph = nx.MultiGraph()
    graph.add_nodes_from(range(n))
    lookup: dict[int, RVEdgeCopy] = {}
    for edge in edges:
        degree[edge.u] += 1
        degree[edge.v] += 1
        graph.add_edge(edge.u, edge.v, key=edge.uid)
        lookup[edge.uid] = edge
    if np.any(degree % 2):
        raise RuntimeError("RV final U subgraph is not even")
    seen: set[int] = set()
    for component in nx.connected_components(graph):
        subgraph = graph.subgraph(component).copy()
        if subgraph.number_of_edges() == 0:
            continue
        if not nx.is_eulerian(subgraph):
            raise RuntimeError("RV U component is not Eulerian")
        source = min(v for v in subgraph.nodes if subgraph.degree(v) > 0)
        for u, v, key in nx.eulerian_circuit(subgraph, source=source, keys=True):
            edge = lookup[int(key)]
            directed.append(RVArcCopy(
                uid.next(), int(u), int(v), edge.cost, edge.scaled_cost,
                "undirected", edge.origin_index, edge.is_base,
            ))
            seen.add(int(key))
    if len(seen) != len(edges):
        raise RuntimeError("RV did not orient every remaining U copy")
    balance = np.zeros(n, dtype=np.int64)
    for arc in directed:
        balance[arc.tail] += 1
        balance[arc.head] -= 1
    if np.any(balance):
        raise RuntimeError("RV final directed multigraph is not balanced")
    return directed


def _rv_largecycles(
    n: int,
    preliminary: RVInOutResult,
    original_edges: Sequence[RVEdgeCopy],
    uid: RVUid,
    deadline: float,
) -> tuple[list[RVArcCopy], dict[str, Any]]:
    """MIXED2 LARGECYCLES: exact T-join on the original undirected edge graph."""
    degree_u = np.zeros(n, dtype=np.int64)
    for edge in preliminary.U:
        degree_u[edge.u] += 1
        degree_u[edge.v] += 1
    terminals = {int(v) for v in np.flatnonzero(degree_u % 2)}
    weights = [int(edge.scaled_cost) for edge in original_edges]
    selected, _, info = _rv_exact_tjoin(n, list(original_edges), terminals, weights, deadline)
    U = list(preliminary.U)
    for index in selected:
        edge = original_edges[index]
        U.append(RVEdgeCopy(
            uid.next(), edge.u, edge.v, edge.cost, edge.scaled_cost,
            edge.origin_index, False,
        ))
    if np.any(_rv_total_degree(n, preliminary.M, U) % 2):
        # M is symmetric, hence every M-degree is even; this check is equivalent
        # to verifying the LARGECYCLES T-join parity condition.
        raise RuntimeError("RV LARGECYCLES failed to make the graph even")
    return _rv_orient_even_undirected_components(n, preliminary.M, U, uid), info


def _rv_arcs_to_candidate(
    instance: MCPPInstance,
    cfg: SearchConfig,
    prep: RVPreparedLite,
    arcs: Sequence[RVArcCopy],
    status: str,
) -> tuple[CandidateSolution, dict[str, Any]]:
    orientation = np.full(prep.m, -1, dtype=np.int8)
    extra_counts = np.zeros(len(prep.travel), dtype=np.int64)
    base_directed = np.zeros(len(instance.directed), dtype=np.int64)
    directed_offset = len(instance.directed)

    for arc in arcs:
        if arc.origin_kind == "directed":
            if arc.is_base:
                base_directed[arc.origin_index] += 1
            else:
                extra_counts[arc.origin_index] += 1
        elif arc.origin_kind == "undirected":
            edge_index = int(arc.origin_index)
            u = int(prep.edge_u[edge_index])
            v = int(prep.edge_v[edge_index])
            if (arc.tail, arc.head) == (u, v):
                bit = 1
                travel_index = directed_offset + 2 * edge_index
            elif (arc.tail, arc.head) == (v, u):
                bit = 0
                travel_index = directed_offset + 2 * edge_index + 1
            else:
                raise RuntimeError("RV undirected-copy endpoint mapping failed")
            if arc.is_base:
                if orientation[edge_index] != -1:
                    raise RuntimeError("RV original undirected edge was serviced more than once")
                orientation[edge_index] = bit
            else:
                extra_counts[travel_index] += 1
        else:
            raise RuntimeError(f"Unknown RV origin kind: {arc.origin_kind}")

    if len(base_directed) and not np.all(base_directed == 1):
        raise RuntimeError("RV original directed arcs are not covered exactly once as mandatory links")
    if np.any(orientation < 0):
        raise RuntimeError("RV did not orient every original undirected required edge")

    extra_cost = float(np.dot(extra_counts.astype(float), prep.travel_cost))
    scaled_extra = int(np.dot(extra_counts.astype(object), prep.travel_scaled.astype(object)))
    solution = CandidateSolution(
        orientation=orientation,
        extra_counts=extra_counts,
        total_cost=float(instance.mandatory_cost + extra_cost),
        extra_cost=extra_cost,
        scaled_extra_cost=scaled_extra,
        dual_potential=np.zeros(prep.n, dtype=np.int64),
        feasible=True, balanced=True, connected=True,
        mcf_engine="rv_modified_mixed_3_2_published_structure",
        status=status,
    )
    audit = _rv_audit_candidate_light(instance, prep, solution)
    required = (
        "balanced", "strongly_connected", "eulerian",
        "directed_required_covered", "undirected_required_covered", "cost_consistent",
    )
    if not all(bool(audit.get(key, False)) for key in required):
        raise RuntimeError(f"Raghavachari-Veerasamy solution failed strict audit: {audit}")
    return solution, audit


def search_modified_mixed_1999(instance: MCPPInstance, cfg: SearchConfig, on_incumbent=None) -> SearchOutcome:
    """Paper-faithful structural reimplementation of Raghavachari--Veerasamy.

    This is a deterministic published-algorithm comparator. It does not call the
    proposed method, persistent Benders cuts, Fisher--Rao proposals, GRASP, or
    the common orientation exact-recourse optimizer to improve its solution.
    The common Evaluator is used only at the end for the same strict route audit.
    """
    cached = _rv_load_cache(instance, cfg)
    if cached is not None:
        return cached
    if cfg.budget_mode != "time":
        raise ValueError("Formal Modified-Mixed comparator requires a wall-clock time budget")
    started = time.perf_counter()
    deadline = started + float(cfg.budget_seconds)
    uid = RVUid()
    prep, original_arcs, original_edges = _rv_original_model(instance, cfg, uid)
    n = prep.n
    tjoin_infos: list[dict[str, Any]] = []
    inout_seconds = 0.0
    inout_augmentations = 0
    inout_solves = 0
    convergence: list[dict[str, Any]] = []

    # Preliminary INOUTDEGREE is shared by Modified Mixed1's zero-cost rule and
    # by the unchanged Mixed2 branch.
    preliminary = _rv_inoutdegree(n, original_arcs, original_edges, uid, deadline)
    inout_seconds += preliminary.flow_seconds
    inout_augmentations += preliminary.augmentations
    inout_solves += 1

    zero_directed = {
        arc.origin_index for arc in preliminary.M if arc.origin_kind == "directed"
    }
    zero_undirected = {
        arc.origin_index for arc in preliminary.M if arc.origin_kind == "undirected"
    }

    # Modified Mixed1: modified-cost EVENDEGREE on G, then the standard
    # INOUTDEGREE and EVENPARITY sequence using true costs thereafter.
    even_arcs, even_edges, info = _rv_evendegree_modified(
        n, original_arcs, original_edges, uid,
        zero_directed, zero_undirected, deadline,
    )
    tjoin_infos.append(info)
    mixed1_io = _rv_inoutdegree(n, even_arcs, even_edges, uid, deadline)
    inout_seconds += mixed1_io.flow_seconds
    inout_augmentations += mixed1_io.augmentations
    inout_solves += 1
    mixed1_arcs, mixed1_u = _rv_evenparity(n, mixed1_io, uid, deadline)
    mixed1_arcs = _rv_orient_even_undirected_components(n, mixed1_arcs, mixed1_u, uid)
    mixed1_solution, mixed1_audit = _rv_arcs_to_candidate(
        instance, cfg, prep, mixed1_arcs, "rv_modified_mixed1"
    )
    if on_incumbent is not None:
        on_incumbent(mixed1_solution, "published_modified_mixed_branch1")
    convergence.append({
        "iteration": 1,
        "elapsed_seconds": time.perf_counter() - started,
        "best_cost": mixed1_solution.total_cost,
        "current_cost": mixed1_solution.total_cost,
        "unique_mcf_calls": 0,
        "phase": "modified_mixed1_complete",
    })
    _rv_check_deadline(deadline, "between Modified Mixed1 and Mixed2")

    # Mixed2 is unchanged by Raghavachari--Veerasamy: preliminary INOUTDEGREE
    # followed by LARGECYCLES on the original undirected graph.
    mixed2_arcs, info = _rv_largecycles(
        n, preliminary, original_edges, uid, deadline
    )
    tjoin_infos.append(info)
    mixed2_solution, mixed2_audit = _rv_arcs_to_candidate(
        instance, cfg, prep, mixed2_arcs, "rv_mixed2"
    )
    best = mixed1_solution if mixed1_solution.total_cost <= mixed2_solution.total_cost else mixed2_solution
    if on_incumbent is not None:
        on_incumbent(best, "published_modified_mixed_complete")
    best_audit = mixed1_audit if best is mixed1_solution else mixed2_audit
    selected_branch = "modified_mixed1" if best is mixed1_solution else "mixed2"
    elapsed = time.perf_counter() - started
    if elapsed > float(cfg.budget_seconds) + 1e-9:
        raise TimeoutError(
            f"Modified-Mixed completed in {elapsed:.6f}s, exceeding the formal "
            f"{cfg.budget_seconds:.6f}s budget; result rejected."
        )
    convergence.append({
        "iteration": 2,
        "elapsed_seconds": elapsed,
        "best_cost": best.total_cost,
        "current_cost": mixed2_solution.total_cost,
        "unique_mcf_calls": 0,
        "phase": "mixed2_complete",
    })

    metrics = {
        "method_seconds": elapsed,
        "search_seconds": elapsed,
        "post_audit_seconds": 0.0,
        "budget_overshoot_seconds": 0.0,
        "unique_mcf_calls": 0,
        "mcf_cache_hits": 0,
        "mcf_seconds": 0.0,
        "augmentations": 0,
        "iterations": 2,
        "audit": best_audit,
        "literature_method": "Raghavachari-Veerasamy-1999-Modified-Mixed-3/2",
        "rv_citation": RV_PAPER_CITATION,
        "rv_implementation_id": RV_IMPLEMENTATION_ID,
        "rv_exact_subproblems": True,
        "rv_selected_branch": selected_branch,
        "rv_modified_mixed1_cost": mixed1_solution.total_cost,
        "rv_mixed2_cost": mixed2_solution.total_cost,
        "rv_inout_flow_solves": inout_solves,
        "rv_inout_flow_seconds": inout_seconds,
        "rv_inout_augmentations": inout_augmentations,
        "rv_tjoin_solves": len(tjoin_infos),
        "rv_tjoin_seconds": float(sum(float(info.get("seconds", 0.0)) for info in tjoin_infos)),
        "rv_tjoin_solvers": ";".join(str(info.get("solver", "")) for info in tjoin_infos),
        "rv_tjoin_variables_max": max((int(info.get("variables", 0)) for info in tjoin_infos), default=0),
        "rv_deterministic_reused": False,
    }
    outcome = SearchOutcome(best, metrics, convergence, [], [])
    _rv_save_cache(instance, cfg, outcome)
    return outcome
# =============================================================================
# RNPS research extension. All baseline code above is readable and self-contained.
# =============================================================================

def _rv_load_cache(instance, cfg):
    # New timing experiments always compute their own initializer in their budget.
    return None


def _rv_save_cache(instance, cfg, outcome):
    return None


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False,
                              default=lambda x: x.item() if isinstance(x, np.generic) else str(x)),
                   encoding='utf-8')
    os.replace(tmp, path)


def remaining(deadline):
    return max(0.0, deadline - time.monotonic())


def load_instance(path):
    path = Path(path)
    if path.suffix.lower() == '.json':
        d = json.loads(path.read_text(encoding='utf-8'))
        ins = MCPPInstance(d['name'],
                           [DirectedRequired(**v) for v in d['directed']],
                           [UndirectedRequired(**v) for v in d['undirected']],
                           [TravelArc(**v) for v in d.get('optional_travel', [])],
                           d.get('coordinates', {}), d.get('metadata', {}))
        ins.metadata.update(source_file=str(path.resolve()), source_sha256=sha256_file(path))
        return ins
    return load_corberan_instance(path)


def dump_instance(ins, path):
    atomic_json(path, dataclasses.asdict(ins))


def checked_extract(archive, destination):
    destination = Path(destination).resolve()
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            if not (destination / item.filename).resolve().is_relative_to(destination):
                raise ValueError('Unsafe archive member: ' + item.filename)
        z.extractall(destination)


def dataset_directory(explicit=None):
    choices = ([Path(explicit)] if explicit else []) + [
        Path(LOCAL_DATASET_PATH) if LOCAL_DATASET_PATH else SCRIPT_DIR / 'corberan_mcpp_benchmark',
        SCRIPT_DIR / 'data' / 'corberan_mcpp_benchmark',
        SCRIPT_DIR.parent / 'corberan_mcpp_benchmark',
    ]
    for p in choices:
        if p.is_dir() and (p / 'MA0532').is_file():
            return p.resolve()
    for z in [SCRIPT_DIR / 'corberan_mcpp_benchmark.zip',
              SCRIPT_DIR.parent / 'corberan_mcpp_benchmark.zip']:
        if z.exists():
            checked_extract(z, SCRIPT_DIR / 'data')
            return dataset_directory(SCRIPT_DIR / 'data' / 'corberan_mcpp_benchmark')
    raise FileNotFoundError('Put corberan_mcpp_benchmark.zip beside this .py, or set LOCAL_DATASET_PATH.')


class ExactOracle:
    """Integer C++ min-cost flow with a separately verified residual dual.

    B is outflow minus inflow. b(x) = b0 + 2 C x, and B f = -b(x).
    No all-pairs shortest paths are used. Original costs must be representable
    exactly at COST_SCALE; silent rounding would invalidate the proof.
    """
    def __init__(self, instance):
        self.ins = instance
        self.prep = RVPreparedLite(instance, COST_SCALE)
        p = self.prep
        for original, scaled in zip(p.travel_cost, p.travel_scaled):
            if original <= 0 or abs(float(original) * COST_SCALE - int(scaled)) > 1e-7:
                raise ValueError('Positive, exactly representable costs required. Increase COST_SCALE.')
        self.b0 = p.fixed_balance.copy()
        np.add.at(self.b0, p.edge_u, -1)
        np.add.at(self.b0, p.edge_v, 1)
        self.calls = 0
        self.cache_hits = 0
        self.cache = OrderedDict()
        self.flow_seconds = 0.0
        self.dual_seconds = 0.0
        self.last_seconds = 0.0

    def audit(self, sol, dual=False):
        """Independent count, conservation, SCC, coverage and objective checks."""
        p = self.prep
        x = np.asarray(sol.orientation)
        f = np.asarray(sol.extra_counts)
        if x.shape != (p.m,) or f.shape != (len(p.travel),):
            raise ValueError('Invalid solution array shape')
        if not np.all((x == 0) | (x == 1)):
            raise ValueError('Every required undirected edge needs a binary orientation')
        if not np.all(np.isfinite(f)) or not np.all(f >= 0) or not np.all(f == np.rint(f)):
            raise ValueError('Traversal multiplicities must be nonnegative integers')
        f = f.astype(np.int64)
        balance = p.mandatory_balance(x)
        np.add.at(balance, p.travel_tail, f)
        np.add.at(balance, p.travel_head, -f)
        if np.any(balance):
            raise ValueError('Flow conservation failed')
        tails = [p.idx[a.tail] for a in self.ins.directed]
        heads = [p.idx[a.head] for a in self.ins.directed]
        tails.extend(np.where(x == 1, p.edge_u, p.edge_v).tolist())
        heads.extend(np.where(x == 1, p.edge_v, p.edge_u).tolist())
        positive = np.flatnonzero(f)
        tails.extend(p.travel_tail[positive].tolist())
        heads.extend(p.travel_head[positive].tolist())
        graph = coo_matrix((np.ones(len(tails)), (tails, heads)), shape=(p.n, p.n)).tocsr()
        active = np.unique(np.asarray(tails + heads, dtype=np.int64))
        if not len(active) or connected_components(graph[active][:, active], directed=True,
                                                   connection='strong', return_labels=False) != 1:
            raise ValueError('Directed support is not strongly connected')
        extra_scaled = sum(int(q) * int(c) for q, c in zip(f, p.travel_scaled))
        total = float(self.ins.mandatory_cost + extra_scaled / COST_SCALE)
        if not math.isclose(total, sol.total_cost, abs_tol=1e-7, rel_tol=0):
            raise ValueError('Objective does not equal independently reconstructed cost')
        if extra_scaled != int(sol.scaled_extra_cost):
            raise ValueError('Scaled objective mismatch')
        info = {'passed': True, 'binary_orientation': True, 'integer_traversals': True,
                'balanced': True, 'strongly_connected': True, 'coverage': True,
                'cost_consistent': True, 'total_cost': total, 'extra_scaled': extra_scaled}
        if dual:
            pi = np.asarray(sol.dual_potential, dtype=np.int64)
            slack = p.travel_scaled - (pi[p.travel_tail] - pi[p.travel_head])
            supply = -p.mandatory_balance(x)
            dual_value = sum(int(a) * int(b) for a, b in zip(supply, pi))
            if np.any(slack < 0) or np.any(slack[positive] != 0) or dual_value != extra_scaled:
                raise ValueError('Primal-dual certificate failed; no invalid dual certificate accepted')
            info.update(dual_feasible=True, complementary_slackness=True, primal_dual_gap=0)
        return info

    def _dual(self, flow):
        # A shortest-path potential on the residual graph. All original forward
        # arcs have spare capacity; positive flows add negative-cost reverse arcs.
        # The graph has no negative cycle because the primal flow is optimal.
        p = self.prep
        adj = [[] for _ in range(p.n)]
        for u, v, c, q in zip(p.travel_tail, p.travel_head, p.travel_scaled, flow):
            adj[int(u)].append((int(v), int(c)))
            if q > 0:
                adj[int(v)].append((int(u), -int(c)))
        dist = [0] * p.n
        todo = deque(range(p.n))
        in_queue = [True] * p.n
        while todo:
            u = todo.popleft()
            in_queue[u] = False
            du = dist[u]
            for v, c in adj[u]:
                value = du + c
                if value < dist[v]:
                    dist[v] = value
                    if not in_queue[v]:
                        if todo and value < dist[todo[0]]:
                            todo.appendleft(v)
                        else:
                            todo.append(v)
                        in_queue[v] = True
        return -np.asarray(dist, dtype=np.int64)

    def evaluate(self, orientation, deadline=float('inf'), verify_dual=True, use_cache=True):
        x = np.asarray(orientation, dtype=np.int8)
        if x.shape != (self.prep.m,) or not np.all((x == 0) | (x == 1)):
            raise ValueError('Invalid orientation')
        key = x.tobytes()
        if use_cache and verify_dual and key in self.cache:
            self.cache_hits += 1
            self.cache.move_to_end(key)
            return copy.deepcopy(self.cache[key])
        if remaining(deadline) <= 0.005:
            raise TimeoutError('Recourse deadline')
        started = time.monotonic()
        p = self.prep
        supply = -p.mandatory_balance(x)
        total = int(np.maximum(supply, 0).sum())
        if total:
            solver = min_cost_flow.SimpleMinCostFlow()
            solver.add_arcs_with_capacity_and_unit_cost(
                p.travel_tail, p.travel_head,
                np.full(len(p.travel), total + 1, dtype=np.int64), p.travel_scaled)
            solver.set_nodes_supplies(np.arange(p.n, dtype=np.int64), supply)
            status = solver.solve()
            if status != solver.OPTIMAL:
                raise RuntimeError('Recourse is not proved optimal: ' + str(status))
            flow = np.asarray(solver.flows(np.arange(len(p.travel), dtype=np.int64)), dtype=np.int64)
            objective = int(solver.optimal_cost())
        else:
            flow = np.zeros(len(p.travel), dtype=np.int64)
            objective = 0
        after_flow = time.monotonic()
        pi = self._dual(flow) if verify_dual else np.zeros(p.n, dtype=np.int64)
        self.calls += 1
        self.flow_seconds += after_flow - started
        self.dual_seconds += time.monotonic() - after_flow
        self.last_seconds = time.monotonic() - started
        sol = CandidateSolution(x.copy(), flow, float(self.ins.mandatory_cost + objective / COST_SCALE),
                                float(objective / COST_SCALE), objective, pi, True, True, True,
                                'ortools_integer_mcf+independent_residual_dual', 'certified_recourse')
        self.audit(sol, dual=verify_dual)
        if time.monotonic() > deadline:
            raise TimeoutError('Recourse completed after deadline; candidate rejected')
        if use_cache and verify_dual:
            self.cache[key] = copy.deepcopy(sol)
            if len(self.cache) > ORIENTATION_CACHE_SIZE:
                self.cache.popitem(last=False)
        return sol

    def cut(self, sol):
        self.audit(sol, dual=True)
        p = self.prep
        pi = sol.dual_potential
        beta = -2 * (pi[p.edge_u] - pi[p.edge_v])
        alpha = -sum(int(a) * int(b) for a, b in zip(self.b0, pi))
        if alpha + sum(int(a) * int(b) for a, b in zip(beta, sol.orientation)) != sol.scaled_extra_cost:
            raise AssertionError('Dual affine bound not tight at origin')
        return int(alpha), beta.copy()


class CheckpointWriter:
    def __init__(self, folder, instance, oracle, start, budget):
        self.folder = Path(folder)
        self.ins = instance
        self.oracle = oracle
        self.start = start
        self.budget = budget
        self.best = None
        self.events = []
        self.sequence = 0
        self.last_metrics = {}

    def commit(self, sol, phase, metrics=None):
        if time.monotonic() - self.start > self.budget:
            return False
        if self.best is not None and sol.total_cost >= self.best.total_cost - 1e-9:
            return False
        self.oracle.audit(sol)
        self.sequence += 1
        name = 'candidate_%05d.npz' % self.sequence
        temp = self.folder / (name + '.tmp')
        with temp.open('wb') as handle:
            np.savez_compressed(handle, orientation=sol.orientation, extra_counts=sol.extra_counts,
                                total_cost=np.asarray(sol.total_cost),
                                scaled_extra_cost=np.asarray(sol.scaled_extra_cost),
                                dual_potential=sol.dual_potential)
        elapsed = time.monotonic() - self.start
        if elapsed > self.budget:
            temp.unlink(missing_ok=True)
            return False
        os.replace(temp, self.folder / name)
        event = {'elapsed_seconds': elapsed, 'best_cost': sol.total_cost, 'phase': phase,
                 'candidate': name, 'candidate_sha256': sha256_file(self.folder / name)}
        # Persistence and hashing are also charged to the method budget.
        event['elapsed_seconds'] = time.monotonic() - self.start
        if event['elapsed_seconds'] > self.budget:
            return False
        self.best = copy.deepcopy(sol)
        self.events.append(event)
        self.last_metrics = dict(metrics or {})
        atomic_json(self.folder / 'checkpoint.json', {'instance': self.ins.name,
                    'instance_sha256': self.ins.metadata['source_sha256'], 'event': event,
                    'events': self.events, 'metrics': self.last_metrics})
        return True

    def save_bound(self, bound_scaled, source):
        elapsed = time.monotonic() - self.start
        if elapsed <= self.budget:
            atomic_json(self.folder / 'global_bound.json', {'bound_scaled': int(bound_scaled),
                        'elapsed_seconds': elapsed, 'source': source})


def direct_model(oracle, incumbent):
    """Complete exact MCPP model under the connected-mandatory-support assumption.

    Per-arc bound N_required is globally safe: every orientation has supply at
    most N_required, and a positive-cost optimal repair flow contains no cycle.
    The incumbent objective cutoff removes only solutions that cannot improve
    the known feasible upper bound; it never removes a global optimum.
    """
    p = oracle.prep
    model = cp_model.CpModel()
    xx = [model.new_bool_var('x%d' % j) for j in range(p.m)]
    bound = max(1, oracle.ins.n_required)
    ff = [model.new_int_var(0, bound, 'f%d' % j) for j in range(len(p.travel))]
    terms = [[] for _ in range(p.n)]
    for j, (u, v) in enumerate(zip(p.edge_u, p.edge_v)):
        terms[int(u)].append(2 * xx[j])
        terms[int(v)].append(-2 * xx[j])
    for j, (u, v) in enumerate(zip(p.travel_tail, p.travel_head)):
        terms[int(u)].append(ff[j])
        terms[int(v)].append(-ff[j])
    for i in range(p.n):
        model.add(sum(terms[i]) == -int(oracle.b0[i]))
    objective = sum(int(c) * f for c, f in zip(p.travel_scaled, ff))
    model.add(objective <= int(incumbent.scaled_extra_cost))
    model.minimize(objective)
    for v, q in zip(xx, incumbent.orientation):
        model.add_hint(v, int(q))
    for v, q in zip(ff, incumbent.extra_counts):
        model.add_hint(v, int(q))
    return model, xx, ff


def candidate_from_arrays(oracle, x, f, label='direct_mip'):
    p = oracle.prep
    f = np.asarray(f, dtype=np.int64)
    value = sum(int(a) * int(b) for a, b in zip(f, p.travel_scaled))
    return CandidateSolution(np.asarray(x, dtype=np.int8), f,
            float(oracle.ins.mandatory_cost + value/COST_SCALE), float(value/COST_SCALE),
            value, np.zeros(p.n, dtype=np.int64), True, True, True, label, label)


def run_direct_mip(oracle, incumbent, deadline, seed, writer):
    model, xx, ff = direct_model(oracle, incumbent)
    if remaining(deadline) < 0.05:
        return {'global_status': 'NO_TIME', 'global_optimal': False}
    class Callback(cp_model.CpSolverSolutionCallback):
        def __init__(self):
            super().__init__()
            self.count = 0
        def on_solution_callback(self):
            if remaining(deadline) <= 0:
                self.stop_search()
                return
            sol = candidate_from_arrays(oracle, [self.value(x) for x in xx], [self.value(f) for f in ff])
            writer.commit(sol, 'global_mip_incumbent')
            self.count += 1
            writer.save_bound(max(0, int(math.ceil(self.best_objective_bound - 1e-6))), 'global_cp_sat')
    solver = cp_model.CpSolver()
    solver.parameters.num_search_workers = 1
    solver.parameters.random_seed = int(seed) % 2147483647
    solver.parameters.max_time_in_seconds = max(0.01, remaining(deadline)-0.08)
    callback = Callback()
    status = solver.solve(model, callback)
    optimal = status == cp_model.OPTIMAL and remaining(deadline) > 0
    if remaining(deadline) > 0:
        writer.save_bound(max(0, int(math.ceil(solver.best_objective_bound - 1e-6))), 'global_cp_sat')
    return {'global_status': solver.status_name(status), 'global_optimal': optimal,
            'global_bound_scaled': max(0, int(math.ceil(solver.best_objective_bound - 1e-6))),
            'global_mip_incumbents': callback.count}


# Published journal methods: independent of the proposed search.
def _paper_degree_weight(di: int, dj: int, tiny: float = 1e-6) -> float:
    """Corberan-Martí-Sanchis (2002) construction weight w(i,j)."""
    prod = di * dj
    if prod > 0:
        return -abs(di + dj)
    if prod < 0:
        return abs(di - dj)
    if di == 0 and dj == 0:
        return -tiny
    return tiny

def _grasp_construct_orientation(prep: RVPreparedLite, rng: np.random.Generator, cl: int = 10) -> np.ndarray:
    """Published GRASP construction phase, implemented with a lazy top-s heap."""
    m = prep.m
    if m == 0:
        return np.empty(0, dtype=np.int8)
    # Paper d(v) = incoming - outgoing for original arcs + oriented edges.
    d = (-prep.fixed_balance).astype(np.int64).copy()
    orientation = np.full(m, -1, dtype=np.int8)
    remaining = np.ones(m, dtype=bool)
    version = np.zeros(m, dtype=np.int64)
    incident: dict[int, list[int]] = defaultdict(list)
    in_count = np.zeros(prep.n, dtype=np.int64)
    out_count = np.zeros(prep.n, dtype=np.int64)
    for a in prep.instance.directed:
        out_count[prep.idx[a.tail]] += 1
        in_count[prep.idx[a.head]] += 1
    for eidx, (u, v) in enumerate(zip(prep.edge_u, prep.edge_v)):
        incident[int(u)].append(eidx); incident[int(v)].append(eidx)

    heap: list[tuple[float, int, int]] = []
    def push_edge(eidx: int) -> None:
        if not remaining[eidx]:
            return
        u = int(prep.edge_u[eidx]); v = int(prep.edge_v[eidx])
        w = _paper_degree_weight(int(d[u]), int(d[v]))
        heapq.heappush(heap, (-float(w), int(version[eidx]), int(eidx)))
    for eidx in range(m):
        push_edge(eidx)

    def assign(eidx: int, bit: int) -> None:
        if not remaining[eidx]:
            return
        u = int(prep.edge_u[eidx]); v = int(prep.edge_v[eidx])
        orientation[eidx] = int(bit); remaining[eidx] = False; version[eidx] += 1
        if bit:
            # u -> v : paper d=in-out therefore d[u]-=1,d[v]+=1
            d[u] -= 1; d[v] += 1; out_count[u] += 1; in_count[v] += 1
        else:
            d[v] -= 1; d[u] += 1; out_count[v] += 1; in_count[u] += 1
        touched = set(incident[u]) | set(incident[v])
        for j in touched:
            if remaining[j]:
                version[j] += 1; push_edge(j)

    def force_unique_edges(seed_nodes: Sequence[int]) -> None:
        # Paper's forced orientation rule: if a vertex has one unoriented edge
        # and no outgoing (incoming) selected link, orient that edge outward
        # (inward). Repeat because one forced assignment can trigger another.
        queue = deque(int(x) for x in seed_nodes)
        seen_guard = 0
        while queue and seen_guard < 4 * (prep.n + m + 1):
            seen_guard += 1
            node = queue.popleft()
            rem = [j for j in incident[node] if remaining[j]]
            if len(rem) != 1:
                continue
            eidx = rem[0]
            u = int(prep.edge_u[eidx]); v = int(prep.edge_v[eidx])
            other = v if node == u else u
            bit = None
            if out_count[node] == 0:
                bit = 1 if node == u else 0
            elif in_count[node] == 0:
                bit = 0 if node == u else 1
            if bit is not None:
                assign(eidx, int(bit))
                queue.append(node); queue.append(other)

    while bool(np.any(remaining)):
        top: list[tuple[float, int]] = []
        while heap and len(top) < max(1, int(cl)):
            negw, ver, eidx = heapq.heappop(heap)
            if not remaining[eidx] or ver != int(version[eidx]):
                continue
            u = int(prep.edge_u[eidx]); v = int(prep.edge_v[eidx])
            true_w = _paper_degree_weight(int(d[u]), int(d[v]))
            if abs((-negw) - true_w) > 1e-12:
                version[eidx] += 1; push_edge(eidx); continue
            top.append((true_w, eidx))
        if not top:
            eidx = int(np.flatnonzero(remaining)[0])
        else:
            choice = int(rng.integers(0, len(top)))
            eidx = int(top[choice][1])
            for k, (_, other) in enumerate(top):
                if k != choice and remaining[other]:
                    push_edge(int(other))
        u = int(prep.edge_u[eidx]); v = int(prep.edge_v[eidx])
        if d[u] > d[v]:
            bit = 1
        elif d[v] > d[u]:
            bit = 0
        else:
            bit = int(rng.integers(0, 2))
        assign(eidx, bit)
        force_unique_edges((u, v))
    return orientation.astype(np.int8)

def search_frederickson_1979(instance, cfg, on_incumbent=None):
    """Original Mixed algorithm: minimum of MIXED1 and MIXED2.

    EVENDEGREE uses true costs throughout. The zero-cost modification of
    Raghavachari-Veerasamy is deliberately absent. Subroutines are shared
    numerical implementations of published flow, matching and parity steps.
    """
    started = time.perf_counter()
    deadline = started + cfg.budget_seconds
    uid = RVUid()
    prep, arcs, edges = _rv_original_model(instance, cfg, uid)
    n = prep.n
    even_arcs, even_edges, t1 = _rv_evendegree_modified(
        n, arcs, edges, uid, set(), set(), deadline)
    io1 = _rv_inoutdegree(n, even_arcs, even_edges, uid, deadline)
    a1, u1 = _rv_evenparity(n, io1, uid, deadline)
    a1 = _rv_orient_even_undirected_components(n, a1, u1, uid)
    sol1, _ = _rv_arcs_to_candidate(instance, cfg, prep, a1, 'frederickson_mixed1')
    sol1.mcf_engine = 'published_frederickson_mixed_exact_subproblems'
    if on_incumbent is not None:
        on_incumbent(sol1, 'published_frederickson_branch1')
    _rv_check_deadline(deadline, 'between original MIXED1 and MIXED2')
    io2 = _rv_inoutdegree(n, arcs, edges, uid, deadline)
    a2, t2 = _rv_largecycles(n, io2, edges, uid, deadline)
    sol2, _ = _rv_arcs_to_candidate(instance, cfg, prep, a2, 'frederickson_mixed2')
    sol2.mcf_engine = 'published_frederickson_mixed_exact_subproblems'
    best = sol1 if sol1.total_cost <= sol2.total_cost else sol2
    if on_incumbent is not None:
        on_incumbent(best, 'published_frederickson_complete')
    _rv_check_deadline(deadline, 'original Mixed final audit')
    stats = {'literature_method': 'Frederickson-1979-Mixed',
             'published_algorithm_completed': True, 'iterations': 2,
             'mixed1_cost': sol1.total_cost, 'mixed2_cost': sol2.total_cost,
             'selected_branch': 'mixed1' if best is sol1 else 'mixed2',
             'published_flow_solves': 2,
             'published_flow_seconds': io1.flow_seconds + io2.flow_seconds,
             'published_tjoin_solves': 2,
             'published_tjoin_seconds': t1.get('seconds', 0) + t2.get('seconds', 0)}
    return SearchOutcome(best, stats, [], [], [])


def _grasp_route_counts(oracle, solution):
    """Total directed traversal counts, including one copy of each service."""
    p = oracle.prep
    counts = solution.extra_counts.astype(np.int64).copy()
    offset = len(oracle.ins.directed)
    counts[:offset] += 1
    for i, bit in enumerate(solution.orientation):
        counts[offset + 2*i + (0 if bit else 1)] += 1
    return counts


def _grasp_candidate_from_route(oracle, counts, status):
    """Choose a serviced copy from a route; never optimize it with our method."""
    counts = np.asarray(counts, dtype=np.int64)
    p = oracle.prep
    offset = len(oracle.ins.directed)
    if np.any(counts < 0) or np.any(counts[:offset] < 1):
        raise ValueError('GRASP switch removed mandatory directed service')
    extra = counts.copy()
    extra[:offset] -= 1
    orientation = np.zeros(p.m, dtype=np.int8)
    for i in range(p.m):
        forward, reverse = offset + 2*i, offset + 2*i + 1
        if counts[forward] + counts[reverse] < 1:
            raise ValueError('GRASP switch removed mandatory undirected service')
        bit = int(counts[forward] > 0)
        orientation[i] = bit
        extra[forward if bit else reverse] -= 1
    sol = candidate_from_arrays(oracle, orientation, extra, status)
    oracle.audit(sol)
    return sol


def _grasp_cancel_opposite_copies(oracle, counts):
    # Section 3.2, step (6): delete opposite copies only while >2 copies remain.
    counts = counts.copy()
    offset = len(oracle.ins.directed)
    deleted = 0
    for i in range(oracle.prep.m):
        a, b = offset + 2*i, offset + 2*i + 1
        pair_count = min(int(counts[a]), int(counts[b]),
                         max(0, (int(counts[a] + counts[b]) - 1)//2))
        counts[a] -= pair_count
        counts[b] -= pair_count
        deleted += 2*pair_count
    return counts, deleted


def _grasp_duplicate_graph(oracle, counts):
    """Section 3.2 mixed G': ordinary copies plus neutral opposite pairs.

    A required undirected edge used once each way becomes one mixed edge in G'.
    Traversing that mixed edge in a proposed deletion path removes the copy in
    that direction, retaining the opposite mandatory copy. Other links only
    expose extra copies. All path operations retain original source identities.
    """
    p = oracle.prep
    directed = nx.DiGraph()
    weak = nx.Graph()
    offset = len(oracle.ins.directed)

    def add(j):
        u, v, c = int(p.travel_tail[j]), int(p.travel_head[j]), int(p.travel_scaled[j])
        weak.add_edge(u, v)
        old = directed.get_edge_data(u, v)
        if old is None or (c, j) < (old['weight'], old['travel_index']):
            directed.add_edge(u, v, weight=c, travel_index=j)

    for j in range(offset):
        if counts[j] > 1:
            add(j)
    for i in range(p.m):
        a, b = offset + 2*i, offset + 2*i + 1
        if counts[a] == counts[b] == 1:
            add(a); add(b)
        else:
            if counts[a] > 1:
                add(a)
            if counts[b] > 1:
                add(b)
    return directed, weak


def _grasp_physical_graph(oracle):
    graph = nx.DiGraph()
    graph.add_nodes_from(range(oracle.prep.n))
    p = oracle.prep
    for j, (u, v, c) in enumerate(zip(p.travel_tail, p.travel_head, p.travel_scaled)):
        u, v, c = int(u), int(v), int(c)
        old = graph.get_edge_data(u, v)
        if old is None or (c, j) < (old['weight'], old['travel_index']):
            graph.add_edge(u, v, weight=c, travel_index=j)
    return graph


def _grasp_switch_improvement(oracle, solution, physical, distance_cache,
                              deadline, writer, stats):
    """Published opposite-copy deletion and leaf-pair duplicate-path switches.

    After each accepted switch we rebuild components, equivalent to updating
    the paper's pointer structure. No single-edge orientation search, dual
    guidance, Benders cuts or post-switch exact recourse is inserted.
    """
    current = solution
    while remaining(deadline) > .005:
        counts, removed = _grasp_cancel_opposite_copies(
            oracle, _grasp_route_counts(oracle, current))
        if removed:
            current = _grasp_candidate_from_route(oracle, counts, 'grasp_opposite_copy_deletion')
            stats['opposite_copies_removed'] += removed
            writer.commit(current, 'published_grasp_opposite_copy_deletion', stats)
        duplicates, weak = _grasp_duplicate_graph(oracle, counts)
        accepted = False
        for component in nx.connected_components(weak):
            # Only leaf vertices (one distinct physical neighbor), as in 3.2.
            leaves = sorted(v for v in component if weak.degree(v) == 1)
            if len(leaves) < 2:
                continue
            for u in leaves:
                if remaining(deadline) <= .005:
                    return current
                qdist, qpaths = nx.single_source_dijkstra(duplicates, u, weight='weight')
                if u not in distance_cache:
                    distance_cache[u] = nx.single_source_dijkstra(physical, u, weight='weight')
                pdist, ppaths = distance_cache[u]
                for v in leaves:
                    if remaining(deadline) <= .005:
                        return current
                    if v == u or v not in qdist or v not in pdist:
                        continue
                    stats['leaf_pair_checks'] += 1
                    if pdist[v] >= qdist[v]:
                        continue
                    trial = counts.copy()
                    for a, b in zip(qpaths[v][:-1], qpaths[v][1:]):
                        trial[duplicates[a][b]['travel_index']] -= 1
                    for a, b in zip(ppaths[v][:-1], ppaths[v][1:]):
                        trial[physical[a][b]['travel_index']] += 1
                    candidate = _grasp_candidate_from_route(oracle, trial, 'grasp_leaf_pair_switch')
                    if candidate.total_cost >= current.total_cost - 1e-9:
                        raise AssertionError('GRASP positive-value path switch did not improve')
                    expected = current.total_cost - (qdist[v] - pdist[v])/COST_SCALE
                    if abs(expected - candidate.total_cost) > 1e-7:
                        raise AssertionError('GRASP path replacement cost mismatch')
                    current = candidate
                    stats['leaf_path_switches'] += 1
                    writer.commit(current, 'published_grasp_leaf_path_switch', stats)
                    accepted = True
                    break
                if accepted:
                    break
            if accepted:
                break
        if not accepted:
            break
    return current


def run_grasp_2002(oracle, deadline, seed, writer, stats):
    """Sections 3.1-3.2 of the authors' journal-linked archived manuscript."""
    rng = np.random.default_rng(seed)
    physical = _grasp_physical_graph(oracle)
    distances = {}
    best = None
    stagnation = 0
    stats.update(published_algorithm_completed=False, grasp_iterations=0,
                 opposite_copies_removed=0, leaf_pair_checks=0, leaf_path_switches=0,
                 grasp_candidate_list=GRASP_CANDIDATE_LIST,
                 grasp_stagnation_limit=GRASP_STAGNATION_LIMIT)
    while remaining(deadline) > max(.005, oracle.last_seconds*1.15):
        x = _grasp_construct_orientation(oracle.prep, rng, GRASP_CANDIDATE_LIST)
        try:
            solution = oracle.evaluate(x, deadline, verify_dual=False)
        except TimeoutError:
            break
        # Save before local improvement: a killed worker retains a valid prefix.
        writer.commit(solution, 'published_grasp_construction', stats)
        solution = _grasp_switch_improvement(oracle, solution, physical, distances,
                                             deadline, writer, stats)
        stats['grasp_iterations'] += 1
        if best is None or solution.total_cost < best.total_cost - 1e-9:
            best = solution
            stagnation = 0
        else:
            stagnation += 1
        if stagnation >= GRASP_STAGNATION_LIMIT:
            stats['published_algorithm_completed'] = True
            break
    atomic_json(writer.folder/'stage_metrics.json', stats)
    return writer, stats


def _aco_probability_weights(tau, distances, parameters=None):
    """Literal Eq. (2); the printed alpha/beta are scalar multipliers.

    The PDF was inspected, rather than silently replacing multiplication with
    the more common exponent rule. At the frozen alpha=beta=1 both agree.
    Positive scalar factors cancel in normalized roulette probabilities.
    """
    cfg = parameters or ACO_2026_PARAMETERS
    eta = np.zeros_like(distances, dtype=float)
    valid = np.isfinite(distances) & (distances > 0)
    np.divide(1., distances, out=eta, where=valid)
    return (tau * cfg['alpha']) * (eta * cfg['beta'])


def _aco_draw_matching(weights, rng, deadline, odd=False):
    """Global-cell roulette using an equivalent row-then-column draw.

    Unit copies of imbalance nodes enforce their prescribed multiplicities.
    Odd pairing removes BOTH chosen nodes. No top-k sampling, greedy matching,
    Hungarian solver or blossom optimizer replaces the published ACO loop.
    """
    w = weights.copy()
    row_mass = w.sum(axis=1)
    pairs = []
    target = len(w)//2 if odd else len(w)
    if not odd and w.shape[0] != w.shape[1]:
        raise ValueError('Expanded imbalance supplies and demands must agree')
    for _ in range(target):
        if remaining(deadline) <= .001:
            raise TimeoutError('ACO ant construction reached its stage deadline')
        total = float(row_mass.sum())
        if not total > 0 or not np.isfinite(total):
            return None  # Incomplete pairings must never become a candidate.
        i = min(int(np.searchsorted(np.cumsum(row_mass), rng.random()*total, side='right')), len(w)-1)
        mass = float(w[i].sum())
        if mass <= 0:
            return None
        j = min(int(np.searchsorted(np.cumsum(w[i]), rng.random()*mass, side='right')), w.shape[1]-1)
        pairs.append((i,j))
        row_mass -= w[:,j]
        w[:,j] = 0
        w[i,:] = 0
        row_mass[i] = 0
        if odd:
            row_mass -= w[:,i]
            w[:,i] = 0
            w[j,:] = 0
            row_mass[j] = 0
        np.maximum(row_mass, 0, out=row_mass)
    return pairs


def _aco_pairing_loop(distances, rng, deadline, ants, iterations, odd=False,
                      on_winner=None, parameters=None):
    cfg = parameters or ACO_2026_PARAMETERS
    tau = np.full(distances.shape, cfg['tau0'], dtype=float)
    best, score = None, float('inf')
    log = dict(ants_attempted=0, complete_ants=0, iterations_completed=0,
               planned_ants=ants, planned_iterations=iterations, completed=False)
    for iteration in range(iterations):
        if remaining(deadline) <= .002:
            break
        weights = _aco_probability_weights(tau, distances, cfg)
        deposits = np.zeros_like(tau)
        complete_iteration = True
        for ant in range(ants):
            log['ants_attempted'] += 1
            try:
                pairs = _aco_draw_matching(weights, rng, deadline, odd)
            except TimeoutError:
                complete_iteration = False
                break
            if pairs is None:
                continue
            value = float(sum(distances[i,j] for i,j in pairs))
            log['complete_ants'] += 1
            if value < score:
                best, score = pairs, value
                if on_winner is not None:
                    on_winner(pairs, value)
            if value > 0:
                for i,j in pairs:
                    deposits[i,j] += cfg['q']/value
        # Sections 6.3.2 then 6.3.3: all-ant deposit, THEN evaporation.
        tau = (tau + deposits) * (1-cfg['rho'])
        if not complete_iteration:
            break
        log['iterations_completed'] += 1
    log.update(completed=log['iterations_completed']==iterations, best_pairing_cost=score if best is not None else None)
    return best, log


def _aco_shortest_path_network(oracle, deadline):
    """Exact Dijkstra matrices and explicit physical arc predecessors.

    Parallel travel arcs use the cheapest permitted arc, never summed CSR
    weights. Each reconstructed path retains its original travel/source ID.
    """
    from scipy.sparse.csgraph import dijkstra
    p = oracle.prep
    best = {}
    for a,(u,v,c) in enumerate(zip(p.travel_tail,p.travel_head,p.travel_scaled)):
        key = (int(u),int(v))
        if key not in best or int(c) < best[key][0]:
            best[key] = (int(c),a)
    if remaining(deadline) <= .002:
        raise TimeoutError('ACO shortest path preparation exceeded budget')
    keys = list(best)
    matrix = coo_matrix(([best[k][0] for k in keys],
                        ([k[0] for k in keys],[k[1] for k in keys])),shape=(p.n,p.n)).tocsr()
    distance, predecessor = dijkstra(matrix,directed=True,return_predecessors=True)
    if remaining(deadline) <= .002:
        raise TimeoutError('ACO Dijkstra exceeded budget; late results discarded')
    def path(source,target):
        source,target = int(source),int(target)
        arcs = []
        node = target
        for _ in range(p.n+1):
            if node == source:
                arcs.reverse()
                return arcs
            previous = int(predecessor[source,node])
            if previous < 0:
                raise ValueError('ACO pairing selected an unreachable destination')
            arcs.append(best[(previous,node)][1])
            node = previous
        raise ValueError('Cyclic Dijkstra predecessor chain')
    return distance, path


def _aco_sgs(oracle, directed_counts, undirected_copies, rng, deadline):
    """Section 6.4/Figure 11, followed by a real conservation check.

    Positive nodes with no remaining undirected incident edge, or a nonzero
    final imbalance, are failures. We never invent an edge or use exact MCF to
    rescue such a graph. Even vertex degree alone does not prove feasibility.
    """
    p = oracle.prep
    counts = directed_counts.copy()
    imbalance = np.zeros(p.n,dtype=np.int64)
    np.add.at(imbalance,p.travel_tail,-counts)
    np.add.at(imbalance,p.travel_head,counts)
    incident = [set() for _ in range(p.n)]
    for q,j in enumerate(undirected_copies):
        incident[int(p.edge_u[j])].add(q)
        incident[int(p.edge_v[j])].add(q)
    pending = set(range(len(undirected_copies)))
    offset = len(oracle.ins.directed)
    while pending:
        if remaining(deadline) <= .001:
            return None,'sgs_budget_capped'
        positives = np.flatnonzero(imbalance>0)
        if len(positives):
            highest = imbalance[positives].max()
            eligible = positives[imbalance[positives]==highest]
            u = int(rng.choice(eligible))
            if not incident[u]:
                return None,'positive_node_without_undirected_edge'
        else:
            eligible = [v for v,items in enumerate(incident) if items]
            u = int(rng.choice(eligible))
        neighbors = {}
        for q in sorted(incident[u]):
            j = undirected_copies[q]
            a,b = int(p.edge_u[j]),int(p.edge_v[j])
            v = b if a==u else a
            neighbors.setdefault(v,[]).append(q)
        lowest = min(int(imbalance[v]) for v in neighbors)
        targets = sorted(v for v in neighbors if imbalance[v]==lowest)
        v = int(rng.choice(targets))
        q = int(rng.choice(neighbors[v]))
        j = undirected_copies[q]
        forward = int(p.edge_u[j])==u
        counts[offset+2*j+(0 if forward else 1)] += 1
        imbalance[u] -= 1
        imbalance[v] += 1
        incident[u].remove(q)
        if v != u:
            incident[v].remove(q)
        pending.remove(q)
    if np.any(imbalance):
        return None,'nonzero_final_imbalance'
    try:
        sol = _grasp_candidate_from_route(oracle,counts,'published_aco_mcpp_2026_sgs')
        sol.mcf_engine = 'published_ACO_SGS_path_augmentation_no_flow_repair'
        oracle.audit(sol)
    except ValueError as exc:
        return None,'route_audit_rejected: '+str(exc)
    return sol,'valid'


def run_aco_mcpp_2026(oracle, deadline, seed, writer, stats):
    """Checked paper pipeline; construction failures are observable outcomes.

    Budget allocation truncates the first colony to retain time for the second
    colony and SGS, just as classical branch prefixes are budgeted. Complete
    planned loops are tracked separately from valid prefix incumbents.
    """
    streams = [np.random.default_rng(s) for s in np.random.SeedSequence(seed).spawn(3)]
    cfg = ACO_2026_PARAMETERS
    stats.update(published_algorithm_completed=False, aco_parameters=cfg,
                 aco_sgs_attempts=0, aco_sgs_valid=0, aco_sgs_rejections={},
                 aco_exact_repair_calls=0, aco_scope='checked_independent_port_with_disclosed_interpretations')
    p = oracle.prep
    stats['aco_preparation_start_seconds'] = time.monotonic()-writer.start
    try:
        distances,path = _aco_shortest_path_network(oracle,deadline)
    except TimeoutError:
        stats['published_termination'] = 'budget_before_pairing_matrices'
        atomic_json(writer.folder/'stage_metrics.json',stats)
        return writer,stats
    stats['aco_preparation_end_seconds'] = time.monotonic()-writer.start
    dcounts = np.zeros(len(p.travel_scaled),dtype=np.int64)
    dcounts[:len(oracle.ins.directed)] = 1
    imbalance = np.zeros(p.n,dtype=np.int64)
    np.add.at(imbalance,p.travel_tail,-dcounts)
    np.add.at(imbalance,p.travel_head,dcounts)
    positive = np.repeat(np.flatnonzero(imbalance>0),imbalance[imbalance>0])
    negative = np.repeat(np.flatnonzero(imbalance<0),-imbalance[imbalance<0])
    stats['aco_imbalance_units'] = len(positive)
    # Convert the supplied centimetre road costs back to metres for ACO weights;
    # integer traversal costs and the reported objective remain centimetres.
    metric_divisor = float(oracle.ins.metadata.get('cost_units_per_meter',1.) or 1.)
    stats['aco_heuristic_cost_divisor'] = metric_divisor
    if len(positive):
        imb_end = time.monotonic()+max(.002,remaining(deadline)*.25)
        pairings,log = _aco_pairing_loop(distances[np.ix_(positive,negative)]/metric_divisor,
              streams[0],imb_end,cfg['imb_ants'],cfg['imb_iterations'])
        stats['aco_imb_loop'] = log
        if pairings is None:
            stats['published_termination'] = 'no_complete_imbalance_ant'
            atomic_json(writer.folder/'stage_metrics.json',stats)
            return writer,stats
        for i,j in pairings:
            for a in path(positive[i],negative[j]):
                dcounts[a] += 1
    else:
        stats['aco_imb_loop'] = {'completed':True,'complete_ants':0,'iterations_completed':0}
    degree = np.zeros(p.n,dtype=np.int64)
    np.add.at(degree,p.travel_tail,dcounts)
    np.add.at(degree,p.travel_head,dcounts)
    np.add.at(degree,p.edge_u,1)
    np.add.at(degree,p.edge_v,1)
    odds = np.flatnonzero(degree%2)
    stats['aco_odd_nodes'] = len(odds)
    offset = len(oracle.ins.directed)
    def winner(pairs,score):
        directed = dcounts.copy()
        undirected = list(range(p.m))
        for i,j in pairs:
            for a in path(odds[i],odds[j]):
                if a < offset:
                    directed[a] += 1
                else:
                    undirected.append((a-offset)//2)
        stats['aco_sgs_attempts'] += 1
        sol,status = _aco_sgs(oracle,directed,undirected,streams[2],deadline-.03)
        if sol is not None and remaining(deadline)>0:
            stats['aco_sgs_valid'] += 1
            stats['aco_last_winner_valid'] = True
            writer.commit(sol,'published_aco_2026_checked_winner_prefix',stats)
        else:
            stats['aco_last_winner_valid'] = False
            reasons = stats['aco_sgs_rejections']
            reasons[status] = reasons.get(status,0)+1
        atomic_json(writer.folder/'stage_metrics.json',stats)
    if len(odds):
        odd_distances = distances[np.ix_(odds,odds)]/metric_divisor
        np.fill_diagonal(odd_distances,np.inf)  # Enforce the stated no-self-pair constraint.
        pairings,log = _aco_pairing_loop(odd_distances,streams[1],deadline-.06,
                       cfg['odd_ants'],cfg['odd_iterations'],odd=True,on_winner=winner)
        stats['aco_odd_loop'] = log
        if pairings is not None and remaining(deadline)>.01:
            winner(pairings,log['best_pairing_cost'])
    else:
        stats['aco_odd_loop'] = {'completed':True,'complete_ants':0,'iterations_completed':0}
        winner([],0.)
    stats['published_algorithm_completed'] = bool(stats['aco_imb_loop']['completed']
                    and stats['aco_odd_loop']['completed'] and stats.get('aco_last_winner_valid',False))
    stats['published_termination'] = ('planned_loops_and_valid_route' if stats['published_algorithm_completed']
              else 'audited_prefix_at_budget' if writer.best is not None
              else 'no_audited_feasible_construction')
    atomic_json(writer.folder/'stage_metrics.json',stats)
    return writer,stats


def execute_published_method(task, writer, deadline, stats):
    method = task['method']
    stats['published_algorithm_completed'] = False
    if writer.ins.optional_travel:
        raise ValueError('Published pure MCPP comparators require every link to be mandatory')
    if method == 'grasp_mcpp_2002':
        return run_grasp_2002(writer.oracle, deadline, task['seed'], writer, stats)
    if method == 'aco_mcpp_2026':
        return run_aco_mcpp_2026(writer.oracle, deadline, task['seed'], writer, stats)

    def record(sol, phase):
        writer.commit(sol, phase, stats)

    cfg = SearchConfig(seed=task['seed'], cost_scale=COST_SCALE,
                       budget_seconds=max(.001, remaining(deadline)))
    try:
        outcome = (search_modified_mixed_1999(writer.ins, cfg, record)
                   if method == 'modified_mixed' else
                   search_frederickson_1979(writer.ins, cfg, record))
    except TimeoutError:
        stats['published_termination'] = 'budget_before_all_published_steps_completed'
        atomic_json(writer.folder/'stage_metrics.json', stats)
        return writer, stats
    stats.update({k: v for k, v in outcome.metrics.items() if k != 'audit'})
    stats['published_algorithm_completed'] = True
    writer.commit(outcome.solution, 'published_journal_algorithm_complete', stats)
    atomic_json(writer.folder/'stage_metrics.json', stats)
    return writer, stats


# RNPS: residual network search with binary parity repair.
# Successive shortest paths, min-cost-flow LPs and branching are established
# techniques. Their use here is an experimental research design, not a claim
# that these mathematical building blocks were invented in this project.

class ResidualNetwork:
    """Exact two-unit recourse updates for single edges and service paths.

    If a currently serviced path is oriented s -> t, reversing every service
    edge changes mandatory balance by -2 at s and +2 at t. The optimal extra
    flow therefore changes by a minimum-cost two-unit s -> t residual flow.
    Its cost is the EXACT change in fixed-orientation optimum, including
    deletion of existing duplicates. Negative reverse arcs have capacity f[a].
    Sending both units down the first path without checking capacity is wrong.
    """
    def __init__(self, oracle, stats, cold=False):
        self.oracle = oracle
        self.stats = stats
        self.cold = cold
        p = oracle.prep
        self.n = p.n
        self.adj = [[] for _ in range(p.n)]
        for a, (u, v, c) in enumerate(zip(p.travel_tail, p.travel_head, p.travel_scaled)):
            u, v, c = int(u), int(v), int(c)
            self.adj[u].append((v, c, a, 1))
            self.adj[v].append((u, -c, a, -1))

    def two_units(self, center, source, target, deadline=float('inf'), improve_only=False):
        """Return (delta_or_bound, flow_changes, potential, exact).

        Reduced cost is c - pi[u] + pi[v]. Dijkstra remains valid after each
        augmentation with pi' = pi - min(dist, dist[target]). The distance cap
        makes an early-target Dijkstra sufficient for a globally feasible pi'.
        In improve_only mode a NONNEGATIVE lower bound may reject a move;
        such a return is explicitly marked exact=False, never used as a route.
        """
        self.stats['residual_evaluations'] += 1
        if source == target:
            return 0, {}, center.dual_potential.copy(), True
        flow = list(map(int, center.extra_counts))
        pi = list(map(int, center.dual_potential))
        changes = {}
        delta = 0
        needed = 2
        inf = 10**30
        while needed:
            if time.monotonic() >= deadline:
                raise TimeoutError('Two-unit residual repair deadline')
            dist = [inf] * self.n
            parent = [None] * self.n
            dist[source] = 0
            queue = [(0, source)]
            pops = 0
            while queue:
                du, u = heapq.heappop(queue)
                if du != dist[u]:
                    continue
                pops += 1
                if pops % 128 == 0 and time.monotonic() >= deadline:
                    raise TimeoutError('Residual shortest-path deadline')
                # Marginal augmentation costs are nondecreasing. If already
                # no cheaper than zero on the FIRST unit, two units cannot help.
                if improve_only and needed == 2 and du + pi[source] - pi[target] >= 0:
                    self.stats['residual_early_rejections'] += 1
                    self.stats['residual_shortest_paths'] += 1
                    return 2 * (du + pi[source] - pi[target]), {}, None, False
                if u == target:
                    break
                for v, c, a, sign in self.adj[u]:
                    if sign < 0 and flow[a] == 0:
                        continue
                    reduced = c - pi[u] + pi[v]
                    if reduced < 0:
                        raise AssertionError('Dijkstra was given an infeasible residual dual')
                    value = du + reduced
                    if value < dist[v]:
                        dist[v] = value
                        parent[v] = (u, a, sign, c)
                        heapq.heappush(queue, (value, v))
            self.stats['residual_shortest_paths'] += 1
            if parent[target] is None:
                raise ValueError('Service path reversal has no feasible residual repair')
            path = []
            at = target
            amount = needed
            path_cost = 0
            while at != source:
                u, a, sign, c = parent[at]
                path.append((a, sign))
                if sign < 0:
                    amount = min(amount, flow[a])
                path_cost += c
                at = u
            cap = dist[target]
            pi = [q - min(d, cap) for q, d in zip(pi, dist)]
            for a, sign in path:
                flow[a] += sign * amount
                changes[a] = changes.get(a, 0) + sign * amount
            delta += amount * path_cost
            needed -= amount
        if time.monotonic() >= deadline:
            raise TimeoutError('Residual result completed after phase deadline')
        return delta, changes, np.asarray(pi, dtype=np.int64), True

    def repair(self, center, indices, source, target, deadline, improve_only=True):
        if not self.cold:
            return self.two_units(center, source, target, deadline, improve_only)
        self.stats['cold_repair_evaluations'] += 1
        x = center.orientation.copy()
        x[indices] = 1 - x[indices]
        sol = self.oracle.evaluate(x, deadline, use_cache=False)
        diff = sol.extra_counts - center.extra_counts
        changes = {int(a): int(diff[a]) for a in np.flatnonzero(diff)}
        return (sol.scaled_extra_cost - center.scaled_extra_cost, changes,
                sol.dual_potential.copy(), True)

    def candidate(self, center, indices, result):
        delta, changes, pi, exact = result
        if not exact:
            raise ValueError('A rejection bound cannot become a candidate')
        x = center.orientation.copy()
        x[indices] = 1 - x[indices]
        f = center.extra_counts.copy()
        for a, change in changes.items():
            f[a] += change
        sol = candidate_from_arrays(self.oracle, x, f, 'residual_two_unit_recourse')
        sol.dual_potential = pi
        if sol.scaled_extra_cost != center.scaled_extra_cost + int(delta):
            raise AssertionError('Residual delta disagrees with reconstructed route cost')
        self.oracle.audit(sol, dual=True)
        return sol


def network_orientation_relaxation(oracle, base, fixed=None, region=None):
    """Capacity-two service-switch LP; exact network bound for a binary face.

    Relative to base, service-edge reversal is a zero-cost reverse arc z with
    capacity 2. z=0/2 means unchanged/flipped; z=1 is a HALF orientation and
    never an admissible postman tour. Relaxing that parity condition yields a
    min-cost flow, hence a valid LP lower bound. Integer flow is sufficient
    because the network matrix is totally unimodular; it does not make z=1
    a feasible binary orientation. fixed[j]=0/1 fixes the relative flip.
    """
    p = oracle.prep
    fixed = fixed or {}
    region = np.arange(p.m, dtype=np.int64) if region is None else np.asarray(region, dtype=np.int64)
    if len(np.unique(region)) != len(region) or np.any(region < 0) or np.any(region >= p.m):
        raise ValueError('Invalid orientation region')
    if not set(fixed) <= set(map(int, region)) or any(v not in (0, 1) for v in fixed.values()):
        raise ValueError('Invalid relative binary fixes')
    free = np.asarray([j for j in region if int(j) not in fixed], dtype=np.int64)
    x = np.asarray(base, dtype=np.int8).copy()
    for j, flip in fixed.items():
        if flip:
            x[j] = 1 - x[j]
    supply = -p.mandatory_balance(x)
    tail = np.where(base == 1, p.edge_v, p.edge_u)[free]
    head = np.where(base == 1, p.edge_u, p.edge_v)[free]
    solver = min_cost_flow.SimpleMinCostFlow()
    # Cycle removal gives an optimum with physical-arc transit bounded by
    # N_required + 2*m. The extra slack avoids binding a forward dual arc.
    safe_capacity = oracle.ins.n_required + 2 * p.m + 1
    solver.add_arcs_with_capacity_and_unit_cost(
        p.travel_tail, p.travel_head,
        np.full(len(p.travel), safe_capacity, dtype=np.int64), p.travel_scaled)
    if len(free):
        solver.add_arcs_with_capacity_and_unit_cost(
            tail, head, np.full(len(free), 2, dtype=np.int64),
            np.zeros(len(free), dtype=np.int64))
    solver.set_nodes_supplies(np.arange(p.n, dtype=np.int64), supply)
    if solver.solve() != solver.OPTIMAL:
        raise RuntimeError('Network relaxation was not solved optimally')
    f = np.asarray(solver.flows(np.arange(len(p.travel), dtype=np.int64)), dtype=np.int64)
    z = np.asarray(solver.flows(len(p.travel) + np.arange(len(free), dtype=np.int64)), dtype=np.int64)
    x[free[z == 2]] = 1 - x[free[z == 2]]
    return int(solver.optimal_cost()), x, f, free[z == 1]


def network_parity_face(oracle, center, region, deadline, rng, writer=None,
                        stats=None, max_nodes=128):
    """Exact branching on z=1, interrupted safely by node/time budgets.

    The active queue covers all unexplored orientation assignments. Parent
    bounds remain valid for both children. Only an exhausted queue certifies
    this face. A proper subset of variables yields a CONDITIONAL certificate.
    """
    stats = stats if stats is not None else {}
    region = np.asarray(region, dtype=np.int64)
    queue = [(0, 0, {})]
    serial = 0
    nodes = 0
    best = center
    base = center.orientation.copy()
    root_half = None
    while queue and nodes < max_nodes and remaining(deadline) > 0.004:
        parent_lb, token, fixed = heapq.heappop(queue)
        if parent_lb >= best.scaled_extra_cost:
            continue
        bound, rounded, f, half = network_orientation_relaxation(oracle, base, fixed, region)
        nodes += 1
        stats['network_lp_solves'] = stats.get('network_lp_solves', 0) + 1
        if root_half is None:
            root_half = len(half)
        if time.monotonic() >= deadline:
            # This popped region still belongs to the unfinished domain.
            heapq.heappush(queue, (parent_lb, token, fixed))
            break
        if bound >= best.scaled_extra_cost:
            continue
        if not len(half):
            candidate = candidate_from_arrays(oracle, rounded, f, 'integral_parity_network_leaf')
            candidate.dual_potential = oracle._dual(f)
            oracle.audit(candidate, dual=True)
            if time.monotonic() >= deadline:
                heapq.heappush(queue, (bound, token, fixed))
                break
            if candidate.total_cost < best.total_cost:
                best = candidate
                if writer:
                    writer.commit(best, 'network_parity_leaf', stats)
            continue
        # Two opposite root roundings are HEURISTIC feasible repairs. They do
        # not alter the LP bound or fix the half-switches in the active tree.
        if nodes == 1:
            for reverse_half in (False, True):
                trial = rounded.copy()
                if reverse_half:
                    trial[half] = 1 - trial[half]
                try:
                    candidate = oracle.evaluate(trial, deadline)
                except TimeoutError:
                    break
                if candidate.total_cost < best.total_cost:
                    best = candidate
                    if writer:
                        writer.commit(best, 'network_half_rounding', stats)
        costs = np.asarray([oracle.ins.undirected[int(j)].cost for j in half], dtype=float)
        j = int(half[np.argmax(costs + rng.random(len(half)) * 0.01)])
        for flip in (0, 1):
            child = dict(fixed)
            child[j] = flip
            serial += 1
            heapq.heappush(queue, (bound, serial, child))
    certified = not queue
    lower = best.scaled_extra_cost if certified else min(best.scaled_extra_cost,
                                                        min(q[0] for q in queue))
    log = {'indices': region.tolist(), 'fixed_orientation_sha256': hashlib.sha256(base.tobytes()).hexdigest(),
           'network_nodes': nodes, 'root_half_switches': root_half,
           'restricted_lower_bound_scaled': int(lower),
           'restricted_upper_bound_scaled': int(best.scaled_extra_cost),
           'conditionally_certified': certified, 'active_nodes': len(queue),
           'certificate_scope': 'complete orientation domain' if len(region) == oracle.prep.m
                                else 'this fixed-outside binary face only'}
    return best, log


def residual_descent(oracle, current, deadline, rng, engine, writer=None, stats=None):
    """Dual-filtered first-improvement descent with exact residual deltas."""
    stats = stats if stats is not None else engine.stats
    p = oracle.prep
    complete = False
    while remaining(deadline) > 0.004:
        tail = np.where(current.orientation == 1, p.edge_u, p.edge_v)
        head = np.where(current.orientation == 1, p.edge_v, p.edge_u)
        lower = 2 * (current.dual_potential[tail] - current.dual_potential[head])
        promising = np.flatnonzero(lower < 0)
        stats['dual_filtered_edges'] += int(p.m - len(promising))
        order = promising[np.lexsort((rng.random(len(promising)), lower[promising]))]
        improved = False
        interrupted = False
        for j in order:
            try:
                result = engine.repair(current, [int(j)], int(tail[j]), int(head[j]), deadline)
            except TimeoutError:
                interrupted = True
                break
            if result[3] and result[0] < 0:
                candidate = engine.candidate(current, [int(j)], result)
                if time.monotonic() >= deadline:
                    interrupted = True
                    break
                current = candidate
                stats['single_edge_improvements'] += 1
                if writer:
                    writer.commit(current, 'exact_residual_single_edge', stats)
                improved = True
                break
        stats['residual_scans'] += 1
        if not improved:
            complete = not interrupted
            break
    if complete:
        stats['completed_one_flip_local_scans'] += 1
    return current, complete


def residual_path_search(oracle, current, deadline, rng, engine, stats, writer=None):
    """Evaluate multi-edge service paths without repeated global recourse solves."""
    p = oracle.prep
    tail = np.where(current.orientation == 1, p.edge_u, p.edge_v)
    head = np.where(current.orientation == 1, p.edge_v, p.edge_u)
    adj = [[] for _ in range(p.n)]
    for j, (u, v) in enumerate(zip(tail, head)):
        adj[int(u)].append((int(v), j))
    sources = list(map(int, np.flatnonzero([bool(a) for a in adj])))
    rng.shuffle(sources)
    checks = 0
    for source in sources:
        paths = deque([(source, [], {source})])
        # Different paths with the same endpoints have the same optimal delta.
        # Keep only one representative per endpoint for this fixed center.
        tested_targets = set()
        while paths and checks < RNPS_CHAIN_CHECKS and remaining(deadline) > 0.004:
            u, edges, visited = paths.popleft()
            for target, j in adj[u]:
                if target in visited:
                    continue
                chain = edges + [j]
                if (len(chain) >= 2 and target not in tested_targets and
                        current.dual_potential[source] < current.dual_potential[target]):
                    tested_targets.add(target)
                    try:
                        result = engine.repair(current, chain, source, target, deadline)
                    except TimeoutError:
                        return current
                    checks += 1
                    stats['chain_evaluations'] += 1
                    if result[3] and result[0] < 0:
                        candidate = engine.candidate(current, chain, result)
                        if time.monotonic() >= deadline:
                            return current
                        stats['chain_improvements'] += 1
                        stats['reversed_chain_edges'] += len(chain)
                        if writer:
                            writer.commit(candidate, 'exact_residual_service_chain', stats)
                        return candidate
                if len(chain) < RNPS_CHAIN_LENGTH:
                    paths.append((target, chain, visited | {target}))
        if checks >= RNPS_CHAIN_CHECKS or remaining(deadline) <= 0.004:
            break
    return current


def select_network_region(oracle, current, k, rng):
    """Connected orientation regions plus occasional dispersed joint regions."""
    p = oracle.prep
    k = min(int(k), p.m)
    if k == p.m:
        return np.arange(p.m, dtype=np.int64)
    tail = np.where(current.orientation == 1, p.edge_u, p.edge_v)
    head = np.where(current.orientation == 1, p.edge_v, p.edge_u)
    tension = np.abs(current.dual_potential[tail] - current.dual_potential[head]).astype(float)
    off = len(oracle.ins.directed)
    exposure = current.extra_counts[off:off + 2 * p.m].reshape(p.m, 2).sum(axis=1).astype(float)
    score = tension / max(1., float(tension.max(initial=0))) + exposure / max(1., float(exposure.max(initial=0)))
    # Every edge retains a chance of selection; guidance is not a restriction
    # justified by a global optimality claim.
    incident = [[] for _ in range(p.n)]
    for j, (u, v) in enumerate(zip(p.edge_u, p.edge_v)):
        incident[int(u)].append(j)
        incident[int(v)].append(j)
    if rng.random() < 0.75:
        order = np.argsort(-score - rng.random(p.m) * 0.4)
        seed = int(order[int(rng.integers(min(40, p.m)))])
    else:
        seed = int(rng.integers(p.m))
    chosen = {seed}
    front = deque([int(p.edge_u[seed]), int(p.edge_v[seed])])
    while front and len(chosen) < k:
        u = front.popleft()
        neighbors = incident[u].copy()
        rng.shuffle(neighbors)
        for j in neighbors:
            if j in chosen:
                continue
            chosen.add(j)
            front.extend([int(p.edge_u[j]), int(p.edge_v[j])])
            if len(chosen) >= k:
                break
    if len(chosen) < k:
        other = np.setdiff1d(np.arange(p.m), list(chosen))
        chosen.update(map(int, rng.choice(other, size=k - len(chosen), replace=False)))
    return np.asarray(sorted(chosen), dtype=np.int64)


def _run_rnps_legacy_schedule(oracle, current, deadline, rng, writer, stats, method):
    """Network-only search; CP-SAT is used only by independent validation."""
    # Leave time for atomic diagnostics and returning to the supervised worker.
    # The reserve is part of the method's allotted budget, not extra time.
    deadline -= RNPS_FINAL_RESERVE
    p = oracle.prep
    engine = ResidualNetwork(oracle, stats, cold=(method == 'cold_repair'))
    history = []
    if method != 'without_parity' and remaining(deadline) > 0.04:
        bound, rounded, f, half = network_orientation_relaxation(oracle, current.orientation)
        stats['network_lp_solves'] += 1
        stats['global_root_half_switches'] = len(half)
        if remaining(deadline) > 0:
            writer.save_bound(bound, 'complete_capacity_two_network_relaxation')
            if not len(half):
                sol = candidate_from_arrays(oracle, rounded, f, 'integral_global_network_relaxation')
                sol.dual_potential = oracle._dual(f)
                oracle.audit(sol, dual=True)
                if remaining(deadline) > 0:
                    current = sol
                    writer.commit(sol, 'global_integral_network_optimum', stats)
                    stats.update(global_optimal=True, global_status='PROVEN_INTEGRAL_GLOBAL_NETWORK_LP')
                    writer.save_bound(sol.scaled_extra_cost, 'integral_complete_network_relaxation')
                    return current
            else:
                try:
                    sol = oracle.evaluate(rounded, deadline)
                except TimeoutError:
                    sol = None
                if sol is not None and sol.total_cost < current.total_cost:
                    current = sol
                    writer.commit(sol, 'global_network_rounding_seed', stats)
    # Preserved for the search-scheduling ablation, not a journal comparator.
    stats['phase_initial_descent_calls'] = 1
    stats['schedule_policy'] = 'v19_unreserved_initial_descent'
    atomic_json(writer.folder / 'stage_metrics.json', stats)
    initial_started = time.monotonic()
    current, _ = residual_descent(oracle, current, deadline, rng, engine, writer, stats)
    stats['phase_initial_descent_seconds'] = time.monotonic() - initial_started
    rounds = 0
    while p.m and remaining(deadline) > 0.06:
        old_cost = current.total_cost
        phase_deadline = min(deadline - 0.025, time.monotonic() + RNPS_PHASE_SECONDS)
        if rounds % 4 == 0 and method != 'without_chain':
            stats['phase_chain_calls'] = stats.get('phase_chain_calls', 0) + 1
            current = residual_path_search(oracle, current, phase_deadline, rng, engine, stats, writer)
        elif method != 'without_parity':
            stats['phase_parity_calls'] = stats.get('phase_parity_calls', 0) + 1
            k = min(p.m, RNPS_REGION_SIZES[rounds % len(RNPS_REGION_SIZES)])
            region = select_network_region(oracle, current, k, rng)
            current, log = network_parity_face(oracle, current, region, phase_deadline,
                                              rng, writer, stats, RNPS_FACE_NODES)
            history.append(log)
            stats['neighborhoods'] += 1
            stats['network_branch_nodes'] += log['network_nodes']
            stats['certified_neighborhoods'] += int(log['conditionally_certified'])
            if log['conditionally_certified'] and len(region) == p.m:
                stats.update(global_optimal=True, global_status='PROVEN_COMPLETE_NETWORK_PARITY_TREE')
                writer.save_bound(current.scaled_extra_cost, 'complete_orientation_network_parity_tree')
                atomic_json(writer.folder / 'neighborhoods.json', history)
                return current
        else:
            # The no-parity control spends its search allowance on chains.
            current = residual_path_search(oracle, current, phase_deadline, rng, engine, stats, writer)
        if current.total_cost < old_cost:
            stats['accepted_improvements'] += 1
            current, _ = residual_descent(
                oracle, current, min(deadline - 0.025, time.monotonic() + RNPS_DESCENT_SECONDS),
                rng, engine, writer, stats)
        rounds += 1
        if rounds % 8 == 0 and remaining(deadline) > 0.01:
            atomic_json(writer.folder / 'neighborhoods.json', history)
            atomic_json(writer.folder / 'stage_metrics.json', stats)
    stats['network_search_rounds'] = rounds
    atomic_json(writer.folder / 'neighborhoods.json', history)
    return current


def _phase_checkpoint(writer, stats, phase, before, allocated, operation):
    """Record a scheduled opportunity, its actual work and its incumbent gain.

    A start record survives a watchdog kill; it is not a completed-call claim.
    All telemetry and checkpoint I/O are charged to the same wall budget.
    """
    started = time.monotonic()
    key = 'phase_' + phase
    stats[key + '_calls'] = stats.get(key + '_calls', 0) + 1
    counters = {k: stats.get(k, 0) for k in
                ('chain_evaluations', 'residual_evaluations', 'network_lp_solves', 'joint_pair_proposals', 'joint_evaluations', 'joint_signature_hits', 'joint_screen_rejections')}
    def emit(event):
        with (writer.folder / 'schedule_events.jsonl').open('a', encoding='utf-8') as f:
            f.write(json.dumps(event, ensure_ascii=False, allow_nan=False) + '\n')
            f.flush()
    base = {'phase': phase, 'start_seconds': started - writer.start,
            'allocated_seconds': allocated, 'incumbent_before': before.total_cost}
    emit(dict(base, event='start'))
    atomic_json(writer.folder / 'stage_metrics.json', stats)
    result = operation()
    ended = time.monotonic()
    stats[key + '_completed_calls'] = stats.get(key + '_completed_calls', 0) + 1
    stats[key + '_seconds'] = stats.get(key + '_seconds', 0.0) + ended - started
    emit(dict(base, event='complete', end_seconds=ended - writer.start,
              elapsed_seconds=ended - started, incumbent_after=result.total_cost,
              gain=before.total_cost - result.total_cost,
              work={k: stats.get(k, 0) - v for k, v in counters.items()}))
    atomic_json(writer.folder / 'stage_metrics.json', stats)
    return result


def run_rnps(oracle, current, deadline, rng, writer, stats, method):
    """Reserve first search opportunities, then interleave network mechanisms.

    Mechanism-removal controls reuse each freed slot for an enabled mechanism.
    Initializer-removal controls change only initializer allocation. The two
    legacy schedule controls intentionally restore the old starvation policy.
    """
    if method in ('legacy_phase_schedule', 'legacy_both'):
        return _run_rnps_legacy_schedule(oracle, current, deadline, rng, writer, stats, method)
    deadline -= RNPS_FINAL_RESERVE
    p = oracle.prep
    engine = ResidualNetwork(oracle, stats, cold=(method == 'cold_repair'))
    stats['schedule_policy'] = 'reserved_initial_descent_then_chain_parity_descent_parity'
    stats['search_start_remaining_seconds'] = max(0., remaining(deadline))
    history = []
    if method != 'without_parity' and remaining(deadline) > .04:
        started = time.monotonic()
        bound, rounded, f, half = network_orientation_relaxation(oracle, current.orientation)
        stats['network_lp_solves'] += 1
        stats['global_root_half_switches'] = len(half)
        stats['global_relaxation_seconds'] = time.monotonic() - started
        if remaining(deadline) > 0:
            writer.save_bound(bound, 'complete_capacity_two_network_relaxation')
            if not len(half):
                sol = candidate_from_arrays(oracle, rounded, f, 'integral_global_network_relaxation')
                sol.dual_potential = oracle._dual(f)
                oracle.audit(sol, dual=True)
                if remaining(deadline) > 0:
                    current = sol
                    writer.commit(sol, 'global_integral_network_optimum', stats)
                    stats.update(global_optimal=True, global_status='PROVEN_INTEGRAL_GLOBAL_NETWORK_LP')
                    writer.save_bound(sol.scaled_extra_cost, 'integral_complete_network_relaxation')
                    atomic_json(writer.folder / 'stage_metrics.json', stats)
                    return current
            else:
                try:
                    sol = oracle.evaluate(rounded, deadline)
                except TimeoutError:
                    sol = None
                if sol is not None and sol.total_cost < current.total_cost:
                    current = sol
                    writer.commit(sol, 'global_network_rounding_seed', stats)
    slots = ['chain', 'parity', 'descent', 'parity']
    if method == 'without_chain':
        slots = ['descent' if s == 'chain' else s for s in slots]
    if method == 'without_parity':
        slots = ['chain' if s == 'parity' else s for s in slots]
    # The first descent may use at most 10% of the search window and 0.30 s.
    # It can no longer consume the entire remaining deadline on a large graph.
    allowance = min(RNPS_INITIAL_DESCENT_MAX_SECONDS,
                    max(0., remaining(deadline)) * RNPS_INITIAL_DESCENT_FRACTION)
    if p.m and allowance > .004:
        phase_end = min(deadline - .025, time.monotonic() + allowance)
        current = _phase_checkpoint(writer, stats, 'initial_descent', current, allowance,
            lambda: residual_descent(oracle, current, phase_end, rng, engine, writer, stats)[0])
    rounds = 0
    while p.m and remaining(deadline) > .06:
        phase = slots[rounds % len(slots)]
        allowance = min(RNPS_DESCENT_SECONDS if phase == 'descent' else RNPS_PHASE_SECONDS,
                        max(.005, (remaining(deadline) - .025) / 2))
        phase_end = min(deadline - .025, time.monotonic() + allowance)
        old_cost = current.total_cost
        if phase == 'chain':
            current = _phase_checkpoint(writer, stats, phase, current, allowance,
                lambda: residual_path_search(oracle, current, phase_end, rng, engine, stats, writer))
        elif phase == 'descent':
            current = _phase_checkpoint(writer, stats, phase, current, allowance,
                lambda: residual_descent(oracle, current, phase_end, rng, engine, writer, stats)[0])
        else:
            k = min(p.m, RNPS_REGION_SIZES[rounds % len(RNPS_REGION_SIZES)])
            region = select_network_region(oracle, current, k, rng)
            holder = {}
            def parity_operation():
                sol, log = network_parity_face(oracle, current, region, phase_end,
                                              rng, writer, stats, RNPS_FACE_NODES)
                holder['log'] = log
                return sol
            current = _phase_checkpoint(writer, stats, phase, current, allowance, parity_operation)
            log = holder['log']
            history.append(log)
            stats['neighborhoods'] += 1
            stats['network_branch_nodes'] += log['network_nodes']
            stats['certified_neighborhoods'] += int(log['conditionally_certified'])
            if log['conditionally_certified'] and len(region) == p.m:
                stats.update(global_optimal=True, global_status='PROVEN_COMPLETE_NETWORK_PARITY_TREE')
                writer.save_bound(current.scaled_extra_cost, 'complete_orientation_network_parity_tree')
                stats['network_search_rounds'] = rounds + 1
                atomic_json(writer.folder / 'neighborhoods.json', history)
                atomic_json(writer.folder / 'stage_metrics.json', stats)
                return current
        if current.total_cost < old_cost:
            stats['accepted_improvements'] += 1
        rounds += 1
        stats['network_search_rounds'] = rounds
        if rounds % 8 == 0:
            atomic_json(writer.folder / 'neighborhoods.json', history)
    stats['network_search_rounds'] = rounds
    atomic_json(writer.folder / 'neighborhoods.json', history)
    atomic_json(writer.folder / 'stage_metrics.json', stats)
    return current


# ----------------- V21 coupled service-path experiments -----------------
CPR_POOL_SIZE = 96
CPR_POOL_EXPANSIONS = 768
CPR_ENDPOINT_REPRESENTATIVES = 2
CPR_PAIR_CHECKS = 2048
CPR_PHASE_SECONDS = 0.18
CPR_METHODS = ('cprnps', 'cprnps_no_joint', 'cprnps_no_screen',
               'cprnps_no_signature', 'cprnps_cold_joint')


@dataclass(frozen=True)
class ServicePath:
    source: int
    target: int
    edges: tuple[int, ...]


def validate_service_bundle(oracle, center, paths):
    """Only currently directed, simple, edge-disjoint service paths are legal."""
    p = oracle.prep
    tail = np.where(center.orientation == 1, p.edge_u, p.edge_v)
    head = np.where(center.orientation == 1, p.edge_v, p.edge_u)
    used = set()
    for path in paths:
        if not path.edges or path.source == path.target:
            raise ValueError('A bundle path must be nonempty and open')
        at = path.source
        seen = {at}
        for j in path.edges:
            if j < 0 or j >= p.m or j in used:
                raise ValueError('Bundle service edges must be valid and disjoint')
            if int(tail[j]) != at or int(head[j]) in seen:
                raise ValueError('Bundle path is not a current directed simple service path')
            used.add(j)
            at = int(head[j])
            seen.add(at)
        if at != path.target:
            raise ValueError('Declared bundle endpoint differs from its edge sequence')
    return tuple(sorted(used))


def bundle_signature(paths):
    """Sparse change in extra-flow supply, using outflow-minus-inflow incidence."""
    supply = defaultdict(int)
    for path in paths:
        supply[path.source] += 2
        supply[path.target] -= 2
    return tuple((v, supply[v]) for v in sorted(supply) if supply[v])


def bundle_dual_bound(center, paths):
    return sum(int(center.dual_potential[v]) * q for v, q in bundle_signature(paths))


def repair_service_bundle(oracle, center, paths, deadline=float('inf'),
                          stats=None, cold=False, screen=True, validated=False):
    """Exact joint recourse, or an explicitly marked nonnegative rejection bound.

    Intermediate nonimproving orientations are permitted only in local memory.
    Later paths use the MODIFIED flow, reverse capacities and dual potential.
    Summing independent original-state deltas would give the wrong joint cost.
    The underlying residual reoptimization and dual bound are classical results.
    """
    stats = stats if stats is not None else rnps_metric_defaults()
    if not validated:
        oracle.audit(center, dual=True)
    indices = validate_service_bundle(oracle, center, paths)
    bound = bundle_dual_bound(center, paths)
    if screen and bound >= 0:
        stats['joint_screen_rejections'] = stats.get('joint_screen_rejections', 0) + 1
        return bound, {}, None, False
    if remaining(deadline) <= .004:
        raise TimeoutError('Joint repair deadline')
    stats['joint_evaluations'] = stats.get('joint_evaluations', 0) + 1
    if cold:
        x = center.orientation.copy()
        x[list(indices)] = 1 - x[list(indices)]
        sol = oracle.evaluate(x, deadline, use_cache=False)
        diff = sol.extra_counts - center.extra_counts
        stats['joint_cold_solves'] = stats.get('joint_cold_solves', 0) + 1
        return (sol.scaled_extra_cost - center.scaled_extra_cost,
                {int(a): int(diff[a]) for a in np.flatnonzero(diff)},
                sol.dual_potential.copy(), True)
    engine = ResidualNetwork(oracle, stats)
    state = copy.copy(center)
    state.orientation = center.orientation.copy()
    state.extra_counts = center.extra_counts.copy()
    state.dual_potential = center.dual_potential.copy()
    changes = defaultdict(int)
    delta = 0
    for path in paths:
        part, updates, pi, exact = engine.two_units(
            state, path.source, path.target, deadline, improve_only=False)
        if not exact:
            raise AssertionError('A partial lower bound entered a joint repair')
        for a, q in updates.items():
            state.extra_counts[a] += q
            changes[a] += q
        state.orientation[list(path.edges)] = 1 - state.orientation[list(path.edges)]
        delta += int(part)
        state.scaled_extra_cost = int(center.scaled_extra_cost) + delta
        state.extra_cost = state.scaled_extra_cost / COST_SCALE
        state.total_cost = oracle.ins.mandatory_cost + state.extra_cost
        state.dual_potential = pi
    if time.monotonic() >= deadline:
        raise TimeoutError('Joint result completed after its phase deadline')
    return delta, {a: q for a, q in changes.items() if q}, state.dual_potential, True


def coupled_path_pool(oracle, center, rng, deadline):
    """A bounded diverse pool; sampling does not certify neighborhood exhaustion."""
    p = oracle.prep
    if not p.m:
        return []
    tail = np.where(center.orientation == 1, p.edge_u, p.edge_v)
    head = np.where(center.orientation == 1, p.edge_v, p.edge_u)
    adjacency = [[] for _ in range(p.n)]
    for j, (u, v) in enumerate(zip(tail, head)):
        adjacency[int(u)].append((int(v), j))
    # Include both small dual bounds and random alternatives. Individual exact
    # improvement is deliberately NOT a prerequisite for entering this pool.
    lower = 2 * (center.dual_potential[tail] - center.dual_potential[head])
    priority = np.argsort(lower + rng.random(p.m) * .01).tolist()
    random_order = rng.permutation(p.m).tolist()
    order = []
    selected = set()
    for a, b in zip(priority, random_order):
        for j in (a, b):
            if j not in selected:
                selected.add(j)
                order.append(j)
        if len(order) >= CPR_POOL_SIZE:
            break
    pool = []
    endpoint_count = defaultdict(int)
    expansions = 0
    for j in order:
        source = int(tail[j])
        target = int(head[j])
        if source == target:
            continue
        queue = deque([(target, (j,), frozenset((source, target)))])
        while queue and expansions < CPR_POOL_EXPANSIONS:
            if remaining(deadline) <= .004:
                return pool
            at, edges, visited = queue.popleft()
            expansions += 1
            key = (source, at)
            if endpoint_count[key] < CPR_ENDPOINT_REPRESENTATIVES:
                endpoint_count[key] += 1
                pool.append(ServicePath(source, at, edges))
                if len(pool) >= CPR_POOL_SIZE:
                    return pool
            if len(edges) < RNPS_CHAIN_LENGTH:
                for v, edge in adjacency[at]:
                    if v not in visited:
                        queue.append((v, edges + (edge,), visited | {v}))
    return pool


def coupled_path_search(oracle, center, deadline, rng, stats, writer=None,
                        method='cprnps'):
    """Search four-terminal joint moves using exact shared-network recourse."""
    oracle.audit(center, dual=True)
    pool = coupled_path_pool(oracle, center, rng, deadline)
    stats['joint_pool_paths'] = stats.get('joint_pool_paths', 0) + len(pool)
    screen = method != 'cprnps_no_screen'
    cache_enabled = method != 'cprnps_no_signature'
    cold = method == 'cprnps_cold_joint'
    pairs = []
    footprints = [frozenset(path.edges) for path in pool]
    for i, first in enumerate(pool):
        for j in range(i + 1, len(pool)):
            if remaining(deadline) <= .004:
                return center
            second = pool[j]
            # Four distinct terminals ensure this joint imbalance cannot equal
            # the two-terminal imbalance of one service-path reversal.
            if len({first.source, first.target, second.source, second.target}) != 4:
                continue
            if not footprints[i].isdisjoint(footprints[j]):
                continue
            lower = bundle_dual_bound(center, (first, second))
            if screen and lower >= 0:
                stats['joint_screen_rejections'] = stats.get('joint_screen_rejections', 0) + 1
                continue
            pairs.append((lower, float(rng.random()), i, j))
    pairs.sort()
    # This cache exists for ONE immutable center only. It is discarded after
    # an accepted move and at phase end; no stale changes cross center states.
    signature_cache = {}
    engine = ResidualNetwork(oracle, stats)
    for lower, _, i, j in pairs[:CPR_PAIR_CHECKS]:
        if remaining(deadline) <= .004:
            break
        paths = (pool[i], pool[j])
        signature = bundle_signature(paths)
        stats['joint_pair_proposals'] = stats.get('joint_pair_proposals', 0) + 1
        if cache_enabled and signature in signature_cache:
            result = signature_cache[signature]
            stats['joint_signature_hits'] = stats.get('joint_signature_hits', 0) + 1
        else:
            try:
                result = repair_service_bundle(oracle, center, paths, deadline,
                    stats, cold=cold, screen=screen, validated=True)
            except TimeoutError:
                break
            if cache_enabled and result[3]:
                signature_cache[signature] = result
        if not result[3] or result[0] >= 0:
            continue
        indices = tuple(sorted(set(paths[0].edges) | set(paths[1].edges)))
        candidate = engine.candidate(center, list(indices), result)
        if time.monotonic() >= deadline:
            return center
        # Record a real accepted move before optional diagnostic work. Both
        # persistence and diagnostic work remain within the worker's wall cap.
        stats['joint_improvements'] = stats.get('joint_improvements', 0) + 1
        stats['joint_gain_scaled'] = stats.get('joint_gain_scaled', 0) - int(result[0])
        if writer and not writer.commit(candidate, 'exact_coupled_service_paths', stats):
            return center
        deltas = []
        for path in paths:
            if remaining(deadline) <= .008:
                break
            try:
                separate = engine.two_units(center, path.source, path.target,
                                             deadline, improve_only=False)
            except TimeoutError:
                break
            deltas.append(int(separate[0]))
        barrier = len(deltas) == 2 and all(d >= 0 for d in deltas)
        stats['joint_barrier_crossings'] = stats.get('joint_barrier_crossings', 0) + int(barrier)
        if writer:
            event = {
                'phase': 'coupled_paths',
                'elapsed_seconds': time.monotonic() - writer.start,
                'center_orientation_sha256': hashlib.sha256(center.orientation.tobytes()).hexdigest(),
                'center_orientation': center.orientation.tolist(),
                'candidate_orientation_sha256': hashlib.sha256(candidate.orientation.tobytes()).hexdigest(),
                'candidate_file': writer.events[-1]['candidate'],
                'candidate_sha256': writer.events[-1]['candidate_sha256'],
                'paths': [dataclasses.asdict(path) for path in paths],
                'supply_signature': signature, 'dual_lower_bound_scaled': lower,
                'joint_delta_scaled': int(result[0]),
                'individual_deltas_scaled': deltas,
                'individual_checks_complete': len(deltas) == 2,
                'individual_nonimproving_joint_improving': barrier if len(deltas) == 2 else None,
                'cost_before': center.total_cost, 'cost_after': candidate.total_cost,
                'certificate_scope': 'exact fixed-orientation recourse only; no global or pool-exhaustion proof',
            }
            with (writer.folder / 'joint_moves.jsonl').open('a', encoding='utf-8') as stream:
                stream.write(json.dumps(event, ensure_ascii=False, allow_nan=False) + '\n')
        return candidate
    return center


def run_coupled_rnps(oracle, current, deadline, rng, writer, stats, method):
    """V20 components plus explicit coupled-path slots; experimental variant."""
    deadline -= RNPS_FINAL_RESERVE
    engine = ResidualNetwork(oracle, stats)
    p = oracle.prep
    history = []
    stats['schedule_policy'] = 'chain_joint_parity_descent_joint_parity'
    stats['search_start_remaining_seconds'] = max(0., remaining(deadline))
    if remaining(deadline) > .04:
        started = time.monotonic()
        bound, rounded, f, half = network_orientation_relaxation(oracle, current.orientation)
        stats['network_lp_solves'] += 1
        stats['global_root_half_switches'] = len(half)
        stats['global_relaxation_seconds'] = time.monotonic() - started
        if remaining(deadline) > 0:
            writer.save_bound(bound, 'complete_capacity_two_network_relaxation')
            if not len(half):
                sol = candidate_from_arrays(oracle, rounded, f, 'integral_global_network_relaxation')
                sol.dual_potential = oracle._dual(f)
                oracle.audit(sol, dual=True)
                if remaining(deadline) > 0:
                    writer.commit(sol, 'global_integral_network_optimum', stats)
                    stats.update(global_optimal=True, global_status='PROVEN_INTEGRAL_GLOBAL_NETWORK_LP')
                    writer.save_bound(sol.scaled_extra_cost, 'integral_complete_network_relaxation')
                    return sol
            else:
                try:
                    sol = oracle.evaluate(rounded, deadline)
                except TimeoutError:
                    sol = None
                if sol is not None and sol.total_cost < current.total_cost:
                    current = sol
                    writer.commit(sol, 'global_network_rounding_seed', stats)
    allowance = min(RNPS_INITIAL_DESCENT_MAX_SECONDS,
                    max(0., remaining(deadline)) * RNPS_INITIAL_DESCENT_FRACTION)
    if p.m and allowance > .004:
        phase_end = min(deadline - .025, time.monotonic() + allowance)
        current = _phase_checkpoint(writer, stats, 'initial_descent', current, allowance,
            lambda: residual_descent(oracle, current, phase_end, rng, engine, writer, stats)[0])
    slots = ['chain', 'joint', 'parity', 'descent', 'joint', 'parity']
    rounds = parity_calls = 0
    while p.m and remaining(deadline) > .06:
        phase = slots[rounds % len(slots)]
        target = RNPS_DESCENT_SECONDS if phase == 'descent' else (
                 CPR_PHASE_SECONDS if phase == 'joint' else RNPS_PHASE_SECONDS)
        allowance = min(target, max(.005, (remaining(deadline) - .025) / 2))
        phase_end = min(deadline - .025, time.monotonic() + allowance)
        before = current.total_cost
        if phase == 'joint':
            operation = (lambda: residual_path_search(oracle, current, phase_end, rng, engine, stats, writer)) if method == 'cprnps_no_joint' else (
                lambda: coupled_path_search(oracle, current, phase_end, rng, stats, writer, method))
            current = _phase_checkpoint(writer, stats, 'joint_control_chain' if method == 'cprnps_no_joint' else 'joint', current, allowance, operation)
        elif phase == 'chain':
            current = _phase_checkpoint(writer, stats, phase, current, allowance,
                lambda: residual_path_search(oracle, current, phase_end, rng, engine, stats, writer))
        elif phase == 'descent':
            current = _phase_checkpoint(writer, stats, phase, current, allowance,
                lambda: residual_descent(oracle, current, phase_end, rng, engine, writer, stats)[0])
        else:
            # Deliberately preserve V20's actually active region sizes. A new
            # operator should not be credited for simultaneously retuning them.
            k = min(p.m, (24, 16)[parity_calls % 2])
            parity_calls += 1
            region = select_network_region(oracle, current, k, rng)
            holder = {}
            def parity_operation():
                sol, log = network_parity_face(oracle, current, region, phase_end,
                                              rng, writer, stats, RNPS_FACE_NODES)
                holder['log'] = log
                return sol
            current = _phase_checkpoint(writer, stats, phase, current, allowance, parity_operation)
            log = holder['log']
            history.append(log)
            stats['neighborhoods'] += 1
            stats['network_branch_nodes'] += log['network_nodes']
            stats['certified_neighborhoods'] += int(log['conditionally_certified'])
            if log['conditionally_certified'] and len(region) == p.m:
                stats.update(global_optimal=True, global_status='PROVEN_COMPLETE_NETWORK_PARITY_TREE')
                writer.save_bound(current.scaled_extra_cost, 'complete_orientation_network_parity_tree')
                break
        stats['accepted_improvements'] += int(current.total_cost < before)
        rounds += 1
        stats['network_search_rounds'] = rounds
        if rounds % 8 == 0:
            atomic_json(writer.folder / 'neighborhoods.json', history)
    stats['network_search_rounds'] = rounds
    atomic_json(writer.folder / 'neighborhoods.json', history)
    atomic_json(writer.folder / 'stage_metrics.json', stats)
    return current

def network_incremental_self_tests(output):
    """Independent cold-flow and exhaustive-domain checks of new primitives."""
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    rows = []
    totals = dict(orientations=0, single_updates=0, chain_updates=0,
                  rejection_bounds=0, restricted_trees=0, complete_trees=0)
    for seed in range(10):
        ins = generate_synthetic('NETWORK_UNIT_%02d' % seed, 6 + seed % 3,
                                 .40, 48010 + seed, 'random')
        path = output / (ins.name + '.json')
        dump_instance(ins, path)
        oracle = ExactOracle(load_instance(path))
        p = oracle.prep
        if p.m > 10:
            raise AssertionError('Validation orientation domain unexpectedly large')
        sols = [oracle.evaluate(np.asarray([(mask >> j) & 1 for j in range(p.m)],
                                         dtype=np.int8)) for mask in range(1 << p.m)]
        by_orientation = {s.orientation.tobytes(): s for s in sols}
        optimum = min(s.scaled_extra_cost for s in sols)
        engine = ResidualNetwork(oracle, rnps_metric_defaults())
        single = chains = rejects = 0
        for center in sols:
            lower, _, _, _ = network_orientation_relaxation(oracle, center.orientation)
            if lower > optimum:
                raise AssertionError('Global network relaxation overestimated the exact optimum')
            tail = np.where(center.orientation == 1, p.edge_u, p.edge_v)
            head = np.where(center.orientation == 1, p.edge_v, p.edge_u)
            for j in range(p.m):
                result = engine.two_units(center, int(tail[j]), int(head[j]))
                repaired = engine.candidate(center, [j], result)
                x = center.orientation.copy()
                x[j] = 1 - x[j]
                expected = by_orientation[x.tobytes()]
                if repaired.scaled_extra_cost != expected.scaled_extra_cost:
                    raise AssertionError('Incremental single reversal disagrees with fresh exact flow')
                pruned = engine.two_units(center, int(tail[j]), int(head[j]), improve_only=True)
                true_delta = expected.scaled_extra_cost - center.scaled_extra_cost
                if pruned[3]:
                    if pruned[0] != true_delta:
                        raise AssertionError('An exact residual return claimed the wrong delta')
                else:
                    if pruned[0] < 0 or pruned[0] > true_delta:
                        raise AssertionError('An early rejection was not a valid nonnegative lower bound')
                    rejects += 1
                single += 1
            for j in range(p.m):
                for k in range(p.m):
                    if j == k or head[j] != tail[k] or tail[j] == head[k]:
                        continue
                    result = engine.two_units(center, int(tail[j]), int(head[k]))
                    repaired = engine.candidate(center, [j, k], result)
                    x = center.orientation.copy()
                    x[[j, k]] = 1 - x[[j, k]]
                    if repaired.scaled_extra_cost != by_orientation[x.tobytes()].scaled_extra_cost:
                        raise AssertionError('Service-chain telescoping update disagrees with fresh exact flow')
                    chains += 1
        tree_checks = 0
        for center in sols[::max(1, len(sols) // 8)]:
            region = np.arange(min(4, p.m))
            outside = np.setdiff1d(np.arange(p.m), region)
            conditional = min(s.scaled_extra_cost for s in sols
                              if np.array_equal(s.orientation[outside], center.orientation[outside]))
            face, log = network_parity_face(oracle, center, region, time.monotonic() + 20,
                                            np.random.default_rng(seed), max_nodes=200000)
            if not log['conditionally_certified'] or face.scaled_extra_cost != conditional:
                raise AssertionError('Network parity face certificate disagrees with enumeration')
            full, log = network_parity_face(oracle, center, np.arange(p.m), time.monotonic() + 20,
                                            np.random.default_rng(seed), max_nodes=200000)
            if not log['conditionally_certified'] or full.scaled_extra_cost != optimum:
                raise AssertionError('Full network parity tree disagrees with exhaustive optimum')
            _, unfinished = network_parity_face(oracle, center, np.arange(p.m), time.monotonic() - 1,
                                                np.random.default_rng(seed), max_nodes=200000)
            if unfinished['conditionally_certified']:
                raise AssertionError('Expired network search incorrectly claimed a certificate')
            tree_checks += 1
        row = {'case': ins.name, 'orientation_count': len(sols), 'single_updates': single,
               'chain_updates': chains, 'safe_early_rejections': rejects,
               'restricted_tree_checks': tree_checks, 'complete_tree_checks': tree_checks,
               'exhaustive_optimum_extra_scaled': int(optimum)}
        rows.append(row)
        totals['orientations'] += len(sols)
        totals['single_updates'] += single
        totals['chain_updates'] += chains
        totals['rejection_bounds'] += rejects
        totals['restricted_trees'] += tree_checks
        totals['complete_trees'] += tree_checks
    # A one-copy reverse arc must NOT carry two units. Its saturation forces
    # a second shortest path. The move is cost-neutral, with a valid new dual.
    ins = MCPPInstance('CAPACITY_ONE_FIXTURE', [],
        [UndirectedRequired('0', '1', 3, 'e0'), UndirectedRequired('1', '2', 7, 'e1')])
    path = output / 'capacity_one.json'
    dump_instance(ins, path)
    oracle = ExactOracle(load_instance(path))
    center = oracle.evaluate([1, 1])
    metrics = rnps_metric_defaults()
    engine = ResidualNetwork(oracle, metrics)
    result = engine.two_units(center, 0, 1)
    moved = engine.candidate(center, [0], result)
    if result[0] != 0 or metrics['residual_shortest_paths'] != 2 or moved.total_cost != 20:
        raise AssertionError('Capacity-one residual bottleneck was mishandled')
    bound, rounded, f, half = network_orientation_relaxation(oracle, center.orientation)
    if bound != 0 or len(half) != 2:
        raise AssertionError('Half-orientation fixture did not expose the parity relaxation')
    fake = candidate_from_arrays(oracle, rounded, f, 'forbidden_half_route')
    try:
        oracle.audit(fake)
    except ValueError:
        pass
    else:
        raise AssertionError('An infeasible fractional service solution entered the route auditor')
    report = {'passed': True, 'cases': rows, 'totals': totals,
              'capacity_one_requires_two_paths': True, 'half_orientation_rejected': True,
              'expired_tree_never_certified': True,
              'scope': 'Correctness of exact local updates and conditional/global bounds on enumerated test cases; not benchmark superiority.'}
    atomic_json(output / 'network_incremental_validation.json', report)
    return report


def rv_seed_worker(task_path):
    """Interruptible seed subprocess, including import cost in the parent cap."""
    task = json.loads(Path(task_path).read_text(encoding='utf-8'))
    if sha256_file(Path(__file__)) != task['source_sha256']:
        raise ValueError('Initializer source changed after scheduling')
    if sha256_file(Path(task['path'])) != task['instance_sha256']:
        raise ValueError('Initializer instance changed after scheduling')
    deadline = float(task['absolute_deadline'])
    if remaining(deadline) <= 0.005:
        return
    atomic_json(Path(task['folder']) / 'seed_progress.json',
                {'phase': 'imports_complete', 'elapsed_seconds': time.monotonic()-float(task['parent_start'])})
    ins = load_instance(task['path'])
    oracle = ExactOracle(ins)
    writer = CheckpointWriter(task['folder'], ins, oracle, float(task['parent_start']),
                              deadline - float(task['parent_start']))
    cfg = SearchConfig(seed=int(task['seed']), cost_scale=COST_SCALE,
                       budget_seconds=max(0.001, remaining(deadline)))
    def checkpoint(sol, phase):
        oracle.audit(sol)
        writer.commit(sol, phase)
        atomic_json(Path(task['folder']) / 'seed_progress.json',
                    {'phase': phase, 'cost': sol.total_cost,
                     'elapsed_seconds': time.monotonic()-float(task['parent_start'])})
    try:
        result = search_modified_mixed_1999(ins, cfg, on_incumbent=checkpoint)
    except TimeoutError:
        return
    checkpoint(result.solution, 'published_modified_mixed_complete')
    if remaining(deadline) > 0:
        atomic_json(Path(task['folder']) / 'seed_completed.json',
                    {'completed': True, 'cost': result.solution.total_cost})


def bounded_rv_initializer(task, writer, deadline, stats):
    """Only one optimizing process; all child overhead is in the same wall cap.

    Parent waits while child works. Child imports, launch, checkpoints, waiting,
    termination and recovery are charged. Windows uses a fresh Python process;
    there is no fork/spawn recursion, second optimizer core or pickled state.
    """
    if remaining(deadline) < 0.30:
        stats['initialization_status'] = 'insufficient_time_for_seed_process'
        return
    folder = writer.folder / 'rv_seed'
    folder.mkdir(parents=True, exist_ok=True)
    available = remaining(deadline)
    legacy = task['method'] in ('legacy_initializer', 'legacy_both')
    allotted = max(0.01, available * RNPS_INITIALIZER_FRACTION)
    fraction = RNPS_LEGACY_INITIALIZER_MAX_FRACTION if legacy else RNPS_INITIALIZER_MAX_FRACTION
    maximum = max(allotted, min(available * fraction,
                               available * (1-RNPS_SEARCH_RESERVE_FRACTION)))
    soft_deadline = time.monotonic() + allotted
    seed_deadline = time.monotonic() + maximum
    seed_task = {'path': task['path'], 'seed': task['seed'], 'folder': str(folder.resolve()),
                 'parent_start': writer.start, 'absolute_deadline': seed_deadline,
                 'source_sha256': task['source_sha256'],
                 'instance_sha256': task['instance_sha256']}
    task_path = folder / 'seed_task.json'
    atomic_json(task_path, seed_task)
    capped = False
    extended = False
    with (folder / 'seed_worker.log').open('w', encoding='utf-8') as log:
        proc = subprocess.Popen([sys.executable, str(Path(__file__).resolve()),
                                  '--rv-seed-worker', str(task_path)],
                                 stdout=log, stderr=subprocess.STDOUT)
        try:
            while proc.poll() is None:
                if remaining(soft_deadline) <= 0 and not extended:
                    path = folder / 'checkpoint.json'
                    prefix_cost = (json.loads(path.read_text(encoding='utf-8'))['event']['best_cost']
                                   if path.exists() else float('inf'))
                    if not legacy or writer.best is None or prefix_cost >= writer.best.total_cost:
                        # V20 extends an unfinished published initializer up to
                        # its hard reserve. A good intermediate prefix no longer
                        # causes premature termination of the remaining branch.
                        # No instance name or known optimum enters this decision.
                        extended = True
                    else:
                        capped = True
                        proc.kill()
                        break
                if remaining(seed_deadline) <= 0:
                    capped = True
                    proc.kill()
                    break
                time.sleep(min(0.01, remaining(seed_deadline)))
        finally:
            if proc.poll() is None:
                proc.kill()
            proc.wait()
    stats['seed_process_budget_capped'] = capped
    stats['initializer_policy'] = 'v19_prefix_quality_gate' if legacy else 'completion_aware_reserved_window'
    stats['seed_budget_extended'] = extended
    stats['seed_initial_budget_seconds'] = allotted
    stats['seed_max_budget_seconds'] = maximum
    stats['seed_process_return_code'] = proc.returncode
    progress = folder / 'seed_progress.json'
    if progress.exists():
        stats['seed_last_progress'] = json.loads(progress.read_text(encoding='utf-8'))
    if proc.returncode not in (0, -9) and not capped:
        raise RuntimeError('RV initializer subprocess failed; see rv_seed/seed_worker.log')
    sol, checkpoint = read_checkpoint(folder, writer.oracle, seed_deadline - writer.start)
    if sol is not None and remaining(deadline) > 0:
        stats['initializer_cost'] = sol.total_cost
        writer.commit(sol, checkpoint['event']['phase'], stats)
    stats['rv_initialization_completed'] = (folder / 'seed_completed.json').exists()
    stats['initialization_status'] = ('published_seed_completed' if stats['rv_initialization_completed']
                                      else 'seed_prefix_recovered' if sol is not None
                                      else 'greedy_seed_retained')


def rnps_metric_defaults():
    return {k: 0 for k in ('certified_neighborhoods', 'neighborhoods',
        'accepted_improvements', 'network_lp_solves', 'network_branch_nodes',
        'residual_evaluations', 'residual_shortest_paths', 'residual_early_rejections',
        'cold_repair_evaluations', 'dual_filtered_edges', 'residual_scans',
        'single_edge_improvements', 'completed_one_flip_local_scans',
        'chain_evaluations', 'chain_improvements', 'reversed_chain_edges',
        'network_search_rounds', 'phase_chain_calls', 'phase_parity_calls',
        'phase_descent_calls', 'phase_initial_descent_calls')}


def execute_method(task, folder, start):
    deadline = start + float(task['budget'])
    instance = load_instance(task['path'])
    oracle = ExactOracle(instance)
    writer = CheckpointWriter(folder, instance, oracle, start, float(task['budget']))
    method = task['method']
    rng = np.random.default_rng(task['seed'])
    stats = dict(rnps_metric_defaults(), method=method, global_optimal=False,
                 rv_initialization_completed=False)
    if method in PUBLISHED_METHODS:
        return execute_published_method(task, writer, deadline, stats)
    p = oracle.prep
    # One feasible starting route is saved before expensive initialization.
    # These costs, all parsing, exact repair and persistence are charged.
    x = np.zeros(p.m, dtype=np.int8)
    balance = p.fixed_balance.copy()
    for j in np.argsort(-np.asarray([e.cost for e in instance.undirected])):
        u, v = int(p.edge_u[j]), int(p.edge_v[j])
        bit = int(balance[u] <= balance[v])
        x[j] = bit
        sign = 1 if bit else -1
        balance[u] += sign
        balance[v] -= sign
    current = oracle.evaluate(x, deadline)
    writer.commit(current, 'common_greedy_feasible_fallback', stats)
    bounded_rv_initializer(task, writer, deadline, stats)
    stats['initializer_seconds'] = time.monotonic() - start
    if writer.best is not None:
        # A published initializer's extra flow need not be minimal for its own
        # service orientations. Certify the working state before residual use.
        current = oracle.evaluate(writer.best.orientation, deadline)
        writer.commit(current, 'fixed_orientation_exact_recourse', stats)
    stats['recourse_start_cost'] = current.total_cost
    stats['recourse_start_orientation_sha256'] = hashlib.sha256(current.orientation.tobytes()).hexdigest()
    stats['recourse_start_flow_sha256'] = hashlib.sha256(current.extra_counts.tobytes()).hexdigest()
    atomic_json(Path(folder) / 'stage_metrics.json', stats)
    if method == 'full_mip':
        stats.update(run_direct_mip(oracle, current, deadline, task['seed'], writer))
    elif method == 'rv_singleflip':
        while p.m and remaining(deadline) > max(0.02, oracle.last_seconds * 1.5):
            j = int(rng.integers(p.m))
            x = current.orientation.copy()
            x[j] = 1 - x[j]
            try:
                candidate = oracle.evaluate(x, deadline)
            except TimeoutError:
                break
            if candidate.total_cost < current.total_cost:
                current = candidate
                stats['single_edge_improvements'] += 1
                writer.commit(current, 'random_single_flip_control', stats)
    elif method in CPR_METHODS:
        run_coupled_rnps(oracle, current, deadline, rng, writer, stats, method)
    else:
        run_rnps(oracle, current, deadline, rng, writer, stats, method)
    return writer, stats


def worker(task_path):
    task = json.loads(Path(task_path).read_text(encoding='utf-8'))
    validate_suite_methods([task['method']], task['suite'])
    folder = Path(task['folder'])
    if sha256_file(Path(__file__)) != task['source_sha256']:
        raise ValueError('Worker source changed after this plan was frozen')
    if sha256_file(Path(task['path'])) != task['instance_sha256']:
        raise ValueError('Worker dataset changed after this plan was frozen')
    start = time.monotonic()
    atomic_json(folder/'ready.json', {'start_monotonic': start,
                                     'created_utc': datetime.now(timezone.utc).isoformat()})
    try:
        writer, stats = execute_method(task, folder, start)
        stats.update(oracle_calls=writer.oracle.calls,cache_hits=writer.oracle.cache_hits,
                     flow_seconds=writer.oracle.flow_seconds,dual_seconds=writer.oracle.dual_seconds)
        elapsed = time.monotonic()-start
        stats['worker_elapsed_seconds'] = elapsed
        stats['completed_before_deadline'] = elapsed <= task['budget']
        atomic_json(folder/'worker_metrics.json', stats)
    except Exception:
        atomic_json(folder/'worker_error.json', {'error': traceback.format_exc(),
                                                'elapsed_seconds': time.monotonic()-start})
        raise


def read_checkpoint(folder, oracle, budget):
    folder = Path(folder)
    p = folder/'checkpoint.json'
    if not p.exists():
        return None, None
    d = json.loads(p.read_text(encoding='utf-8'))
    event = d['event']
    if d['instance_sha256'] != oracle.ins.metadata['source_sha256']:
        raise ValueError('Checkpoint dataset digest mismatch')
    if event['elapsed_seconds'] > budget:
        raise ValueError('A checkpoint created after the cap was rejected')
    p = folder/event['candidate']
    if sha256_file(p) != event['candidate_sha256']:
        raise ValueError('Checkpoint digest mismatch')
    with np.load(p, allow_pickle=False) as z:
        sol = candidate_from_arrays(oracle, z['orientation'], z['extra_counts'], 'saved_incumbent')
        if abs(sol.total_cost-float(z['total_cost'])) > 1e-7:
            raise ValueError('Checkpoint claimed cost differs from saved route counts')
        sol.dual_potential = z['dual_potential'].astype(np.int64)
        if int(sol.scaled_extra_cost) != int(z['scaled_extra_cost']):
            raise ValueError('Checkpoint objective mismatch')
    oracle.audit(sol)
    return sol, d


def export_euler_tour(oracle, sol, path):
    graph = nx.MultiDiGraph()
    for a in oracle.ins.directed:
        graph.add_edge(a.tail, a.head, source_id=a.source_id, cost=a.cost, service=True)
    for bit, e in zip(sol.orientation, oracle.ins.undirected):
        u, v = (e.u, e.v) if bit else (e.v, e.u)
        graph.add_edge(u, v, source_id=e.source_id, cost=e.cost, service=True)
    for q, a in zip(sol.extra_counts, oracle.prep.travel):
        for _ in range(int(q)):
            graph.add_edge(a.tail, a.head, source_id=a.source_id, cost=a.cost, service=False)
    if not nx.is_eulerian(graph):
        raise ValueError('Export graph failed independent Eulerian audit')
    rows = []
    previous = None
    first = None
    covered = set()
    cost = 0.0
    for i, (u, v, key) in enumerate(nx.eulerian_circuit(graph, keys=True)):
        if previous is not None and previous != u:
            raise ValueError('Exported walk is discontinuous')
        if first is None:
            first = u
        previous = v
        data = graph[u][v][key]
        cost += data['cost']
        if data['service']:
            covered.add(data['source_id'])
        rows.append({'step': i, 'tail': u, 'head': v, **data})
    required = {a.source_id for a in oracle.ins.directed} | {e.source_id for e in oracle.ins.undirected}
    if first != previous or covered != required or abs(cost-sol.total_cost) > 1e-7:
        raise ValueError('Euler walk closure, coverage or cost verification failed')
    pd.DataFrame(rows).to_csv(path, index=False, encoding='utf-8-sig')


def supervised_task(task, output):
    run_id = hashlib.sha256(json.dumps(task, sort_keys=True).encode()).hexdigest()[:20]
    folder = Path(output)/'runs'/run_id
    folder.mkdir(parents=True, exist_ok=True)
    task = dict(task, folder=str(folder.resolve()))
    digest = hashlib.sha256(json.dumps(task, sort_keys=True).encode()).hexdigest()
    result_path = folder/'result.json'
    if result_path.exists():
        saved = json.loads(result_path.read_text(encoding='utf-8'))
        if saved.get('task_digest') != digest:
            raise ValueError('Resume configuration changed')
        oracle = ExactOracle(load_instance(task['path']))
        if saved.get('feasible'):
            sol, _ = read_checkpoint(folder, oracle, task['budget'])
            if sol is None or abs(sol.total_cost - saved['cost']) > 1e-7:
                raise ValueError('Resume checkpoint failed')
        return saved
    if (folder/'task.json').exists():
        # A killed run can retain an old rv_seed checkpoint/completion marker.
        # It was computed under a different clock origin and must not supply
        # an uncharged initializer to a restarted attempt. Completed immutable
        # results may resume above; unfinished attempts require a fresh folder.
        raise FileExistsError('Unfinished attempt retained at '+str(folder)+
            '. Preserve its evidence and choose a new --output directory.')
    # Remove stale records from an interrupted unsaved attempt; completed
    # result.json files are never overwritten under a different configuration.
    for p in folder.iterdir():
        if p.is_file() and p.name != 'task.json':
            p.unlink()
    atomic_json(folder/'task.json', task)
    launched = time.monotonic()
    last_poll = launched
    max_poll_gap = 0.0
    deadline_detected = None
    kill_requested = None
    kill_returned = None
    start = None
    killed = False
    startup_failure = False
    with (folder/'worker.log').open('w', encoding='utf-8') as log:
        proc = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--worker',
                                 str(folder/'task.json')], stdout=log, stderr=subprocess.STDOUT)
        while proc.poll() is None:
            poll_time = time.monotonic()
            max_poll_gap = max(max_poll_gap, poll_time - last_poll)
            last_poll = poll_time
            if start is None and (folder/'ready.json').exists():
                start = float(json.loads((folder/'ready.json').read_text())['start_monotonic'])
            now = time.monotonic()
            if start is not None and now >= start + task['budget']:
                deadline_detected = now
                killed = True
                kill_requested = time.monotonic()
                proc.kill()
                kill_returned = time.monotonic()
                break
            if start is None and now - launched > IMPORT_STARTUP_LIMIT:
                startup_failure = True
                proc.kill()
                break
            time.sleep(0.025)
        proc.wait()
    ended = time.monotonic()
    if start is None and (folder/'ready.json').exists():
        start = float(json.loads((folder/'ready.json').read_text())['start_monotonic'])
    instance = load_instance(task['path'])
    oracle = ExactOracle(instance)
    row = {'instance': instance.name, 'method': task['method'], 'seed': task['seed'],
           'budget_seconds': task['budget'], 'task_digest': digest, 'execution_id': run_id,
           'instance_sha256': instance.metadata['source_sha256'],
           'source_sha256': task['source_sha256'], 'nodes': oracle.prep.n,
           'required_links': instance.n_required, 'mandatory_cost': instance.mandatory_cost,
           'physical_execution': True, 'watchdog_terminated': killed,
           'solver_wall_seconds': None if start is None else ended-start,
           'import_startup_seconds': None if start is None else start-launched,
           'end_to_end_before_export_seconds': ended-launched,
           'watchdog_latency_seconds': 0 if start is None else max(0., ended-start-task['budget']),
           'feasible': False, 'cost': None, 'status': 'startup_failed' if startup_failure else 'no_feasible_incumbent'}
    row.update(supervisor_max_poll_gap_seconds=max_poll_gap,
               deadline_detected_seconds=None if start is None or deadline_detected is None else deadline_detected-start,
               kill_requested_seconds=None if start is None or kill_requested is None else kill_requested-start,
               kill_call_returned_seconds=None if start is None or kill_returned is None else kill_returned-start,
               process_exit_observed_seconds=None if start is None else ended-start)
    row['cost_units_per_meter'] = instance.metadata.get('cost_units_per_meter')
    try:
        sol, checkpoint = read_checkpoint(folder, oracle, task['budget'])
        if sol is not None:
            row.update(cost=sol.total_cost, feasible=True, status='budget_capped' if killed else 'completed',
                       incumbent_seconds=checkpoint['event']['elapsed_seconds'],
                       initializer_cost=next((e['best_cost'] for e in checkpoint['events']
                                              if e['phase']=='modified_mixed_initializer'), None))
            row.update(checkpoint.get('metrics',{}))
            row['common_fallback_cost'] = next((e['best_cost'] for e in checkpoint['events']
                                               if e['phase']=='common_greedy_feasible_fallback'),None)
            export_start = time.monotonic()
            export_euler_tour(oracle, sol, folder/'euler_tour.csv')
            row['post_audit_and_export_seconds'] = time.monotonic()-export_start
            if row['cost_units_per_meter']:
                row['route_length_meters'] = sol.total_cost/row['cost_units_per_meter']
    except Exception:
        row.update(feasible=False, cost=None, status='audit_failed', audit_error=traceback.format_exc())
    row['counters_complete'] = (folder/'worker_metrics.json').exists()
    for file in ['stage_metrics.json','worker_metrics.json', 'worker_error.json']:
        if (folder/file).exists():
            d = json.loads((folder/file).read_text())
            if file == 'worker_error.json':
                row['worker_error'] = d
                if row['feasible']:
                    row['status'] = 'feasible_with_worker_error'
            else:
                row.update(d)
    bound = folder/'global_bound.json'
    if bound.exists():
        d = json.loads(bound.read_text())
        if d['elapsed_seconds'] <= task['budget']:
            row['global_lower_bound'] = float(instance.mandatory_cost + d['bound_scaled']/COST_SCALE)
    row['run_directory'] = str(folder.resolve())
    atomic_json(result_path, row)
    return row


def holm_adjust(p_values):
    if not len(p_values):
        return []
    p = np.asarray(p_values, dtype=float)
    order = np.argsort(p)
    adjusted = np.empty_like(p)
    adjusted[order] = np.minimum(1., np.maximum.accumulate(p[order]*(len(p)-np.arange(len(p)))))
    return adjusted.tolist()


def bootstrap_mean_ci(values, rng=None):
    values = np.asarray(values, dtype=float)
    if not len(values):
        return [None, None]
    if rng is None:
        rng = np.random.default_rng(STATISTICAL_SEED)
    draws = rng.choice(values, (BOOTSTRAP_REPEATS, len(values)), replace=True).mean(axis=1)
    return np.quantile(draws, [.025, .975]).tolist()


def paired_statistics(frame, reference, cost_col='cost'):
    # One inferential observation per instance, regardless of the number of
    # stochastic seeds or repeated labels of a deterministic execution.
    grouped = frame.groupby(['instance','method'])[cost_col].mean().unstack()
    out = []
    if reference not in grouped:
        return pd.DataFrame()
    for comparator in sorted(c for c in grouped if c != reference):
        pair = grouped[[reference, comparator]].dropna()
        delta = pair[comparator].to_numpy()-pair[reference].to_numpy()
        rel = 100*delta/pair[comparator].to_numpy()
        nonzero = delta[np.abs(delta)>1e-7]
        pval = 1. if not len(nonzero) else float(wilcoxon(delta, zero_method='pratt', alternative='two-sided').pvalue)
        ci = bootstrap_mean_ci(rel)
        out.append({'reference': reference, 'comparator': comparator, 'instances': len(pair),
                    'reference_wins': int((delta>1e-7).sum()), 'ties': int((np.abs(delta)<=1e-7).sum()),
                    'reference_losses': int((delta<-1e-7).sum()),
                    'mean_relative_cost_reduction_pct': float(np.mean(rel)) if len(rel) else None,
                    'bootstrap95_low_pct': ci[0], 'bootstrap95_high_pct': ci[1],
                    'wilcoxon_pratt_two_sided_p': pval,
                    'sign_test_p': float(binomtest(int((nonzero>0).sum()),len(nonzero),.5).pvalue) if len(nonzero) else 1.,
                    'inference_unit': 'instance mean; duplicated deterministic labels are not extra observations'})
    adjusted = holm_adjust([r['wilcoxon_pratt_two_sided_p'] for r in out])
    for r, p in zip(out, adjusted):
        r['holm_p'] = p
    return pd.DataFrame(out)


def summarize_new_results(rows, output, expected=None, suite='literature', stage='unspecified_exploratory'):
    output = Path(output)
    frame = pd.DataFrame(rows)
    if not len(frame):
        return
    validate_suite_methods(list(frame.method.unique()), suite)
    frame['experiment_suite'] = suite
    frame['experiment_stage'] = stage
    provenance = {m: method_provenance(m) for m in frame.method.unique()}
    for col in ['display_name', 'method_category', 'title', 'doi', 'journal', 'year', 'implementation']:
        frame[col] = frame.method.map(lambda m: provenance[m].get(col, ''))
    frame.to_csv(output/'all_attempts.csv', index=False, encoding='utf-8-sig')
    export_mechanism_diagnostics(rows, output, suite)
    summary = []
    for method, group in frame.groupby('method'):
        ok = group[group.feasible]
        physical = group.drop_duplicates('execution_id')
        means = ok.groupby('instance').cost.mean()
        summary.append({'method':method,'display_name':provenance[method]['display_name'],
                        'method_category':provenance[method]['method_category'],
                        'journal':provenance[method].get('journal',''),
                        'doi':provenance[method].get('doi',''),
                        'title':provenance[method].get('title',''),
                        'year':provenance[method].get('year',''),
                        'implementation':provenance[method].get('implementation',''),
                        'experiment_suite':suite,'experiment_stage':stage,'attempted_labels':len(group),
                        'physical_executions':len(physical),'feasible_labels':len(ok),
                        'failures':int((~group.feasible).sum()),
                        'instances':group.instance.nunique(),
                        'mean_cost_over_successful_instances_only':float(means.mean()) if len(means) else None,
                        'mean_physical_wall_seconds':physical.solver_wall_seconds.mean(),
                        'max_watchdog_latency_seconds':physical.watchdog_latency_seconds.max(),
                        'worker_error_labels':int(group.get('worker_error',pd.Series(index=group.index,dtype=object)).notna().sum()),
                        'certified_neighborhoods_on_finished_workers':int(physical.get('certified_neighborhoods',pd.Series(dtype=int)).sum())})
        if method in PUBLISHED_METHODS:
            summary[-1]['published_algorithm_complete_physical_runs'] = int(
                physical.get('published_algorithm_completed',pd.Series(False,index=physical.index)).eq(True).sum())
        if 'gap_to_official_lower_bound_pct' in group:
            summary[-1]['mean_instance_gap_to_official_lb_pct'] = ok.groupby('instance').gap_to_official_lower_bound_pct.mean().mean()
            summary[-1]['mean_instance_gap_to_official_ub_pct'] = ok.groupby('instance').gap_to_official_upper_bound_pct.mean().mean()
    pd.DataFrame(summary).to_csv(output/'method_summary.csv',index=False,encoding='utf-8-sig')
    eligibility=[]
    for comparator in frame.method.unique():
        if comparator==PROPOSED_METHOD:
            continue
        group=frame[frame.method.isin([PROPOSED_METHOD,comparator])]
        eligibility.append({'reference':PROPOSED_METHOD,'comparator':comparator,
            'attempted_labels':len(group),'failed_labels':int((~group.feasible).sum()),
            'all_attempts_feasible':bool(group.feasible.all()),
            'cost_comparison_scope':'complete_feasible_pairs' if bool(group.feasible.all()) else 'incomplete; report feasibility and failures before cost',
            'implementation_fidelity':method_provenance(comparator).get('reference_equivalence','internal_control')})
    pd.DataFrame(eligibility).to_csv(output/'comparison_eligibility.csv',index=False,encoding='utf-8-sig')
    # A failure never disappears through pandas' default skip-NaN aggregation.
    has_worker_errors = bool(frame.get('worker_error',pd.Series(index=frame.index,dtype=object)).notna().any())
    complete = bool(frame.feasible.all()) and not has_worker_errors and (expected is None or len(frame)==expected)
    pairs = paired_statistics(frame[frame.feasible], PROPOSED_METHOD)
    confirmatory_stage = stage.startswith('prospectively_frozen_') and suite == 'literature'
    if len(pairs):
        pair_complete=[]
        for comparator in pairs.comparator:
            group=frame[frame.method.isin([PROPOSED_METHOD,comparator])]
            counts=group.groupby(['instance','method']).size().unstack()
            pair_complete.append(bool(group.feasible.all())
                and not group.get('worker_error',pd.Series(index=group.index,dtype=object)).notna().any()
                and not counts.isna().any().any() and counts.nunique(axis=1).eq(1).all())
        pairs['complete_pair_protocol']=pair_complete
        # A missing route is not a cheap tour. Do not compute significance or
        # intervals after silently dropping failed runs from a method pair.
        for field in ['bootstrap95_low_pct','bootstrap95_high_pct',
                      'wilcoxon_pratt_two_sided_p','sign_test_p','holm_p']:
            pairs.loc[~pairs.complete_pair_protocol,field]=np.nan
        pairs['complete_protocol'] = complete
        pairs['experiment_suite'] = suite
        pairs['experiment_stage'] = stage
        pairs['interpretation'] = ('frozen_confirmatory_complete_protocol' if complete and confirmatory_stage
                                   else 'exploratory_'+suite+'_complete_protocol' if complete
                                   else 'exploratory_successful_pairs_only')
        pairs.to_csv(output/'paired_instance_comparisons.csv',index=False,encoding='utf-8-sig')
    instance_rows = []
    for (name, method), group in frame.groupby(['instance','method']):
        instance_rows.append({'instance':name,'method':method,'attempted':len(group),
                'feasible':int(group.feasible.sum()),'nodes':int(group.nodes.iloc[0]),
                'mean_cost':group.cost.mean() if bool(group.feasible.all()) else None,
                'cost_with_failure_penalty':group.cost.mean() if bool(group.feasible.all()) else float('inf'),
                'mandatory_cost':float(group.mandatory_cost.iloc[0]),
                'best_global_lower_bound':float(max(group.mandatory_cost.iloc[0],
                                                    group.get('global_lower_bound',pd.Series([0])).max()))})
    im = pd.DataFrame(instance_rows)
    im.to_csv(output/'instance_summary.csv', index=False, encoding='utf-8-sig')
    # Size is a descriptor, not an additional independent replicate.
    im.groupby(['nodes','method']).agg(instances=('instance','nunique'),
            mean_cost=('mean_cost','mean'), failures=('mean_cost',lambda s:int(s.isna().sum())))\
        .to_csv(output/'size_stratified_summary.csv',encoding='utf-8-sig')
    ranks = im.pivot(index='instance',columns='method',values='cost_with_failure_penalty').rank(axis=1)
    ranks.mean().rename('average_rank_failure_as_infinity').to_csv(output/'average_ranks.csv',encoding='utf-8-sig')
    atomic_json(output/'integrity.json', {'complete_protocol':complete,
                'experiment_suite':suite,'experiment_stage':stage,
                'eligible_as_frozen_confirmatory_results':complete and confirmatory_stage,
                'observed_labels':len(frame),'expected_labels':expected,
                'failure_labels':int((~frame.feasible).sum()),
                'has_worker_errors':has_worker_errors,
                'timing_clean_within_one_second_supervisor_latency':bool((frame.watchdog_latency_seconds<=1).all()),
                'inference_unit':'instance; seed runs are nested replicates',
                'certification_boundary':'Network parity face certificates are conditional; only complete-domain proofs and full_mip bounds are global',
                'confirmatory_claim':'New results require their own prospectively frozen untouched instances.'})
    if suite == 'literature':
        atomic_json(output/'literature_fidelity_manifest.json',
                    {'suite':suite, 'stage':stage, 'methods':provenance,
                     'excluded_adaptations':EXCLUDED_LITERATURE_ADAPTATIONS,
                     'scope':'One proposed method and independently reimplemented published journal algorithms. No claim of official author software or automatic journal acceptance.'})
        pd.DataFrame(summary).to_csv(output/'SCI_main_comparison.csv',index=False,encoding='utf-8-sig')
    elif suite == 'recent':
        atomic_json(output/'recent_publication_fidelity_manifest.json',{
            'suite':suite,'methods':provenance,'eligible_as_sci_main_comparison':False,
            'reason':'Recent port has unconfirmed SCIE status and no numerical author-code equivalence',
            'failures_retained':True})
        pd.DataFrame(summary).to_csv(output/'supplemental_recent_publications.csv',index=False,encoding='utf-8-sig')
    elif suite == 'ablation':
        pd.DataFrame(summary).to_csv(output/'supplemental_ablation_comparison.csv',index=False,encoding='utf-8-sig')
    else:
        pd.DataFrame(summary).to_csv(output/'independent_model_validation.csv',index=False,encoding='utf-8-sig')
    lines = ['# MCPP experiment result: '+suite, '', 'Stage: '+stage, '',
             'Complete protocol: **%s**. Observed %d labels; failed %d.' % (complete,len(frame),(~frame.feasible).sum()),
             '', 'A feasible initializer preserved by construction is not evidence that the added search helps.',
             'Use paired_instance_comparisons.csv and report ties, losses, confidence intervals and all failures.',
             'Do not call a face-optimality certificate a global MCPP optimality certificate.',
             'Average cost over successful instances is descriptive when the protocol is incomplete.']
    (output/'RESULTS_GUIDE.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    anytime = []
    for r in rows:
        p = Path(r['run_directory'])/'checkpoint.json'
        if not p.exists():
            events = []
        else:
            events = json.loads(p.read_text(encoding='utf-8'))['events']
        cap = r['budget_seconds']
        times = sorted(set([t for t in [.5,1,2,4,5,8,10,30,60,120,300] if t<=cap]+[cap]))
        lb = r.get('official_lower_bound',r['mandatory_cost'])
        for t in times:
            eligible = [e['best_cost'] for e in events if e['elapsed_seconds']<=t]
            cost = min(eligible) if eligible else None
            anytime.append({'instance':r['instance'],'method':r['method'],'seed':r['seed'],
                            'seconds':t,'best_cost':cost,
                            'gap_to_reference_lb_pct':100*(cost-lb)/lb if cost is not None else None,
                            'reference_lb_type':'official' if 'official_lower_bound' in r else 'mandatory_cost'})
    curve = pd.DataFrame(anytime)
    curve.to_csv(output/'anytime_all_labels.csv',index=False,encoding='utf-8-sig')
    inst_curve = curve.groupby(['instance','method','seconds']).agg(
                    labels=('seed','size'),available=('best_cost','count'),
                    mean_gap=('gap_to_reference_lb_pct','mean')).reset_index()
    inst_curve.loc[inst_curve.available!=inst_curve.labels,'mean_gap']=np.nan
    anytime_summary = inst_curve.groupby(['method','seconds']).agg(
                    expected_instances=('instance','size'),
                    instances_with_all_labels_available=('mean_gap','count'),
                    mean_gap_on_available_instances=('mean_gap','mean')).reset_index()
    anytime_summary.to_csv(output/'anytime_summary.csv',index=False,encoding='utf-8-sig')
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(8,4))
        ranks.mean().sort_values().plot.barh(ax=ax, color='#2563a6')
        ax.set_xlabel('Mean instance rank (failed method = +infinity before ranking)')
        fig.tight_layout(); fig.savefig(output/'average_ranks.png',dpi=180); plt.close(fig)
        fig,ax=plt.subplots(figsize=(8,4))
        for method,group in anytime_summary.groupby('method'):
            ax.plot(group.seconds,group.mean_gap_on_available_instances,marker='o',label=method)
        ax.set_xlabel('Method seconds, including input/preparation/initialization')
        ax.set_ylabel('Mean gap to reference lower bound (%)')
        ax.legend(fontsize=7);fig.tight_layout();fig.savefig(output/'anytime_gap.png',dpi=180);plt.close(fig)
    except ImportError:
        pass


def find_history(explicit=None):
    candidates = ([Path(explicit)] if explicit else []) + [
        Path(HISTORICAL_RESULTS_PATH) if HISTORICAL_RESULTS_PATH else SCRIPT_DIR/'cor_paper_results',
        SCRIPT_DIR/'historical_evidence', SCRIPT_DIR.parent/'cor_paper_results']
    for p in candidates:
        if p.is_dir() and list(p.glob('*/analysis/all_results.csv')):
            return p.resolve()
    for p in [SCRIPT_DIR/'cor_paper_results(1).zip',SCRIPT_DIR/'cor_paper_results.zip',
              SCRIPT_DIR.parent/'cor_paper_results(1).zip',SCRIPT_DIR.parent/'cor_paper_results.zip']:
        if p.exists():
            dest = OUTPUT_ROOT/'historical_input'
            checked_extract(p,dest)
            return find_history(dest/'cor_paper_results')
    return None


def historical_audit(root, output):
    root, output = Path(root), Path(output)
    output.mkdir(parents=True,exist_ok=True)
    inventory=[]
    suites={}
    for path in sorted(root.glob('*/analysis/all_results.csv')):
        suite = path.parent.parent.name
        f = pd.read_csv(path)
        suites[suite]=f
        mf = path.parent.parent/'experiment_manifest.json'
        manifest = json.loads(mf.read_text()) if mf.exists() else {}
        for method,g in f.groupby('method'):
            by=g.groupby('instance')
            caps = pd.to_numeric(g.profile.str.extract(r'time_(\d+(?:\.\d+)?)s')[0],errors='coerce')
            inventory.append({'suite':suite,'method':method,'rows':len(g),'instances':g.instance.nunique(),
                'mean_instance_gap_lb_pct':by.gap_to_lower_bound_pct.mean().mean(),
                'mean_method_seconds':by.method_seconds.mean().mean(),
                'mean_shared_init_seconds':by.shared_init_seconds.mean().mean() if 'shared_init_seconds' in g else 0,
                'max_method_seconds':g.method_seconds.max(),
                'over_cap_gt_1s':int((g.budget_overshoot_seconds>1).sum()),
                'max_budget_overshoot_seconds':g.budget_overshoot_seconds.max(),
                'conditional_certificates':int(g.certified_neighborhoods.sum()),
                'source_sha256':manifest.get('source_sha256'),
                'parallel_workers':manifest.get('workers')})
    table=pd.DataFrame(inventory)
    table.to_csv(output/'historical_suite_inventory.csv',index=False,encoding='utf-8-sig')
    pairs=[]
    for left,right,label in [
        ('joh_gfrq_literature_comparison_development_20x5','joh_modified_mixed_development_20x1_v1724','development60'),
        ('joh_gfrq_literature_comparison_heldout_100x10','joh_modified_mixed_heldout_100x10_v1722','historical100')]:
        if left not in suites or right not in suites:
            continue
        f=suites[left].query("method=='frq_sm_pb_lns'").copy()
        g=suites[right].copy()
        joined=pd.concat([f,g],ignore_index=True)
        joined['cost']=joined.strict_cost
        stat=paired_statistics(joined,'frq_sm_pb_lns')
        stat['comparison']=label
        stat['time_fairness_validated']=False if label=='historical100' else '60s cap has a small V17 overrun'
        pairs.append(stat)
        joined.groupby(['instance','method']).agg(mean_cost=('strict_cost','mean'),
            gap_lb_pct=('gap_to_lower_bound_pct','mean'),runtime=('method_seconds','mean'),
            seed_labels=('seed','nunique')).reset_index().to_csv(output/(label+'_instance_comparison.csv'),index=False,encoding='utf-8-sig')
    if pairs:
        pd.concat(pairs,ignore_index=True).to_csv(output/'historical_paired_comparisons.csv',index=False,encoding='utf-8-sig')
    # Timestamp-only truncation is a diagnostic. Historical checkpoint tours
    # were not saved; truncation does not manufacture independently verified
    # 300-second feasible solutions or remedy uncharged preprocessing.
    historical='joh_gfrq_literature_comparison_heldout_100x10'
    if historical in suites:
        conv=root/historical/'analysis/all_convergence.csv'
        if conv.exists():
            c=pd.read_csv(conv)
            keys=['instance','method','seed']
            eligible=c[(c.elapsed_seconds<=300)&np.isfinite(c.best_cost)].groupby(keys).best_cost.min().rename('logged_best_at_300s')
            f=suites[historical].merge(eligible.reset_index(),on=keys,how='left')
            f['claimed_final_better_than_logged_cap']=f.strict_cost < f.logged_best_at_300s-1e-7
            f[['instance','method','seed','strict_cost','logged_best_at_300s','method_seconds',
               'claimed_final_better_than_logged_cap']].to_csv(output/'deadline_log_diagnostic.csv',index=False,encoding='utf-8-sig')
            f.groupby('method').agg(rows=('seed','size'),missing_in_cap_checkpoint=('logged_best_at_300s',lambda s:int(s.isna().sum())),
                   post_cap_final_improvement=('claimed_final_better_than_logged_cap','sum')).to_csv(output/'deadline_log_summary.csv',encoding='utf-8-sig')
    verdict={'supports_current_high_performance_submission':False,
             'main_problems':['A much faster directly published comparator often has lower cost.',
                'Formal 300-second rows include large overruns; preprocessing is not consistently included.',
                'No V17 conditional neighborhood certificates are reported in the uploaded heldout results.',
                'No new-method independent confirmation is available on untouched instances.',
                'Historical proposed-method route counts are not retained for independent saved-tour verification.'],
             'recommendation':'Treat this experiment as development. Retain strongest comparator, matched-budget ablations, exact small cases, and a newly frozen external set.'}
    atomic_json(output/'publication_readiness.json',verdict)
    print('[audit] Wrote historical comparison and timing diagnostics:',output,flush=True)
    return table


def generate_synthetic(name,n,ratio,seed,family='geometric'):
    """Controlled synthetic instance, not real-road evidence.

    A directed Hamiltonian cycle guarantees strong permitted connectivity.
    Extra physical links sample either geometric nearest-neighbor pairs or
    uniformly random pairs. All mandatory costs are positive integers.
    """
    rng=np.random.default_rng(seed)
    points=rng.random((n,2))
    pairs={(min(i,(i+1)%n),max(i,(i+1)%n)) for i in range(n)}
    target=min(n*(n-1)//2,3*n)
    if family=='geometric':
        neighbors=cKDTree(points).query(points,k=min(n,8))[1]
        for i,values in enumerate(neighbors):
            for j in values[1:]:
                if i!=int(j):pairs.add((min(i,int(j)),max(i,int(j))))
        available=sorted(pairs)
        ring={(min(i,(i+1)%n),max(i,(i+1)%n)) for i in range(n)}
        extra=[p for p in available if p not in ring]
        rng.shuffle(extra)
        pairs=ring|set(extra[:max(0,target-len(ring))])
    else:
        while len(pairs)<target:
            u,v=map(int,rng.choice(n,2,replace=False))
            pairs.add((min(u,v),max(u,v)))
    directed=[];undirected=[]
    ring_orientations={tuple(sorted((i,(i+1)%n))):(i,(i+1)%n) for i in range(n)}
    for idx,(u,v) in enumerate(sorted(pairs)):
        cost=int(1+round(90*np.linalg.norm(points[u]-points[v]))) if family=='geometric' else int(rng.integers(1,100))
        source=f'{name}:required:{idx}'
        if (u,v) in ring_orientations:
            tail,head=ring_orientations[(u,v)]
            directed.append(DirectedRequired(str(tail),str(head),cost,source))
        elif rng.random()<ratio:
            undirected.append(UndirectedRequired(str(u),str(v),cost,source))
        else:
            tail,head=(u,v) if rng.integers(2) else (v,u)
            directed.append(DirectedRequired(str(tail),str(head),cost,source))
    return MCPPInstance(name,directed,undirected,[],{},
            {'dataset':'new_controlled_synthetic','family':family,'generation_seed':seed,
             'requested_undirected_probability_on_nonbackbone_links':ratio,
             'actual_undirected_fraction':len(undirected)/len(pairs),
             'not_real_road_data':True})


def freeze_fresh_set(output,methods,seeds,budget,fresh_input=None,suite='literature'):
    validate_suite_methods(methods,suite)
    output=Path(output)
    manifest=output/'frozen_protocol.json'
    if manifest.exists():
        raise FileExistsError('Fresh protocol already frozen. It will not be regenerated or overwritten.')
    entries=[]
    if fresh_input is not None:
        inputs = sorted(Path(fresh_input).glob('*.json'))
        if not inputs:
            raise FileNotFoundError('Fresh input folder contains no MCPP instance JSON files')
        seen = set()
        for source in inputs:
            ins = load_instance(source)
            if re.fullmatch(r'M[AB]\d{4}',ins.name):
                raise ValueError('Previously viewed Corberan benchmark cannot become a fresh confirmation set')
            if ins.name in seen:
                raise ValueError('Duplicate fresh instance name')
            seen.add(ins.name)
            oracle = ExactOracle(ins)  # Validate representation only; no optimization.
            if ins.optional_travel:
                raise ValueError('RV comparator requires pure MCPP with every link mandatory')
            label = re.sub(r'[^A-Za-z0-9_-]','_',ins.name)
            p = output/'instances'/(label+'.json')
            if p.exists():
                raise FileExistsError('Fresh output already contains an instance with this sanitized name')
            dump_instance(ins,p)
            entries.append({'name':ins.name,'relative_path':str(p.relative_to(output)),
                            'sha256':sha256_file(p),'input_sha256':sha256_file(source),
                            'family':ins.metadata.get('dataset','user_supplied_mcpp'),
                            'nodes':oracle.prep.n})
    generator_seed=FRESH_GENERATOR_SEED
    for family in ([] if fresh_input is not None else ['geometric','random']):
        for n in FRESH_NODE_SIZES:
            for ratio in [.30,.70]:
                for repetition in range(FRESH_REPLICATES):
                    name=f'NEW_{family}_n{n}_r{int(ratio*100)}_{repetition:02d}'
                    instance=generate_synthetic(name,n,ratio,generator_seed,family)
                    path=output/'instances'/(name+'.json')
                    dump_instance(instance,path)
                    entries.append({'name':name,'relative_path':str(path.relative_to(output)),
                                    'sha256':sha256_file(path),'family':family,'nodes':n})
                    generator_seed+=1
    # Only use this after development decisions are complete. Config/hash guards
    # prevent silently editing the method while continuing the same confirmation.
    atomic_json(manifest,{'stage':'prospectively_frozen_external_inputs' if fresh_input else 'prospectively_frozen_new_synthetic_set',
        'created_utc':datetime.now(timezone.utc).isoformat(),'source_sha256':sha256_file(Path(__file__)),
        'algorithm_parameters':algorithm_parameters(),'methods':methods,'suite':suite,'seeds':seeds,'budget':budget,
        'generator_seed':FRESH_GENERATOR_SEED if fresh_input is None else None,'instances':entries,
        'claim_boundary':'Input provenance and prior viewing must be disclosed; file hashes cannot prove that a researcher has never viewed data.'})
    print('[freeze] Frozen',len(entries),'new instances:',manifest,flush=True)


def export_mechanism_diagnostics(rows, output, suite):
    """Keep starvation, mechanism calls and failed comparisons visible."""
    keys = ['instance','method','seed','execution_id','budget_seconds','feasible','cost',
            'initializer_policy','initialization_status','rv_initialization_completed',
            'initializer_seconds','recourse_start_cost','recourse_start_orientation_sha256',
            'recourse_start_flow_sha256','schedule_policy',
            'phase_initial_descent_calls','phase_initial_descent_seconds',
            'phase_chain_calls','phase_parity_calls','phase_descent_calls',
            'network_search_rounds','chain_evaluations','chain_improvements',
            'residual_evaluations','cold_repair_evaluations','neighborhoods',
            'certified_neighborhoods','single_edge_improvements',
            'aco_sgs_attempts','aco_sgs_valid','aco_sgs_rejections','published_termination']
    data = []
    for r in rows:
        item = {k:r.get(k) for k in keys}
        item['mechanism_starvation_observed'] = bool(r['method']=='rnps'
            and not r.get('global_optimal',False)
            and r.get('phase_chain_calls',0)==0 and r.get('phase_parity_calls',0)==0)
        data.append(item)
    pd.DataFrame(data).to_csv(Path(output)/'mechanism_diagnostics.csv',index=False,encoding='utf-8-sig')
    if suite=='ablation':
        starts=[]
        frame=pd.DataFrame(rows)
        for (instance,seed),group in frame.groupby(['instance','seed']):
            reference=group[group.method=='rnps']
            if reference.empty:
                continue
            ref=reference.iloc[0]
            for _,r in group.iterrows():
                pure=r['method'] in ['without_chain','without_parity','cold_repair','legacy_phase_schedule','rv_singleflip']
                matched=all(r.get(k)==ref.get(k) for k in
                    ['recourse_start_orientation_sha256','recourse_start_flow_sha256','recourse_start_cost'])
                starts.append({'instance':instance,'seed':int(seed),'method':r['method'],
                    'same_start_required_for_pure_mechanism_claim':pure,'identical_audited_search_start':matched,
                    'eligible_as_pure_mechanism_pair':bool(pure and matched and r['feasible'] and ref['feasible']),
                    'reference_start_cost':ref.get('recourse_start_cost'),'control_start_cost':r.get('recourse_start_cost')})
        pd.DataFrame(starts).to_csv(Path(output)/'ablation_start_match_audit.csv',index=False,encoding='utf-8-sig')
        atomic_json(Path(output)/'ablation_protocol.json',{
            'common_total_wall_budget_seconds': sorted(set(r['budget_seconds'] for r in rows)),
            'common_seeds': sorted(set(r['seed'] for r in rows)),
            'comparison_start': 'same parsed instance and common greedy fallback; same completed RV seed for mechanism-only controls when initialization completes',
            'wall_time_note': 'Watchdog budgets match; phase-limited stochastic trajectories may differ because mechanisms have different runtime',
            'factorial_scheduler_controls': ['rnps','legacy_initializer','legacy_phase_schedule','legacy_both'],
            'mechanism_controls': ['without_chain','without_parity','cold_repair'],
            'single_flip_control': 'rv_singleflip',
            'main_literature_table': False,
            'claim_boundary': 'Different initializer completion or repaired starts must be reported, never hidden as a pure search-mechanism effect'})


def algorithm_parameters():
    return {'cost_scale':COST_SCALE,'rnps_region_sizes':list(RNPS_REGION_SIZES),
            'rnps_phase_seconds':RNPS_PHASE_SECONDS,'rnps_descent_seconds':RNPS_DESCENT_SECONDS,
            'rnps_face_nodes':RNPS_FACE_NODES,'rnps_chain_length':RNPS_CHAIN_LENGTH,
            'rnps_chain_checks':RNPS_CHAIN_CHECKS,'rnps_initializer_fraction':RNPS_INITIALIZER_FRACTION,'rnps_initializer_max_fraction':RNPS_INITIALIZER_MAX_FRACTION,'rnps_final_reserve':RNPS_FINAL_RESERVE,
            'rnps_legacy_initializer_max_fraction':RNPS_LEGACY_INITIALIZER_MAX_FRACTION,
            'rnps_initial_descent_fraction':RNPS_INITIAL_DESCENT_FRACTION,
            'rnps_initial_descent_max_seconds':RNPS_INITIAL_DESCENT_MAX_SECONDS,
            'rnps_search_reserve_fraction':RNPS_SEARCH_RESERVE_FRACTION,
            'cold_repair_move_cache_enabled':False,
            'rnps_cycle':['chain','parity','descent','parity'],
            'cpr_cycle':['chain','joint','parity','descent','joint','parity'],
            'cpr_active_parity_regions':[24,16],
            'cpr_pool_size':CPR_POOL_SIZE,'cpr_pool_expansions':CPR_POOL_EXPANSIONS,
            'cpr_endpoint_representatives':CPR_ENDPOINT_REPRESENTATIVES,
            'cpr_pair_checks':CPR_PAIR_CHECKS,'cpr_phase_seconds':CPR_PHASE_SECONDS,
            'cpr_four_distinct_terminals':True,
            'cpr_cache_scope':'one immutable center within one phase',
            'aco_mcpp_2026':dict(ACO_2026_PARAMETERS),
            'orientation_cache_size':ORIENTATION_CACHE_SIZE,
            'grasp_candidate_list':GRASP_CANDIDATE_LIST,
            'grasp_stagnation_limit':GRASP_STAGNATION_LIMIT}


def run_plan(paths,methods,seeds,budget,output,stage,suite='literature'):
    validate_suite_methods(methods,suite)
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    code_digest=sha256_file(Path(__file__))
    identities=[{'name':load_instance(p).name,'path':str(Path(p).resolve()),'sha256':sha256_file(p)} for p in paths]
    official = known_bounds(paths)
    plan={'stage':stage,'suite':suite,'source_sha256':code_digest,'algorithm_parameters':algorithm_parameters(),
          'method_provenance':{m:method_provenance(m) for m in methods},
          'instances':identities,'official_bounds':official,'methods':methods,'seeds':seeds,'budget_seconds':budget,
          'order_policy':'cyclic method order balanced across instance and seed labels',
          'simultaneous_optimizing_processes':1,'initializer_subprocess_inside_budget':True,'solver_threads':1,'inference_unit':'instance',
          'versions':{k:importlib_metadata.version(k) for k in ['numpy','pandas','networkx','scipy','ortools','rustworkx']},
          'python':sys.version,'platform':platform.platform()}
    manifest=output/'plan.json'
    if manifest.exists() and json.loads(manifest.read_text()) != plan:
        raise ValueError('Output plan differs from frozen/resumable plan; choose a new --output directory.')
    atomic_json(manifest,plan)
    expected=len(paths)*len(methods)*len(seeds)
    scheduled=[]
    for idx,identity in enumerate(identities):
        for seed_idx,seed in enumerate(seeds):
            shift=(idx+seed_idx)%len(methods)
            order=methods[shift:]+methods[:shift]
            for method in order:
                scheduled.append({'path':identity['path'],'instance':identity['name'],
                    'instance_sha256':identity['sha256'],
                    'method':method,'seed':seed,'budget':budget,'source_sha256':code_digest,
                    'algorithm_parameters':algorithm_parameters(),'stage':stage,'suite':suite})
    pd.DataFrame(scheduled).to_csv(output/'scheduled_labels.csv',index=False,encoding='utf-8-sig')
    deterministic={}
    rows=[]
    for index,task in enumerate(scheduled):
        key=(task['instance'],task['method'])
        if task['method'] in ('modified_mixed','frederickson_1979') and key in deterministic:
            row=dict(deterministic[key],seed=task['seed'],physical_execution=False)
        else:
            print(f'[run {index+1}/{expected}] {task["instance"]} {task["method"]} seed={task["seed"]} cap={budget:g}s',flush=True)
            row=supervised_task(task,output)
            if task['method'] in ('modified_mixed','frederickson_1979'):
                deterministic[key]=row
        row.update(official.get(row['instance'], {}))
        if row['feasible'] and 'official_lower_bound' in row:
            row['gap_to_official_lower_bound_pct'] = 100*(row['cost']-row['official_lower_bound'])/row['official_lower_bound']
            row['gap_to_official_upper_bound_pct'] = 100*(row['cost']-row['official_upper_bound'])/row['official_upper_bound']
            if row['cost'] < row['official_lower_bound'] - 1e-6:
                raise ValueError('Candidate is below the supplied proven lower bound; check instance/bounds identities.')
        rows.append(row)
        atomic_json(output/'attempts.json',rows)
        print(f'  status={row["status"]} feasible={row["feasible"]} cost={row["cost"]}',flush=True)
    summarize_new_results(rows,output,expected,suite,stage)
    return rows


def known_bounds(paths):
    """Retain the supplied official LB/UB distinction; never call every UB optimal."""
    result = {}
    for parent in {Path(p).parent for p in paths}:
        path = parent / 'mcpp_bounds.csv'
        if path.exists():
            frame = pd.read_csv(path)
            required = {'instance', 'lower_bound', 'upper_bound', 'status', 'exact'}
            if not required <= set(frame.columns):
                raise ValueError('Bounds table schema is incomplete')
            for r in frame.to_dict('records'):
                result[str(r['instance'])] = {
                    'official_lower_bound': float(r['lower_bound']),
                    'official_upper_bound': float(r['upper_bound']),
                    'official_status': str(r['status']),
                    'official_exact': str(r['exact']).lower() == 'true',
                    'bounds_file_sha256': sha256_file(path),
                    'bounds_reference': 'https://www.uv.es/corberan/data/MCPP.txt'}
    return result


def self_tests(output):
    """Nontrivial checks of flow, dual cuts, face certificates and global model."""
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    checks=[]
    for seed in range(7):
        ins=generate_synthetic(f'UNIT_{seed}',6+(seed%3),.25,41000+seed,'random')
        # These small instances are exclusively validation cases, never included
        # in the fresh confirmatory set or performance statistics.
        path=output/(ins.name+'.json');dump_instance(ins,path);ins=load_instance(path)
        oracle=ExactOracle(ins)
        m=oracle.prep.m
        if m>13:
            raise AssertionError('Validation enumeration unexpectedly large')
        sols=[]
        for mask in range(1<<m):
            x=np.asarray([(mask>>j)&1 for j in range(m)],dtype=np.int8)
            sol=oracle.evaluate(x)
            oracle.audit(sol,dual=True)
            # An independently implemented NetworkX network-simplex oracle.
            g=nx.MultiDiGraph()
            supply=-oracle.prep.mandatory_balance(x)
            for i in range(oracle.prep.n):g.add_node(i,demand=-int(supply[i]))
            for j,(u,v,c) in enumerate(zip(oracle.prep.travel_tail,oracle.prep.travel_head,oracle.prep.travel_scaled)):
                g.add_edge(int(u),int(v),key=j,weight=int(c),capacity=ins.n_required+1)
            nx_cost,_=nx.network_simplex(g)
            if nx_cost != sol.scaled_extra_cost:raise AssertionError('Independent MCF engines disagree')
            sols.append(sol)
        optimum=min(s.total_cost for s in sols)
        for origin in sols:
            alpha,beta=oracle.cut(origin)
            for candidate in sols:
                value=alpha+sum(int(a)*int(b) for a,b in zip(beta,candidate.orientation))
                if value>candidate.scaled_extra_cost:raise AssertionError('A global cut overestimated recourse')
        rv=search_modified_mixed_1999(ins,SearchConfig(cost_scale=COST_SCALE,budget_seconds=30))
        oracle.audit(rv.solution)
        if rv.solution.total_cost > 1.5*optimum+1e-7:
            raise AssertionError('Modified-Mixed exceeds published ratio on validation case')
        center=sols[-1]
        model,xx,ff=direct_model(oracle,center)
        solver=cp_model.CpSolver();solver.parameters.num_search_workers=1;solver.parameters.max_time_in_seconds=10
        status=solver.solve(model)
        if status != cp_model.OPTIMAL:raise AssertionError('Small complete model not solved optimally')
        direct=candidate_from_arrays(oracle,[solver.value(v) for v in xx],[solver.value(v) for v in ff])
        oracle.audit(direct)
        if abs(direct.total_cost-optimum)>1e-7:raise AssertionError('Complete MIP disagrees with exhaustive orientations')
        face,log=network_parity_face(oracle,center,np.arange(m),time.monotonic()+20,
                                    np.random.default_rng(seed),max_nodes=200000)
        if not log['conditionally_certified'] or abs(face.total_cost-optimum)>1e-7:
            raise AssertionError('Network full-face certificate disagrees with brute-force optimum')
        if m >= 2:
            subset = np.arange(min(2, m))
            outside = np.setdiff1d(np.arange(m), subset)
            conditional = min(s.total_cost for s in sols
                              if np.array_equal(s.orientation[outside], center.orientation[outside]))
            face2, log2 = network_parity_face(oracle, center, subset, time.monotonic()+20,
                                         np.random.default_rng(seed+100),max_nodes=200000)
            if not log2['conditionally_certified'] or abs(face2.total_cost-conditional)>1e-7:
                raise AssertionError('Fixed-outside face certificate disagrees with enumeration')
        checks.append({'instance':ins.name,'orientations_exhaustively_checked':len(sols),'optimum':optimum,
                       'rv_cost':rv.solution.total_cost,'flow_and_dual':True,'all_cuts_globally_valid_on_case':True,
                       'complete_model_matches':True,'network_parity_certificate_matches':True})
        classical = search_frederickson_1979(ins, SearchConfig(seed=seed, budget_seconds=20))
        oracle.audit(classical.solution)
        if classical.solution.total_cost < optimum - 1e-7 or classical.solution.total_cost > (5/3)*optimum + 1e-7:
            raise AssertionError('Original Mixed exceeds its published bound on this validation case')
        checks[-1]['frederickson_cost'] = classical.solution.total_cost
    network_checks = network_incremental_self_tests(output/'network_incremental')
    published_checks = published_baseline_self_tests(output/'published_baselines')
    v20_checks = v20_revision_self_tests(output/'v20_revision')
    # Deliberately invalid count data must fail the independent auditor.
    wrong=copy.deepcopy(sols[0]);wrong.extra_counts=wrong.extra_counts.copy();wrong.extra_counts[0]=-1
    try:oracle.audit(wrong)
    except ValueError:pass
    else:raise AssertionError('Auditor accepted negative traversals')
    fake=output/'deadline_case';fake.mkdir(exist_ok=True)
    writer=CheckpointWriter(fake,ins,oracle,time.monotonic()-2,1)
    if writer.commit(sols[0],'late_candidate'):raise AssertionError('Accepted a late solution')
    atomic_json(output/'self_test_results.json',{'passed':True,'cases':checks,
                'negative_flow_rejected':True,'post_deadline_candidate_rejected':True,
                'published_baseline_checks':published_checks, 'network_incremental_checks':network_checks,
                'v20_revision_checks':v20_checks,
                'scope':'Correctness checks; not evidence of performance on benchmark instances.'})
    print('[self-test] PASS: independent MCF, dual/global cuts, complete model, parity certificates, published path switches, reserved phases, ACO matching/path/SGS rejection, suite separation, invalid/late candidates.',flush=True)


def v20_revision_self_tests(output):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    checks={}
    # A low-cost parallel arc must retain its own identity in the path.
    ins=MCPPInstance('ACO_PARALLEL_PATH',
        [DirectedRequired('0','1',10,'expensive'),DirectedRequired('0','1',2,'cheap'),
         DirectedRequired('1','2',2,'d12'),DirectedRequired('2','0',2,'d20')],
        [UndirectedRequired('0','2',10,'u02')])
    path=output/'parallel.json';dump_instance(ins,path);ins=load_instance(path)
    oracle=ExactOracle(ins)
    dist,paths=_aco_shortest_path_network(oracle,time.monotonic()+5)
    if dist[oracle.prep.idx['0'],oracle.prep.idx['2']]!=4 or paths(0,2)!=[1,2]:
        raise AssertionError('ACO predecessor path lost cheapest parallel source identity')
    checks['parallel_path_travel_ids']=[1,2]
    # Multiplicity requires exactly one use of each unit supply/demand token.
    weights=np.ones((4,4))
    pairs=_aco_draw_matching(weights,np.random.default_rng(11),time.monotonic()+5)
    if sorted(i for i,j in pairs)!=list(range(4)) or sorted(j for i,j in pairs)!=list(range(4)):
        raise AssertionError('ACO imbalance matching dropped or repeated a unit')
    distances=np.ones((6,6));np.fill_diagonal(distances,np.inf)
    pairs=_aco_draw_matching(_aco_probability_weights(np.ones((6,6)),distances),
                             np.random.default_rng(13),time.monotonic()+5,True)
    if sorted(v for pair in pairs for v in pair)!=list(range(6)):
        raise AssertionError('ACO odd matching dropped or repeated an odd node')
    checks['imbalance_units_and_odd_nodes_exactly_once']=True
    # Even degrees and strong physical connectivity alone are insufficient:
    # four mandatory 0->1 arcs, and only two undirected incidences at node 1.
    impossible=MCPPInstance('EVEN_MIXED_AUGMENTATION_COUNTEREXAMPLE',
        [DirectedRequired('0','1',1,'d%d'%k) for k in range(4)],
        [UndirectedRequired('1','2',1,'u12'),UndirectedRequired('2','0',1,'u20')])
    oracle2=ExactOracle(impossible)
    counts=np.zeros(len(oracle2.prep.travel_scaled),dtype=np.int64);counts[:4]=1
    candidate,reason=_aco_sgs(oracle2,counts,[0,0,1,1],np.random.default_rng(1),time.monotonic()+5)
    if candidate is not None:
        raise AssertionError('SGS accepted an augmentation violating a vertex cut')
    checks['sgs_even_degree_counterexample_rejected']=reason
    # A real two-colony pipeline on a small mixed cycle must audit its route.
    mixed=MCPPInstance('ACO_VALID_MIXED_CYCLE',
        [DirectedRequired('0','1',2,'d01')],
        [UndirectedRequired('1','2',3,'u12'),UndirectedRequired('2','0',4,'u20')])
    path=output/'valid_mixed.json';dump_instance(mixed,path);mixed=load_instance(path)
    oracle3=ExactOracle(mixed);start=time.monotonic()
    (output/'aco_valid').mkdir(exist_ok=True)
    writer=CheckpointWriter(output/'aco_valid',mixed,oracle3,start,5)
    stats={};run_aco_mcpp_2026(oracle3,start+5,2026,writer,stats)
    if writer.best is None:
        raise AssertionError('ACO pipeline failed its valid mixed-cycle fixture')
    oracle3.audit(writer.best)
    if stats['aco_exact_repair_calls']!=0:
        raise AssertionError('A hidden exact recourse repaired the published ACO construction')
    checks['mixed_cycle_checked_cost']=writer.best.total_cost
    # Integration: on a fractional large enough domain, the first descent
    # must return while both network mechanisms still have an opportunity.
    fractional=None
    for seed in range(12):
        ins=generate_synthetic('PHASE_RESERVE_FIXTURE',40,.55,64101+seed,'random')
        path=output/'phase_case.json';dump_instance(ins,path);ins=load_instance(path)
        probe=ExactOracle(ins);current=probe.evaluate(np.zeros(probe.prep.m,dtype=np.int8))
        if len(network_orientation_relaxation(probe,current.orientation)[3]):
            fractional=(ins,probe,current);break
    if fractional is None:
        raise AssertionError('No fractional scheduling fixture was constructed')
    ins,probe,current=fractional;start=time.monotonic()
    (output/'phase_reserve').mkdir(exist_ok=True)
    writer=CheckpointWriter(output/'phase_reserve',ins,probe,start,2)
    writer.commit(current,'fixture_start');stats=rnps_metric_defaults()
    run_rnps(probe,current,start+2,np.random.default_rng(19),writer,stats,'rnps')
    if not stats['phase_chain_calls'] or not stats['phase_parity_calls']:
        raise AssertionError('Reserved schedule starved chain or parity on the integration fixture')
    checks['reserved_schedule_chain_calls']=stats['phase_chain_calls']
    checks['reserved_schedule_parity_calls']=stats['phase_parity_calls']
    checks['reserved_schedule_initial_descent_seconds']=stats['phase_initial_descent_seconds']
    rejected=[]
    for method in ABLATION_METHODS[1:]:
        try:validate_suite_methods([method],'literature')
        except ValueError:rejected.append(method)
        else:raise AssertionError('Internal ablation was included in the journal main table')
    checks['main_suite_rejected_controls']=rejected
    try:validate_suite_methods(['aco_mcpp_2026'],'literature')
    except ValueError:checks['unconfirmed_scie_recent_port_rejected_by_main']=True
    else:raise AssertionError('Unconfirmed SCIE paper entered SCI main suite')
    validate_suite_methods(['aco_mcpp_2026'],'recent')
    # A cold control must genuinely call the full flow oracle even for a cached
    # direction, while ordinary cached evaluation still returns the same cost.
    x=current.orientation.copy()
    probe.evaluate(x)
    before=probe.calls
    fresh=probe.evaluate(x,use_cache=False)
    if probe.calls!=before+1 or fresh.total_cost!=probe.evaluate(x).total_cost:
        raise AssertionError('Uncached cold repair did not perform an independent exact solve')
    checks['cold_control_bypasses_direction_cache']=True
    # Deliberately retain an interrupted attempt's seed completion marker.
    # The supervisor must reject reuse before launching another optimizer.
    mock={'instance':ins.name,'method':'rnps','seed':19,'budget':2.,
          'path':str(path.resolve()),'suite':'ablation',
          'source_sha256':sha256_file(Path(__file__)),
          'instance_sha256':ins.metadata['source_sha256']}
    run_id=hashlib.sha256(json.dumps(mock,sort_keys=True).encode()).hexdigest()[:20]
    interrupted=output/'interrupted_case'/'runs'/run_id
    (interrupted/'rv_seed').mkdir(parents=True,exist_ok=True)
    atomic_json(interrupted/'task.json',{'interrupted_fixture':True})
    atomic_json(interrupted/'rv_seed/seed_completed.json',{'completed':True,'stale':True})
    try:supervised_task(mock,output/'interrupted_case')
    except FileExistsError:pass
    else:raise AssertionError('Supervisor reused an interrupted attempt or its stale seed')
    if not (interrupted/'rv_seed/seed_completed.json').exists():
        raise AssertionError('Interrupted evidence was deleted instead of being preserved')
    checks['stale_interrupted_seed_reuse_rejected']=True
    atomic_json(output/'revision_checks.json',checks)
    return checks


def published_baseline_self_tests(output):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    # This valid, deliberately nonoptimal route contains an expensive duplicate
    # 1->0. The leaf-pair switch must replace it with 1->2->0 and save exactly 3.
    ins=MCPPInstance('PUBLISHED_PATH_SWITCH',
        [DirectedRequired('0','1',9,'d0'),DirectedRequired('1','0',5,'d1')],
        [UndirectedRequired('0','2',1,'e0'),UndirectedRequired('2','1',1,'e1')])
    path=output/'case.json';dump_instance(ins,path);ins=load_instance(path)
    oracle=ExactOracle(ins)
    initial=candidate_from_arrays(oracle,[1,1],[0,1,0,0,0,0])
    if initial.total_cost != 21:raise AssertionError('Incorrect switch fixture cost')
    writer=CheckpointWriter(output,ins,oracle,time.monotonic(),10)
    stats={'opposite_copies_removed':0,'leaf_pair_checks':0,'leaf_path_switches':0}
    final=_grasp_switch_improvement(oracle,initial,_grasp_physical_graph(oracle),{},
                                   time.monotonic()+10,writer,stats)
    if final.total_cost != 18 or stats['leaf_path_switches']!=1:
        raise AssertionError('Published leaf-pair path replacement failed')
    # Deleting opposite pairs may change the mandatory direction; all counts,
    # conservation and required coverage must survive that representation change.
    total=_grasp_route_counts(oracle,initial);total[2]+=2;total[3]+=2
    cleaned,removed=_grasp_cancel_opposite_copies(oracle,total)
    if removed!=4 or not np.array_equal(cleaned,_grasp_route_counts(oracle,initial)):
        raise AssertionError('Published opposite-copy cancellation failed')
    _grasp_candidate_from_route(oracle,cleaned,'checked_cancellation')
    rejected=[]
    for method in ['without_chain','without_parity','cold_repair','rv_singleflip','full_mip']:
        try:validate_suite_methods([PROPOSED_METHOD,method],'literature')
        except ValueError:rejected.append(method)
        else:raise AssertionError('Internal control leaked into SCI main suite')
    return {'leaf_switch_cost_before':21,'leaf_switch_cost_after':18,
            'opposite_copies_removed':removed,'main_suite_rejected_controls':rejected,
            'scope':'Validation fixtures and seven small exact cases; no universal implementation-equivalence proof.'}


def legacy_orientation_audit(root,dataset,output,max_rows=0):
    """Recompute saved V17 orientations through a different compiled MCF engine.

    This verifies their fixed-orientation final cost, not the feasibility of
    unretained historical states at earlier timestamps.
    """
    suite=Path(root)/'joh_gfrq_literature_comparison_heldout_100x10'
    f=pd.read_csv(suite/'analysis/all_results.csv').query("method=='frq_sm_pb_lns'")
    if max_rows:f=f.head(max_rows)
    records=[];oracles={}
    for r in f.itertuples(index=False):
        if r.instance not in oracles:oracles[r.instance]=ExactOracle(load_instance(Path(dataset)/r.instance))
        oracle=oracles[r.instance]
        p=suite/'shards'/r.profile/r.instance/('seed_'+str(r.seed))/'run'/'runs'/r.instance/r.method/str(r.seed)/'orientation.npy'
        if not p.exists():
            records.append({'instance':r.instance,'seed':r.seed,'passed':False,'reason':'saved orientation missing'})
            continue
        x=np.load(p,allow_pickle=False)
        sol=oracle.evaluate(x,verify_dual=False)
        passed=abs(sol.total_cost-r.strict_cost)<1e-7
        records.append({'instance':r.instance,'seed':r.seed,'claimed_cost':r.strict_cost,
                        'recomputed_cost':sol.total_cost,'passed':passed})
        if len(records)%50==0:print('[route-audit]',len(records),'orientations checked',flush=True)
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(records).to_csv(output/'legacy_orientation_recomputation.csv',index=False,encoding='utf-8-sig')
    return records


def exact_validation_study(output, methods, seeds, budget, max_instances=0):
    output = Path(output)
    self_tests(output/'correctness_validation')
    paths = []
    seed = 185500
    for family in ['random','geometric']:
        for n in [8,12,16]:
            for ratio in [.3,.7]:
                for repetition in range(2):
                    name = f'EXACT_{family}_{n}_{int(ratio*100)}_{repetition}'
                    p = output/'instances'/(name+'.json')
                    ins = generate_synthetic(name,n,ratio,seed,family)
                    if p.exists():
                        previous = load_instance(p)
                        if (previous.name != name or previous.metadata.get('generation_seed') != seed):
                            raise ValueError('Existing exact validation dataset differs')
                    else:
                        dump_instance(ins,p)
                    paths.append(p)
                    seed += 1
    if max_instances:
        paths = paths[:max_instances]
    if 'full_mip' not in methods:
        raise ValueError('Exact validation requires full_mip as an independent complete-model comparator')
    rows = run_plan(paths, methods, seeds, budget, output/'experiment', 'small_exact_validation', 'validation')
    frame = pd.DataFrame(rows)
    exact = frame[(frame.method=='full_mip') & frame.get('global_optimal',pd.Series(False,index=frame.index)).eq(True) & frame.feasible]
    optima = exact.groupby('instance').cost.min().rename('proven_optimum')
    joined = frame.merge(optima.reset_index(), on='instance', how='left')
    joined['gap_to_proven_optimum_pct'] = 100*(joined.cost-joined.proven_optimum)/joined.proven_optimum
    if bool((joined.gap_to_proven_optimum_pct < -1e-7).any()):
        raise ValueError('Heuristic allegedly beats a proven optimum; investigate identities and audits')
    joined.to_csv(output/'small_instance_optimality_gaps.csv', index=False, encoding='utf-8-sig')
    atomic_json(output/'exact_validation_coverage.json', {'instances':len(paths),
               'instances_with_proven_global_optimum':len(optima),
               'unsolved_cases_retained':len(paths)-len(optima),
               'scope':'Independent complete-model proof where available; all failed or unproved cases retained.'})


def main():
    parser=argparse.ArgumentParser(description='V20 reserved RNPS scheduling, matched ablations and published-journal comparisons')
    parser.add_argument('--mode',default=PAPER_MODE,choices=['audit_and_smoke','audit','smoke','development','ablation','recent-comparison','self-test','fresh-freeze','confirmatory','exact-validation'])
    parser.add_argument('--suite',default=None,choices=list(SUITE_METHODS),help='Separate literature, internal ablation or independent validation tables')
    parser.add_argument('--dataset',default=LOCAL_DATASET_PATH)
    parser.add_argument('--history',default=HISTORICAL_RESULTS_PATH)
    parser.add_argument('--output',type=Path,default=None)
    parser.add_argument('--budget',type=float,default=None)
    parser.add_argument('--seeds',default=None,help='Comma-separated integer seed labels')
    parser.add_argument('--methods',default=None,help='Comma-separated method IDs')
    parser.add_argument('--max-instances',type=int,default=0)
    parser.add_argument('--legacy-route-audit',action='store_true')
    parser.add_argument('--legacy-max-rows',type=int,default=0)
    parser.add_argument('--fresh-input',type=Path,default=None,help='Fresh external MCPP JSON folder; omitted means new synthetic instances')
    parser.add_argument('--worker',type=Path)
    parser.add_argument('--rv-seed-worker',type=Path)
    args=parser.parse_args()
    if args.rv_seed_worker:
        rv_seed_worker(args.rv_seed_worker);return
    if args.worker:
        worker(args.worker);return
    if args.budget is not None and args.budget<=0:parser.error('--budget must be positive')
    mode=args.mode
    suite = args.suite or ('validation' if mode=='exact-validation' else 'ablation' if mode=='ablation' else 'recent' if mode=='recent-comparison' else 'literature')
    if mode=='exact-validation' and suite!='validation':parser.error('exact-validation requires the validation suite')
    if mode=='ablation' and suite!='ablation':parser.error('ablation requires the ablation suite')
    if mode=='recent-comparison' and suite!='recent':parser.error('recent-comparison requires the recent supplemental suite')
    if mode in ('audit_and_smoke','smoke','development') and suite!='literature':
        parser.error('Main comparison modes require the literature suite. Use --mode ablation for internal controls.')
    methods=args.methods.split(',') if args.methods else list(SUITE_METHODS[suite])
    try:validate_suite_methods(methods,suite)
    except ValueError as exc:parser.error(str(exc))
    seeds=[int(s) for s in args.seeds.split(',')] if args.seeds else list(DEVELOPMENT_SEEDS)
    if len(set(seeds))!=len(seeds):parser.error('Duplicate seeds')
    default_name = ('sci_main_smoke' if mode in ('audit_and_smoke','smoke')
                    else 'sci_main_development' if mode=='development'
                    else 'supplemental_ablation' if mode=='ablation' else mode.replace('-','_'))
    output=args.output or OUTPUT_ROOT/default_name
    if mode=='self-test':
        self_tests(output);return
    if mode=='exact-validation':
        exact_validation_study(output, methods,
                               [int(s) for s in args.seeds.split(',')] if args.seeds else [DEVELOPMENT_SEEDS[0]],
                               args.budget or 10.0, args.max_instances)
        return
    if mode in ['audit','audit_and_smoke','development']:
        root=find_history(args.history)
        if root:
            historical_audit(root,output/'historical_audit')
            if args.legacy_route_audit:
                legacy_orientation_audit(root,dataset_directory(args.dataset),output/'historical_audit',args.legacy_max_rows)
        else:print('[audit] No historical result folder found; new experiments can still run.',flush=True)
        if mode=='audit':return
    if mode=='fresh-freeze':
        seeds=[int(s) for s in args.seeds.split(',')] if args.seeds else list(CONFIRMATORY_SEEDS)
        freeze_fresh_set(output,methods,seeds,args.budget or CONFIRMATORY_BUDGET,args.fresh_input,suite);return
    if mode=='confirmatory':
        # Use --output to point to the folder made by fresh-freeze.
        manifest=output/'frozen_protocol.json'
        if not manifest.exists():raise FileNotFoundError('First run fresh-freeze after development. For confirmation use the SAME --output folder.')
        d=json.loads(manifest.read_text())
        frozen_suite = d.get('suite')
        if frozen_suite is None:raise ValueError('Old mixed-method protocol cannot be relabeled as a literature experiment. Freeze a new correctly separated protocol.')
        if args.suite is not None and suite!=frozen_suite:raise ValueError('Suite differs from frozen protocol')
        validate_suite_methods(d['methods'],frozen_suite)
        if d['source_sha256']!=sha256_file(Path(__file__)) or d['algorithm_parameters']!=algorithm_parameters():
            raise ValueError('Algorithm changed after fresh-set freeze; confirmation blocked for this protocol.')
        if args.budget is not None and args.budget!=d['budget']:raise ValueError('Budget differs from frozen protocol')
        if args.methods and methods!=d['methods']:raise ValueError('Methods differ from frozen protocol')
        if args.seeds and seeds!=d['seeds']:raise ValueError('Seeds differ from frozen protocol')
        if args.max_instances:raise ValueError('A confirmatory run cannot silently omit frozen instances')
        paths=[]
        for e in d['instances']:
            p=output/e['relative_path']
            if sha256_file(p)!=e['sha256']:raise ValueError('Frozen dataset bytes changed')
            paths.append(p)
        run_plan(paths,d['methods'],d['seeds'],d['budget'],output/'confirmation',d['stage'],frozen_suite);return
    dataset=dataset_directory(args.dataset)
    names=list(DEVELOPMENT_INSTANCES)
    if mode in ['smoke','audit_and_smoke','recent-comparison']:
        if mode!='recent-comparison':self_tests(output/'correctness_validation')
        names=names[:3]
        seeds=[int(s) for s in args.seeds.split(',')] if args.seeds else [DEVELOPMENT_SEEDS[0]]
        budget=args.budget or SMOKE_BUDGET
        stage=('supplemental_recent_published_method_port_check' if mode=='recent-comparison'
               else 'smoke_only_not_publication_performance')
    else:
        budget=args.budget or DEVELOPMENT_BUDGET
        stage='internal_ablation_old_development20_only' if suite=='ablation' else 'development_old_development20_only'
    if args.max_instances:names=names[:args.max_instances]
    paths=[dataset/n for n in names]
    print('[suite]',suite,'methods=',','.join(methods),flush=True)
    rows=run_plan(paths,methods,seeds,budget,output/'experiment',stage,suite)
    print('[done] Results:',output,flush=True)
    print('[interpretation] This run establishes only its recorded stage. It does not establish superiority or journal acceptance.',flush=True)


if __name__=='__main__':
    main()
