# 三城九图 60 秒复现与 V21 联合路径候选工程

本工程包含完整优化器、冻结道路子图、实验调度器、独立路线审计器和机制测试。
不需要下载原始 PBF，不需要 GPU，也不安装或使用 PyTorch。

## 在 Windows/PyCharm 运行

1. 将 ZIP **完整解压**为一个文件夹，例如 `E:\PythonProject8\V21_Coupled_Path_MCPP_Kit`。
   `V20_RNPS_MCPP.py`、`V21_Coupled_RNPS_MCPP.py`、各入口和 `osm_data` 必须保持在
   同一个工程目录。不要只取一个入口文件。
2. PyCharm 打开这个文件夹，解释器选你已有的
   `C:\Path\To\python.exe`。本包在 Python 3.12.14/Linux
   验证；Windows 入口使用标准子进程方式，没有 fork 或 pickle 依赖。
3. 在该解释器的终端安装算法依赖。已存在且满足版本范围的包会保留：

```bat
cd /d E:\PythonProject8\V21_Coupled_Path_MCPP_Kit
C:\Path\To\python.exe -m pip install -r requirements.txt
```

4. 先右键运行 `Check_Environment.py` 和 `Verify_Package.py`，再运行
   `Run_V21_Mechanism_Tests.py` 与 `Run_V21_Smoke.py`。
5. 正式实验按下表选择入口。可直接在 PyCharm 右键 Run；不需要填命令行参数。

| 入口 | 默认任务 | 结果目录 |
| --- | --- | --- |
| `Run_V20_ThreeCity_60s.py` | 论文对应 V20；九图×四方法×五种子；每次名义 60 秒 | `results/v20_formal` |
| `Run_V21_ThreeCity_60s.py` | V21 候选；同样九图、四方法、五种子、60 秒 | `results/v21_formal` |
| `Run_V21_Ablation_60s.py` | 独立内部消融；九图×六方法×五种子；60 秒 | `results/v21_ablation` |
| `Run_Exact_Validation.py` | 九图的完整模型验证，每图 30 秒 | `results/v21_validation` |
| `Run_V21_Smoke.py` | 三个 n100 图、一个种子、四方法、8 秒 | `results/v21_smoke` |
| `Run_V21_Mechanism_Tests.py` | 独立流、精确修复、构造例及非法/过期移动测试 | `results/mechanism_tests` |

主比较的四个方法是 `cprnps`/原 V20 的 `rnps`、Modified Mixed、Frederickson、GRASP。
后面三个是已发表期刊方法的独立实现，不是作者官方软件。V21 的内部消融为
`cprnps`、`rnps`、`cprnps_no_joint`、`cprnps_no_screen`、`cprnps_no_signature`、
`cprnps_cold_joint`。旧版本和删减方案不放进主比较。

正式实验为 **180 行种子标签、108 次物理执行**。RNPS/CPRNPS 和 GRASP 各 45 次；
两个确定性方法各九次，复用其结果至五个种子标签。不能把这些标签当作 180 个
独立重复。内部消融是 270 次物理执行。串行满预算估算主比较约 90 分钟加启动
和审计开销，内部消融约 4.5 小时加开销；自然提前结束会缩短时间。

## 可选命令

核对九图及配置、只生成协议，不运行优化器：

```bat
python Run_V21_ThreeCity_60s.py --plan-only --output results\v21_formal
```

正式运行或复用同协议下已完成的结果：

```bat
python Run_V20_ThreeCity_60s.py
python Run_V21_ThreeCity_60s.py
python Run_V21_Ablation_60s.py
python Run_Exact_Validation.py
```

只检查大图的新算子：

```bat
python Run_V21_ThreeCity_60s.py --targets 1000 --seeds 180201 --budget 8 --methods cprnps --output results\v21_large_smoke
```

单独检查近期移植，输出与主比较分开。这个入口沿用独立 ACO 移植，不表示作者
软件的数值复现已经完成：

```bat
python ThreeCity_Experiment.py --version v21 --profile recent --targets 100 --seeds 180201 --budget 8 --output results\v21_recent_check
```

核对实际联合移动的成本。这里的冷流复算在优化结束后运行，其耗时不冒充搜索
性能：

```bat
python Audit_Joint_Moves.py --results results\v21_formal
```

若使用上述示例中的 `python`，必须确保终端已激活与 PyCharm 相同的解释器，
否则用第 3 步所列完整解释器路径替换 `python`。

## 怎样读结果

- `protocol.json` 和 `experiment/plan.json`：源码、输入、依赖、CPU/内存信息及预算。
- `experiment/all_attempts.csv`：保留全部标签，包括失败与不完整计数。
- `experiment/graph_method_summary.csv`：每图每方法的完整组均值、最好成本和实际执行数。
- `experiment/descriptive_comparison_summary.csv`：相对成本降低的宏平均和胜/平/负，
  只采用完整的图组，同时原始失败仍留在总表。
- `experiment/ablation_start_matching.csv`：消融起点一致性；仅消融套件生成。
- `experiment/joint_mechanism_physical_runs.csv`：联合候选、筛选、缓存、接受数及阶段时间。
- `experiment/runs/*/joint_moves.jsonl`：真实接收的联合移动及其独立单路径变化量；
  单路径复核未完成会标记未知，不会当作成功跨越停滞。
- `independent_route_audit.json`：原始计数、方向、闭合 Euler 行走、成本和候选时间审计。

## 数据和预算边界

九图是北京、上海、重庆各三个 target 标识：100、300、1000。实际节点数不同，
最高为 1341；target 不是保证的图大小。额外三个 n12 图保留原始转换清单，
仅作为可选的小图验证输入。优化使用预先转换好的 JSON，费用单位是整数厘米。
所有道路需要服务，数据不包含转弯禁令、车辆约束或整座城市覆盖保证。

V20 源码逐字节保留，SHA-256 为
`6e4177fa067fa820e9280805805b9045b6e876ace8033bf1a865638b2bfcf11a`。
V21 会生成不同源码哈希和新的输出目录。不能将 V20 的成本表标成 V21 的结果。
源码、输入、配置或依赖环境改变后，必须换新输出目录。未完成的旧尝试必须
保留，重试时使用新的 `--output`，防止把旧初始化结果作为免费起点。

60 秒是工作进程搜索窗口，顶层启动/import 与运行后导出分开记录。V21 新增监督
轮询最大间隔、检测截止、请求终止与观察退出时间。操作系统暂停等情形仍可能
产生墙钟超时；记录所有超时，不承诺严格 60 秒进程退出。

`requirements-tested.txt` 对应本次验证环境，`requirements-v20-archive.txt` 仅保留
旧包的版本记录。没有在你的 Windows 机器上自动执行或修改现有工程。

本包交付的 `verification_evidence` 只含本次实际执行的检查，不能当成新的
九图 60 秒正式结果。创新处理和构造例的证据范围见 `NOVELTY_AND_VALIDATION_CN.md`。
代码正确、构造例成立和性能超越是三个不同结论。

OSM 归属和许可见 `DATA_LICENSE_OSM.txt`。本包不为原始研究代码和数据重新指定
统一许可。
