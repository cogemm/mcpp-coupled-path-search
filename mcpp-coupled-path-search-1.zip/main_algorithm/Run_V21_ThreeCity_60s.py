"""Nine graphs, five seeds, nominal 60 seconds, published comparisons only."""
import sys
from ThreeCity_Experiment import main
if __name__ == '__main__':
    main(['--version', 'v21', '--profile', 'formal', *sys.argv[1:]])
