"""Check this interpreter and the native flow library without installing anything."""
import importlib.metadata as metadata
import json
import os
import platform
import sys

for name in ['OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'NUMEXPR_NUM_THREADS']:
    os.environ[name] = '1'


def main():
    report = {'python': sys.version, 'executable': sys.executable,
              'platform': platform.platform(), 'packages': {}, 'missing': []}
    for name in ['numpy', 'pandas', 'networkx', 'scipy', 'ortools', 'rustworkx']:
        try:
            report['packages'][name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            report['missing'].append(name)
    print(json.dumps(report, indent=2), flush=True)
    if report['missing']:
        raise SystemExit('Missing packages. In this interpreter run: python -m pip install -r requirements.txt')
    from ortools.graph.python import min_cost_flow
    solver = min_cost_flow.SimpleMinCostFlow()
    solver.add_arc_with_capacity_and_unit_cost(0, 1, 3, 7)
    solver.set_node_supply(0, 2)
    solver.set_node_supply(1, -2)
    if solver.solve() != solver.OPTIMAL or solver.optimal_cost() != 14:
        raise SystemExit('Native minimum-cost flow verification failed.')
    print('[environment] PASS: selected interpreter and native min-cost flow', flush=True)


if __name__ == '__main__':
    main()
