"""Reproduce the original nine-graph V20 60-second experiment."""
import sys
from ThreeCity_Experiment import main
if __name__ == '__main__':
    main(['--version', 'v20', '--profile', 'formal', *sys.argv[1:]])
