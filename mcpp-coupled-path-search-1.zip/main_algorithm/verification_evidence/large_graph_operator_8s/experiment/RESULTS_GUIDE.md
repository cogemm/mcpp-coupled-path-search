# MCPP experiment result: ablation

Stage: exploratory_three_city_v21_ablation

Complete protocol: **True**. Observed 9 labels; failed 0.

A feasible initializer preserved by construction is not evidence that the added search helps.
Use paired_instance_comparisons.csv and report ties, losses, confidence intervals and all failures.
Do not call a face-optimality certificate a global MCPP optimality certificate.
Average cost over successful instances is descriptive when the protocol is incomplete.
