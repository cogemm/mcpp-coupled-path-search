"""Independent flow checks, exhaustive pair checks and a strict path-local witness.

These constructed instances test mathematical correctness and neighborhood
separation. They are never included in the road performance tables.
"""
from pathlib import Path
import argparse
import itertools
import time
import json
import V21_Coupled_RNPS_MCPP as core

ROOT = Path(__file__).resolve().parent


def independent_flow_cost(oracle, x):
    p = oracle.prep
    graph = core.nx.MultiDiGraph()
    supply = -p.mandatory_balance(x)
    for v in range(p.n):
        graph.add_node(v, demand=-int(supply[v]))
    for a, (u, v, c) in enumerate(zip(p.travel_tail, p.travel_head, p.travel_scaled)):
        graph.add_edge(int(u), int(v), key=a, weight=int(c), capacity=oracle.ins.n_required + 1)
    return int(core.nx.network_simplex(graph)[0])


def enumerate_paths(oracle, center):
    p = oracle.prep
    tail = core.np.where(center.orientation == 1, p.edge_u, p.edge_v)
    head = core.np.where(center.orientation == 1, p.edge_v, p.edge_u)
    adj = [[] for _ in range(p.n)]
    for j, (u, v) in enumerate(zip(tail, head)):
        adj[int(u)].append((int(v), j))
    result = []
    for source in range(p.n):
        queue = [(source, (), {source})]
        while queue:
            at, edges, seen = queue.pop()
            for target, edge in adj[at]:
                if target not in seen:
                    path = core.ServicePath(source, target, edges + (edge,))
                    result.append(path)
                    if len(path.edges) < core.RNPS_CHAIN_LENGTH:
                        queue.append((target, path.edges, seen | {target}))
    return result


def run_tests(output):
    output.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    totals = {'orientations': 0, 'joint_pairs': 0, 'safe_rejections': 0,
              'independent_network_simplex_checks': 0, 'path_bundle_checks': 0}
    for seed in range(4):
        ins = core.generate_synthetic('JOINT_UNIT_' + str(seed), 6, .40, 79000 + seed, 'random')
        path = output / (ins.name + '.json')
        core.dump_instance(ins, path)
        oracle = core.ExactOracle(core.load_instance(path))
        p = oracle.prep
        if p.m > 10:
            raise AssertionError('Test orientation domain is unexpectedly large.')
        solutions = {}
        for mask in range(1 << p.m):
            x = core.np.array([(mask >> j) & 1 for j in range(p.m)], dtype=core.np.int8)
            center = oracle.evaluate(x)
            oracle.audit(center, dual=True)
            if independent_flow_cost(oracle, x) != center.scaled_extra_cost:
                raise AssertionError('Independent MCF solvers disagree.')
            solutions[mask] = center
            totals['orientations'] += 1
            totals['independent_network_simplex_checks'] += 1
        for mask, center in solutions.items():
            paths = enumerate_paths(oracle, center)
            singles = [path for path in paths if len(path.edges) == 1]
            for first, second in itertools.combinations(singles, 2):
                if len({first.source, first.target, second.source, second.target}) != 4:
                    continue
                indices = first.edges + second.edges
                expected = solutions[mask ^ sum(1 << j for j in indices)]
                delta = expected.scaled_extra_cost - center.scaled_extra_cost
                stats = core.rnps_metric_defaults()
                result = core.repair_service_bundle(oracle, center, (first, second), stats=stats, screen=False)
                candidate = core.ResidualNetwork(oracle, stats).candidate(center, list(indices), result)
                if candidate.scaled_extra_cost != expected.scaled_extra_cost:
                    raise AssertionError('Warm joint recourse disagrees with independent cold optimum.')
                reverse_order = core.repair_service_bundle(oracle, center, (second, first), stats=stats, screen=False)
                if reverse_order[0] != delta or result[0] != delta:
                    raise AssertionError('Joint objective incorrectly depends on repair order.')
                lower = core.bundle_dual_bound(center, (first, second))
                if lower > delta:
                    raise AssertionError('Joint dual screen overestimated the exact delta.')
                rejected = core.repair_service_bundle(oracle, center, (first, second), stats=stats, screen=True)
                if not rejected[3]:
                    if rejected[0] < 0 or delta < rejected[0]:
                        raise AssertionError('Unsafe lower-bound rejection.')
                    try:
                        core.ResidualNetwork(oracle, stats).candidate(center, list(indices), rejected)
                    except ValueError:
                        pass
                    else:
                        raise AssertionError('A rejection bound became a route.')
                    totals['safe_rejections'] += 1
                totals['joint_pairs'] += 1
            # Exercise longer service paths without quadratic exhaustive growth.
            bundles = [(a, b) for a, b in itertools.combinations(paths, 2)
                       if len(a.edges) + len(b.edges) > 2 and
                       not set(a.edges).intersection(b.edges) and
                       len({a.source, a.target, b.source, b.target}) == 4]
            for first, second in bundles[:4]:
                indices = first.edges + second.edges
                expected = solutions[mask ^ sum(1 << j for j in indices)]
                result = core.repair_service_bundle(oracle, center, (first, second), screen=False)
                if result[0] != expected.scaled_extra_cost - center.scaled_extra_cost:
                    raise AssertionError('Longer path bundle has the wrong joint delta.')
                totals['path_bundle_checks'] += 1

    fixture = ROOT / 'fixtures/joint_barrier_fixture.json'
    expected = json.loads((ROOT / 'fixtures/joint_barrier_fixture_expected.json').read_text(encoding='utf-8'))
    oracle = core.ExactOracle(core.load_instance(fixture))
    center = oracle.evaluate(expected['orientation'])
    paths = tuple(core.ServicePath(r['source'], r['target'], tuple(r['edges'])) for r in expected['paths'])
    deltas = []
    for path in enumerate_paths(oracle, center):
        x = center.orientation.copy()
        x[list(path.edges)] = 1 - x[list(path.edges)]
        deltas.append(independent_flow_cost(oracle, x) - center.scaled_extra_cost)
    if min(deltas) < 0 or len(deltas) != expected['all_simple_service_paths_length_at_most_4']:
        raise AssertionError('The strict single-path local-optimum witness is invalid.')
    result = core.repair_service_bundle(oracle, center, paths, screen=False)
    cold = core.repair_service_bundle(oracle, center, paths, cold=True, screen=False)
    reverse = core.repair_service_bundle(oracle, center, paths[::-1], screen=False)
    if result[0] != -27 or cold[0] != -27 or reverse[0] != -27:
        raise AssertionError('Constructed joint barrier witness failed.')
    # Search must actually discover and accept this four-terminal move.
    stats = core.rnps_metric_defaults()
    log_folder = output / 'witness_logged_move'
    log_folder.mkdir(exist_ok=True)
    clock = time.monotonic()
    writer = core.CheckpointWriter(log_folder, oracle.ins, oracle, clock, 10)
    writer.commit(center, 'constructed_witness_initial')
    core.atomic_json(log_folder / 'task.json', {
        'instance': oracle.ins.name, 'method': 'cprnps', 'seed': 1,
        'source_sha256': core.sha256_file(Path(core.__file__)),
        'instance_sha256': core.sha256_file(fixture),
        'stage': 'constructed_mechanism_test_only',
    })
    (output / (oracle.ins.name + '.json')).write_bytes(fixture.read_bytes())
    candidate = core.coupled_path_search(oracle, center, time.monotonic() + 10,
                                         core.np.random.default_rng(1), stats, writer)
    if candidate.total_cost >= center.total_cost or stats.get('joint_barrier_crossings', 0) < 1:
        raise AssertionError('Joint search failed to expose the constructed barrier.')
    for method in ['cprnps_no_screen', 'cprnps_no_signature', 'cprnps_cold_joint']:
        control = core.coupled_path_search(oracle, center, time.monotonic() + 10,
                                           core.np.random.default_rng(1), core.rnps_metric_defaults(), method=method)
        if control.total_cost >= center.total_cost:
            raise AssertionError('A joint control failed the constructed improvement: ' + method)
    snapshot = (center.orientation.tobytes(), center.extra_counts.tobytes(), center.dual_potential.tobytes())
    for invalid in [(paths[0], paths[0]), (core.ServicePath(paths[0].target, paths[0].source, paths[0].edges), paths[1])]:
        try:
            core.repair_service_bundle(oracle, center, invalid, screen=False)
        except ValueError:
            pass
        else:
            raise AssertionError('Invalid path bundle was accepted.')
    try:
        core.repair_service_bundle(oracle, center, paths, deadline=time.monotonic() - 1, screen=False)
    except TimeoutError:
        pass
    else:
        raise AssertionError('Expired joint candidate was accepted.')
    if snapshot != (center.orientation.tobytes(), center.extra_counts.tobytes(), center.dual_potential.tobytes()):
        raise AssertionError('A trial repair modified its incumbent in place.')

    alias = core.MCPPInstance('SIGNATURE_ALIAS',
        [core.DirectedRequired(str(a), str(b), 1, 'd' + str(i))
         for i, (a, b) in enumerate([(0,4),(4,5),(5,3),(3,2),(2,1),(1,0)])],
        [core.UndirectedRequired(str(a), str(b), c, 'e' + str(i))
         for i, (a,b,c) in enumerate([(0,1,2),(1,3,3),(0,2,4),(2,3,5),(4,5,6)])])
    alias_path = output / 'signature_alias.json'
    core.dump_instance(alias, alias_path)
    oracle = core.ExactOracle(core.load_instance(alias_path))
    center = oracle.evaluate([1,1,1,1,1])
    bundle_a = (core.ServicePath(0,3,(0,1)), core.ServicePath(4,5,(4,)))
    bundle_b = (core.ServicePath(0,3,(2,3)), core.ServicePath(4,5,(4,)))
    if core.bundle_signature(bundle_a) != core.bundle_signature(bundle_b):
        raise AssertionError('Alias signatures differ.')
    shared = core.repair_service_bundle(oracle, center, bundle_a, screen=False)
    stats = core.rnps_metric_defaults()
    reused = core.ResidualNetwork(oracle, stats).candidate(center, [2,3,4], shared)
    if reused.scaled_extra_cost != independent_flow_cost(oracle, reused.orientation):
        raise AssertionError('Signature reuse changed the optimum or feasibility.')

    bottleneck = core.MCPPInstance('JOINT_CAPACITY_ONE', [],
        [core.UndirectedRequired('0','1',3,'e0'), core.UndirectedRequired('1','2',7,'e1'),
         core.UndirectedRequired('2','3',5,'e2')])
    bottleneck_path = output / 'capacity_one.json'
    core.dump_instance(bottleneck, bottleneck_path)
    oracle = core.ExactOracle(core.load_instance(bottleneck_path))
    center = oracle.evaluate([1,1,1])
    stats = core.rnps_metric_defaults()
    result = core.repair_service_bundle(oracle, center,
        (core.ServicePath(0,1,(0,)), core.ServicePath(2,3,(2,))), stats=stats, screen=False)
    candidate = core.ResidualNetwork(oracle, stats).candidate(center, [0,2], result)
    if stats['residual_shortest_paths'] < 4 or candidate.scaled_extra_cost != independent_flow_cost(oracle, candidate.orientation):
        raise AssertionError('A one-copy reverse arc incorrectly carried two units.')
    report = {
        'passed': True, 'source_sha256': core.sha256_file(Path(core.__file__)),
        'totals': totals, 'elapsed_seconds': time.monotonic() - started,
        'strict_single_path_local_witness': expected,
        'invalid_bundle_rejected': True, 'expired_trial_rejected': True,
        'incumbent_unchanged_by_trials': True, 'capacity_one_respected': True,
        'balance_signature_alias_verified': True,
        'scope': 'Constructed correctness and separation tests only; no road-performance or literature-novelty conclusion.',
    }
    core.atomic_json(output / 'joint_mechanism_validation.json', report)
    print('[mechanism-test] PASS', json.dumps(totals), flush=True)
    print('[witness] separate changes=0,0; joint change=-27; all 12 single service paths nonimproving', flush=True)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'results/mechanism_tests')
    args = parser.parse_args()
    run_tests(args.output.resolve())


if __name__ == '__main__':
    main()
