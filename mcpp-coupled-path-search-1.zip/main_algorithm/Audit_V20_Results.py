"""Independently audit saved V20 route counts and Euler walks; never optimize.

PyCharm: set RESULTS_ROOT below, or pass --results and --dataset.
Original Windows absolute paths are resolved by instance name and SHA256.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import math
from collections import Counter
from decimal import Decimal
from pathlib import Path
import networkx as nx
import numpy as np
from V20_RNPS_MCPP import load_instance, sha256_file, atomic_json

ROOT = Path(__file__).resolve().parent
RESULTS_ROOT = ROOT / "v20_results"


def count_solution(ins, candidate):
    """Reconstruct directly from public instance data, not the solver auditor."""
    travel = ins.travel_arcs()
    with np.load(candidate, allow_pickle=False) as z:
        x, f = z['orientation'], z['extra_counts']
        if x.shape != (len(ins.undirected),) or f.shape != (len(travel),):
            raise ValueError('Incorrect array dimensions')
        if not np.all((x == 0) | (x == 1)):
            raise ValueError('Nonbinary service directions')
        if not np.all(np.isfinite(f)) or not np.all(f >= 0) or not np.all(f == np.rint(f)):
            raise ValueError('Nonintegral or negative traversal counts')
        declared = Decimal(str(float(z['total_cost'])))
        if not np.isfinite(z['scaled_extra_cost']) or z['scaled_extra_cost'] != np.rint(z['scaled_extra_cost']):
            raise ValueError('Nonintegral declared extra objective')
        declared_extra = int(z['scaled_extra_cost'])
    arcs = Counter()
    balance = Counter()
    total = Decimal(0)
    extra = Decimal(0)
    for a in ins.directed:
        arcs[(a.tail, a.head, a.source_id, Decimal(str(a.cost)), True)] += 1
    for bit, e in zip(x, ins.undirected):
        u, v = (e.u, e.v) if bit else (e.v, e.u)
        arcs[(u, v, e.source_id, Decimal(str(e.cost)), True)] += 1
    for q, a in zip(f, travel):
        if q:
            arcs[(a.tail, a.head, a.source_id, Decimal(str(a.cost)), False)] += int(q)
            extra += int(q) * Decimal(str(a.cost))
    graph = nx.DiGraph()
    for (u, v, source, cost, service), q in arcs.items():
        balance[u] += q
        balance[v] -= q
        total += q * cost
        graph.add_edge(u, v)
    if any(balance.values()) or not graph or not nx.is_strongly_connected(graph):
        raise ValueError('Unbalanced or disconnected directed route support')
    if total != declared or extra != Decimal(declared_extra):
        raise ValueError('Independently reconstructed integer objective differs')
    return total, arcs


def audit_euler(path, expected):
    actual = Counter()
    first = previous = None
    length = 0
    with path.open(encoding='utf-8-sig', newline='') as fh:
        for i, row in enumerate(csv.DictReader(fh)):
            if int(row['step']) != i or row['service'] not in ('True', 'False'):
                raise ValueError('Invalid Euler step or service marker')
            if first is None:
                first = row['tail']
            if previous is not None and previous != row['tail']:
                raise ValueError('Discontinuous Euler walk')
            previous = row['head']
            actual[(row['tail'], row['head'], row['source_id'],
                    Decimal(row['cost']), row['service'] == 'True')] += 1
            length += 1
    if not length or previous != first or actual != expected:
        raise ValueError('Euler walk closure, counts, directions or coverage mismatch')
    return length


def audit_tree(results, dataset, destination, all_candidates=False, source_path=None):
    results, dataset = Path(results), Path(dataset)
    source_path = Path(source_path) if source_path is not None else ROOT / 'V20_RNPS_MCPP.py'
    source_sha = sha256_file(source_path)
    cache = {}
    report = []
    for path in sorted(results.rglob('result.json')):
        folder = path.parent
        if not folder.joinpath('task.json').exists():
            continue
        row = json.loads(path.read_text(encoding='utf-8'))
        task = json.loads(folder.joinpath('task.json').read_text(encoding='utf-8'))
        record = {k: row.get(k) for k in ('instance', 'method', 'seed', 'execution_id', 'cost')}
        try:
            for k in ('instance', 'method', 'seed'):
                if row[k] != task[k]:
                    raise ValueError('Task/result label mismatch: ' + k)
            digest = hashlib.sha256(json.dumps(task, sort_keys=True).encode()).hexdigest()
            if digest != row['task_digest']:
                raise ValueError('Saved task digest mismatch')
            if task['source_sha256'] != source_sha or row['source_sha256'] != source_sha:
                raise ValueError('Source identity mismatch')
            identity = (task['instance'], task['instance_sha256'])
            if identity not in cache:
                candidates = [dataset / task['instance'], dataset / (task['instance'] + '.json')]
                candidates.extend(dataset.rglob(task['instance'] + '.json'))
                data = next((p for p in candidates if p.is_file() and
                             sha256_file(p) == identity[1]), None)
                if data is None:
                    raise FileNotFoundError('Matching input bytes unavailable: ' + task['instance'])
                cache[identity] = load_instance(data)
            ins = cache[identity]
            if row['instance_sha256'] != identity[1]:
                raise ValueError('Result input identity mismatch')
            if not row['feasible']:
                if row.get('cost') is not None or row.get('audit_error') or row.get('worker_error'):
                    raise ValueError('Failed attempt has an inconsistent objective or execution/audit error')
                if folder.joinpath('checkpoint.json').exists():
                    raise ValueError('An allegedly empty attempt contains a committed checkpoint')
                record.update(passed=True, status='recorded_no_feasible_incumbent', feasible_route_verified=False)
                report.append(record)
                continue
            checkpoint = json.loads(folder.joinpath('checkpoint.json').read_text(encoding='utf-8'))
            if checkpoint['instance_sha256'] != identity[1] or row['instance_sha256'] != identity[1]:
                raise ValueError('Input identity mismatch')
            events = checkpoint['events']
            if not events or checkpoint['event'] != events[-1]:
                raise ValueError('Final checkpoint does not match final event')
            previous_time, previous_cost = -1., float('inf')
            for event in events:
                elapsed, cost = float(event['elapsed_seconds']), float(event['best_cost'])
                if not math.isfinite(elapsed) or not 0 <= elapsed <= float(task['budget']):
                    raise ValueError('Candidate outside recorded budget')
                if elapsed < previous_time or cost > previous_cost:
                    raise ValueError('Nonmonotone checkpoint history')
                candidate = folder / event['candidate']
                if not candidate.resolve().is_relative_to(folder.resolve()):
                    raise ValueError('Invalid candidate path')
                if sha256_file(candidate) != event['candidate_sha256']:
                    raise ValueError('Candidate identity mismatch')
                if all_candidates:
                    reconstructed, _ = count_solution(ins, candidate)
                    if reconstructed != Decimal(str(cost)):
                        raise ValueError('Historical candidate objective mismatch')
                previous_time, previous_cost = elapsed, cost
            total, counts = count_solution(ins, folder / events[-1]['candidate'])
            if total != Decimal(str(row['cost'])) or total != Decimal(str(previous_cost)):
                raise ValueError('Result differs from final checkpoint')
            length = audit_euler(folder / 'euler_tour.csv', counts)
            record.update(passed=True, status='valid', candidate_events=len(events),
                          feasible_route_verified=True,
                          euler_steps=length, final_recorded_seconds=previous_time,
                          budget_seconds=float(task['budget']))
        except Exception as exc:
            record.update(passed=False, status='audit_failed', error=str(exc))
        report.append(record)
        if len(report) % 25 == 0:
            print('[audit]', len(report), 'physical runs checked', flush=True)
    if not report:
        raise FileNotFoundError('No physical result.json + task.json pairs found')
    output = {'passed': all(r['passed'] for r in report), 'physical_runs': len(report),
              'passed_runs': sum(r.get('feasible_route_verified',False) for r in report), 'source_sha256': source_sha,
              'records_with_valid_identities':sum(r['passed'] for r in report),
              'recorded_no_feasible_incumbents':sum(r['status']=='recorded_no_feasible_incumbent' for r in report),
              'all_attempts_feasible':all(r.get('feasible_route_verified',False) for r in report),
              'auditor_sha256':sha256_file(Path(__file__)),
              'expected_solver_source_path':str(source_path.resolve()),
              'all_committed_candidates_reconstructed': all_candidates, 'records': report,
              'scope': 'Saved route feasibility, exact costs, Euler counts, identities and recorded candidate deadlines; not execution attestation or global optimality.'}
    atomic_json(destination, output)
    print('[audit] PASS' if output['passed'] else '[audit] FAIL',
          'verified routes=',output['passed_runs'],'recorded empty attempts=',output['recorded_no_feasible_incumbents'],
          'physical attempts=',len(report),flush=True)
    return output


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--results', type=Path, default=RESULTS_ROOT)
    p.add_argument('--dataset', type=Path, default=ROOT / 'data/corberan_mcpp_benchmark')
    p.add_argument('--output', type=Path, default=ROOT / 'review/independent_route_audit.json')
    p.add_argument('--all-candidates', action='store_true')
    p.add_argument('--source',type=Path,default=None,help='Actual frozen source snapshot for archived builds; default current solver')
    args = p.parse_args()
    result = audit_tree(args.results, args.dataset, args.output, args.all_candidates,args.source)
    if not result['passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
