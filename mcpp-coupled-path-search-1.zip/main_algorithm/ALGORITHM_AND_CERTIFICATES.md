# Coupled service-path reversal: implementation and claim boundaries

The V21 method identifier is `cprnps`. This is an experimental extension of the
frozen V20 implementation. The word “coupled” describes a joint cost evaluation;
it does not establish priority in the MCPP literature.

## Representation and assumptions

Every required undirected physical link has one binary service orientation. A
required directed link retains its permitted direction. Additional traversals
use the fixed permitted travel network. Costs are positive integer centimeters
for the supplied road data, with symmetric costs on each undirected link.
Required support is connected and spans the modeled vertices. Every accepted
solution is independently checked for binary orientations, integer multiplicities,
conservation, connected directed support, coverage, and exact cost.

Let the incidence matrix use +1 at an arc's tail and -1 at its head. The
fixed-orientation extra-flow problem is

$$Q(x)=\min\{c^T f:Nf=-b(x),\ f\geq0,\ f\text{ integer}\}.$$

The constant mandatory service cost is unchanged by service-orientation flips.
An optimal extra flow has a verified dual potential with

$$c_a-\pi_{\mathrm{tail}(a)}+\pi_{\mathrm{head}(a)}\geq0,$$

with equality on positive-flow arcs and equality of the primal and dual objectives.
These are classical minimum-cost flow optimality conditions.

## Joint move and exact evaluation

Select two currently directed simple paths of required undirected service links.
They are edge-disjoint and have four distinct terminals. For path i directed from
s_i to t_i, reversing its service directions changes mandatory imbalance by
-2(e_s_i - e_t_i). For the joint move,

$$r=2(e_{s_1}-e_{t_1}+e_{s_2}-e_{t_2})$$

is the change in extra-flow supply. The four-terminal restriction distinguishes
this imbalance from that of one open service-path reversal. It does not distinguish
the move from all existing parity, circulation, or broader orientation neighborhoods.

`repair_service_bundle` repairs the first path by two residual units. It updates
extra counts, finite reverse capacities, and the feasible dual potential before
repairing the second path. Forward residual arcs permit additional travel;
reverse arcs have capacity equal to the currently present extra count and negative
original cost. A one-copy reverse arc cannot carry two units.

Each two-unit repair ends at an optimal flow for the corresponding new supply.
Applying the next repair to this updated optimum therefore gives the optimal
flow for the final supply. The order can change the selected optimal flow but
cannot change its objective. This follows from standard residual reoptimization,
not a new half-integrality theorem. With two paths, at most four unit/bottleneck
augmentations are needed, each evaluated by a feasible-potential Dijkstra scan.
The implemented per-move bound is O(|T| + |V| + 4(|T| + |V| log |V|)), apart from
route/dual auditing and memory allocation. No bound is asserted for the quality
of the bounded heuristic search.

Summing both independent original-state deltas is invalid: the first repair
can change the capacity and price information used by the second. Intermediate
nonimproving states are never installed as timed incumbents. The final candidate
must pass the full count/dual audit and the checkpoint time test.

## Safe screening and reuse

The incumbent's verified potential remains dual-feasible for every right-hand
side in the fixed travel network. Strong duality at the incumbent and weak
duality at the proposed supply imply

$$Q(x')-Q(x)\geq r^T\pi.$$

A nonnegative bound rejects a strictly improving joint move. A rejected bound
is returned with `exact=False`; `ResidualNetwork.candidate` refuses to convert
it into a route. A negative bound is only permission to evaluate a candidate.
It is never reported as an observed cost improvement.

For a fixed incumbent, the sparse tuple of nonzero entries in r is a balance
signature. Equal signatures give the same final supply and fixed-orientation
optimum, even when the flipped service-edge sets differ. An optimal extra flow
and its dual can be reused, followed by reconstructing and auditing the distinct
service directions. `coupled_path_search` keeps this cache inside one invocation
with one immutable center. An accepted move returns immediately; later phases
start fresh. Reuse across a changed flow, potential, or center is prohibited.

## Bounded search and controls

The path pool contains at most 96 paths, with at most 768 expansions and two
representatives per endpoint pair. Sampling combines low dual bounds and random
alternatives; individual exact improvement is not a prerequisite. Paths have
at most four service edges. Only edge-disjoint pairs with four distinct terminals
are considered, with at most 2,048 retained pair checks in a nominal 0.18-second
joint phase. These limits are explicit heuristics. Exhausting this sampled list
does not certify local optimality over all path pairs.

The phase cycle is chain, joint, parity, descent, joint, parity. Initialization
is unchanged from the reserved V20 policy. The actual parity sizes remain 24
and 16 to avoid attributing parameter retuning to the new operator.

| Identifier | Controlled difference |
| --- | --- |
| `cprnps` | Full candidate design |
| `rnps` | Original V20 search and schedule, implemented in the same V21 source for internal development comparison |
| `cprnps_no_joint` | Reassign each joint opportunity to single service-path search; it does not idle |
| `cprnps_no_screen` | Disable joint lower-bound rejection; preserve scoring and all other operators |
| `cprnps_no_signature` | Disable balance-signature reuse within a joint phase |
| `cprnps_cold_joint` | Evaluate the same joint orientation by fresh native MCF; no orientation-cache shortcut |

The four V21 mechanism controls have the same phase layout and initialization.
Wall-budget variants may follow different trajectories and perform different
numbers of proposals. The start-matching table and per-phase work counts expose
this. Comparison with `rnps` additionally changes the phase layout; the direct
operator contrast is against `cprnps_no_joint`.

## Certificate scopes and validation

An accepted joint move has an exact fixed-orientation extra-flow certificate.
Its logged individual deltas are marked incomplete when the remaining phase
window prevents both evaluations. A proper parity region has a conditional
fixed-outside certificate only. Global certificates require the existing
complete-domain mechanisms or the independent complete model. No sampled joint
pool is promoted into a global optimality proof.

The constructed fixture exhibits two individually neutral paths with joint delta
-27 while all 12 simple service paths of length at most four are nonimproving.
The tests independently check its costs with NetworkX network-simplex. This is a
separation result for strict single-path descent, not for the entire V20 method,
which already contains parity search, nor for plateau-walking alternatives.

Formal claims require further comparison with the published GRASP, SAP and exact
MCPP literature, matched-start large-graph ablations, and fresh difficult instances.
The packaged verification evidence does not establish performance superiority
or acceptance by any journal.
