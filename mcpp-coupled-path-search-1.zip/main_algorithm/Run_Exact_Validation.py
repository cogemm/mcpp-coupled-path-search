"""Separate complete-model validation on all nine graphs, 30 seconds each."""
import sys
from ThreeCity_Experiment import main
if __name__ == '__main__':
    main(['--version', 'v21', '--profile', 'validation', *sys.argv[1:]])
