"""Three n100 graphs, one seed, eight seconds per method."""
import sys
from ThreeCity_Experiment import main
if __name__ == '__main__':
    main(['--version', 'v21', '--profile', 'smoke', *sys.argv[1:]])
