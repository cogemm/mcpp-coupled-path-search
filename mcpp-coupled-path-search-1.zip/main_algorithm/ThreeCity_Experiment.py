"""Run frozen nine-graph experiments with separate literature/ablation suites.

PyCharm launchers set the requested profile. No PBF conversion or online data
download occurs. Original inputs are checked by SHA-256 before scheduling.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import importlib
import json
from pathlib import Path
import platform
import sys

ROOT = Path(__file__).resolve().parent
FROZEN_V20_SHA = '6e4177fa067fa820e9280805805b9045b6e876ace8033bf1a865638b2bfcf11a'
DEFAULT_SEEDS = [180201, 180202, 180203, 180204, 180205]


def hardware_info():
    import os
    result = {'processor': platform.processor() or None, 'logical_cpu_count': os.cpu_count(),
              'physical_memory_bytes': None}
    if sys.platform == 'win32':
        import ctypes
        class MemoryStatus(ctypes.Structure):
            _fields_ = [('length', ctypes.c_ulong), ('memory_load', ctypes.c_ulong),
                        ('total_phys', ctypes.c_ulonglong), ('avail_phys', ctypes.c_ulonglong),
                        ('total_page', ctypes.c_ulonglong), ('avail_page', ctypes.c_ulonglong),
                        ('total_virtual', ctypes.c_ulonglong), ('avail_virtual', ctypes.c_ulonglong),
                        ('avail_extended', ctypes.c_ulonglong)]
        status = MemoryStatus()
        status.length = ctypes.sizeof(status)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            result['physical_memory_bytes'] = int(status.total_phys)
    else:
        try:
            result['physical_memory_bytes'] = os.sysconf('SC_PHYS_PAGES') * os.sysconf('SC_PAGE_SIZE')
            cpuinfo = Path('/proc/cpuinfo')
            if cpuinfo.exists():
                result['processor'] = next((line.split(':', 1)[1].strip() for line in cpuinfo.read_text().splitlines() if line.startswith('model name')), result['processor'])
        except (ValueError, OSError):
            pass
    return result


def select_entries(core, folder, targets):
    manifest_path = folder / 'conversion_manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if manifest['solver_sha256'] != FROZEN_V20_SHA:
        raise ValueError('Road data must retain the original V20 validation binding.')
    entries = [e for e in manifest['instances'] if e['target_nodes'] in targets]
    expected = {(city, target) for city in ['beijing', 'shanghai', 'chongqing']
                for target in targets}
    actual = {(e['city'], e['target_nodes']) for e in entries}
    if actual != expected or len(entries) != len(expected):
        raise ValueError('Expected exactly one frozen graph per city and target.')
    for entry in entries:
        path = folder / entry['instance_relative_path']
        if core.sha256_file(path) != entry['instance_sha256']:
            raise ValueError('Input changed: ' + entry['name'])
        if core.load_instance(path).name != entry['name']:
            raise ValueError('Input identity differs: ' + entry['name'])
    return manifest_path, entries


def summarize(core, rows, entries, output, suite):
    """Descriptive graph means; deterministic labels never add replication."""
    pd = core.pd
    frame = pd.DataFrame(rows)
    cities = {e['name']: e['city'] for e in entries}
    frame['city'] = frame.instance.map(cities)
    frame.to_csv(output / 'city_labeled_attempts.csv', index=False, encoding='utf-8-sig')
    groups = []
    for (instance, method), group in frame.groupby(['instance', 'method']):
        ok = group[group.feasible]
        groups.append({
            'instance': instance, 'city': cities[instance], 'method': method,
            'label_rows': len(group),
            'physical_executions': group.execution_id.nunique(),
            'feasible_labels': len(ok), 'failed_labels': len(group) - len(ok),
            'complete_group': bool(group.feasible.all()),
            'mean_cost_cm': float(ok.cost.mean()) if len(ok) == len(group) else None,
            'best_cost_cm': float(ok.cost.min()) if len(ok) else None,
            'mean_length_km': float(ok.cost.mean()) / 100000 if len(ok) == len(group) else None,
            'sample_sd_cm': float(ok.cost.std(ddof=1)) if len(ok) == len(group) and len(ok) > 1 else None,
        })
    summary = pd.DataFrame(groups)
    summary.to_csv(output / 'graph_method_summary.csv', index=False, encoding='utf-8-sig')
    mean = summary.pivot(index='instance', columns='method', values='mean_cost_cm')
    pairs = []
    if core.PROPOSED_METHOD in mean:
        for instance, costs in mean.iterrows():
            own = costs.get(core.PROPOSED_METHOD)
            if pd.isna(own):
                continue
            for method, cost in costs.items():
                if method == core.PROPOSED_METHOD or pd.isna(cost):
                    continue
                gain = 100 * (cost - own) / cost
                pairs.append({'instance': instance, 'city': cities[instance],
                    'proposed': core.PROPOSED_METHOD, 'comparator': method,
                    'proposed_mean_cost_cm': own, 'comparator_mean_cost_cm': cost,
                    'relative_cost_reduction_percent': gain,
                    'outcome': 'win' if gain > 0 else 'loss' if gain < 0 else 'tie'})
    if pairs:
        paired = pd.DataFrame(pairs)
        paired.to_csv(output / 'descriptive_graph_comparisons.csv', index=False, encoding='utf-8-sig')
        reports = []
        for method, group in paired.groupby('comparator'):
            reports.append({'comparator': method, 'complete_graph_pairs': len(group),
                'wins': int(group.outcome.eq('win').sum()),
                'ties': int(group.outcome.eq('tie').sum()),
                'losses': int(group.outcome.eq('loss').sum()),
                'macro_mean_cost_reduction_percent': float(group.relative_cost_reduction_percent.mean()),
                'scope': 'descriptive only; failed graph groups excluded and counted separately'})
        pd.DataFrame(reports).to_csv(output / 'descriptive_comparison_summary.csv', index=False, encoding='utf-8-sig')
    # The inherited general-purpose table assumes independent graphs. Suppress
    # its p-values for these development patches from only three city clusters.
    infer = output / 'paired_instance_comparisons.csv'
    if infer.exists():
        table = pd.read_csv(infer)
        for col in ['wilcoxon_pratt_two_sided_p', 'sign_test_p', 'holm_p',
                    'bootstrap95_low_pct', 'bootstrap95_high_pct']:
            if col in table:
                table[col] = None
        table['interpretation'] = 'descriptive_only; three city clusters, seeds nested within graph'
        table.to_csv(infer, index=False, encoding='utf-8-sig')
    if suite == 'ablation':
        baseline = frame[frame.method.eq(core.PROPOSED_METHOD)].set_index(['instance', 'seed'])
        starts = []
        for _, row in frame.iterrows():
            key = (row['instance'], row['seed'])
            if key not in baseline.index:
                continue
            reference = baseline.loc[key]
            fields = ['recourse_start_orientation_sha256', 'recourse_start_flow_sha256']
            available = all(pd.notna(row.get(k)) and pd.notna(reference.get(k)) for k in fields)
            match = available and all(row.get(k) == reference.get(k) for k in fields)
            starts.append({'instance': key[0], 'seed': key[1], 'method': row['method'],
                'start_digest_available': available, 'matched_search_start': match,
                'initializer_completed': bool(row.get('rv_initialization_completed', False)),
                'interpretation': 'matched start; wall trajectories differ' if match else 'unmatched or unavailable start; causal mechanism comparison unsupported'})
        pd.DataFrame(starts).to_csv(output / 'ablation_start_matching.csv', index=False, encoding='utf-8-sig')
    physical_frame = frame.drop_duplicates('execution_id')
    joint_columns = ['instance', 'city', 'method', 'seed', 'execution_id', 'cost',
        'feasible', 'solver_wall_seconds', 'joint_pair_proposals', 'joint_evaluations',
        'joint_signature_hits', 'joint_screen_rejections', 'joint_cold_solves',
        'joint_improvements', 'joint_gain_scaled', 'joint_barrier_crossings',
        'phase_joint_calls', 'phase_joint_completed_calls', 'phase_joint_seconds',
        'counters_complete', 'supervisor_max_poll_gap_seconds', 'deadline_detected_seconds',
        'kill_requested_seconds', 'kill_call_returned_seconds', 'process_exit_observed_seconds']
    physical_frame.reindex(columns=joint_columns).to_csv(output / 'joint_mechanism_physical_runs.csv', index=False, encoding='utf-8-sig')
    core.atomic_json(output / 'inference_scope.json', {
        'city_clusters': len(set(cities.values())), 'graphs': len(entries),
        'formal_label_rows': len(rows), 'physical_executions': frame.execution_id.nunique(),
        'p_values_disabled': True, 'independent_confirmation_data': False,
        'scope': 'exploratory development road subgraphs, distance-only service',
        'universal_superiority_or_literature_novelty_established': False,
    })


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--version', choices=['v20', 'v21'], default='v21')
    parser.add_argument('--profile', choices=['formal', 'smoke', 'ablation', 'validation', 'recent'], default='formal')
    parser.add_argument('--data', type=Path, default=ROOT / 'osm_data')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--budget', type=float)
    parser.add_argument('--seeds')
    parser.add_argument('--targets', default=None, help='Optional target identifiers, e.g. 100,300,1000')
    parser.add_argument('--methods', default=None, help='Optional comma-separated methods from the selected suite')
    parser.add_argument('--plan-only', action='store_true', help='Verify identities and save the plan without running optimizers')
    args = parser.parse_args(argv)
    module = 'V20_RNPS_MCPP' if args.version == 'v20' else 'V21_Coupled_RNPS_MCPP'
    core = importlib.import_module(module)
    if core.sha256_file(ROOT / 'V20_RNPS_MCPP.py') != FROZEN_V20_SHA:
        raise ValueError('Original V20 source changed. Preserve this reference implementation.')
    budget = args.budget if args.budget is not None else (8. if args.profile == 'smoke' else 30. if args.profile == 'validation' else 60.)
    if budget <= 0 or not core.math.isfinite(budget):
        parser.error('Budget must be finite and positive.')
    seeds = [int(s) for s in args.seeds.split(',')] if args.seeds else ([180201] if args.profile in ['smoke', 'validation'] else DEFAULT_SEEDS)
    if not seeds or len(set(seeds)) != len(seeds):
        parser.error('Seeds must be nonempty and unique.')
    targets = [int(s) for s in args.targets.split(',')] if args.targets else ([100] if args.profile == 'smoke' else [100, 300, 1000])
    if len(set(targets)) != len(targets) or not set(targets) <= {12, 100, 300, 1000}:
        parser.error('Targets must be distinct frozen target identifiers.')
    suite = {'formal': 'literature', 'smoke': 'literature', 'ablation': 'ablation',
             'validation': 'validation', 'recent': 'recent'}[args.profile]
    methods = args.methods.split(',') if args.methods else (['full_mip'] if suite == 'validation' else list(core.SUITE_METHODS[suite]))
    core.validate_suite_methods(methods, suite)
    manifest, entries = select_entries(core, args.data, targets)
    source = Path(core.__file__)
    output = (args.output or ROOT / 'results' / (args.version + '_' + args.profile + ('_plan' if args.plan_only else ''))).resolve()
    protocol = {
        'version': args.version, 'profile': args.profile, 'suite': suite,
        'budget_seconds': budget, 'seeds': seeds, 'methods': methods,
        'solver_sha256': core.sha256_file(source),
        'wrapper_sha256': core.sha256_file(Path(__file__)),
        'conversion_manifest_sha256': core.sha256_file(manifest),
        'instances': [{k: e[k] for k in ['name', 'city', 'target_nodes', 'actual_nodes', 'instance_sha256']} for e in entries],
        'algorithm_parameters': core.algorithm_parameters(),
        'python': sys.version, 'platform': platform.platform(),
        'hardware': hardware_info(),
        'versions': {k: core.importlib_metadata.version(k) for k in ['numpy', 'pandas', 'networkx', 'scipy', 'ortools', 'rustworkx']},
        'stage': 'exploratory_three_city_' + args.version + '_' + args.profile,
        'budget_clock': 'worker search window; top-level startup separate; actual overruns retained',
        'deterministic_reuse': 'one physical execution per graph per deterministic method, reused over seed labels',
    }
    output.mkdir(parents=True, exist_ok=True)
    frozen = output / 'protocol.json'
    if frozen.exists():
        if json.loads(frozen.read_text(encoding='utf-8'))['protocol'] != protocol:
            raise ValueError('Protocol differs. Preserve old results and choose a new --output folder.')
    else:
        core.atomic_json(frozen, {'created_utc': datetime.now(timezone.utc).isoformat(), 'protocol': protocol})
    labels = len(entries) * len(methods) * len(seeds)
    deterministic = sum(m in ['modified_mixed', 'frederickson_1979'] for m in methods)
    physical = len(entries) * (deterministic + (len(methods) - deterministic) * len(seeds))
    print(f'[plan] version={args.version} suite={suite} graphs={len(entries)} labels={labels} physical={physical} budget={budget:g}s', flush=True)
    if args.plan_only:
        print('[plan-only] inputs verified; no optimizer executed:', output, flush=True)
        return
    paths = [args.data / e['instance_relative_path'] for e in entries]
    rows = core.run_plan(paths, methods, seeds, budget, output / 'experiment', protocol['stage'], suite)
    summarize(core, rows, entries, output / 'experiment', suite)
    from Audit_V20_Results import audit_tree
    audit = audit_tree(output / 'experiment', args.data / 'instances',
                       output / 'independent_route_audit.json', True, source_path=source)
    print('[done]', output, flush=True)
    if not audit['passed']:
        raise SystemExit('Some attempts failed audit; failures remain recorded. Review the audit report.')


if __name__ == '__main__':
    main()
