"""Recompute recorded joint moves with fresh cold flow solves, outside search time.

This audit is distinct from the route/Euler auditor. It checks joint and
individual costs against saved orientation vectors and immutable input bytes.
No outcomes are added to the timed optimizer's reported performance.
"""
from pathlib import Path
import argparse
import json
import time
import V21_Coupled_RNPS_MCPP as core

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, default=ROOT / 'results/v21_formal')
    parser.add_argument('--data', type=Path, default=ROOT / 'osm_data/instances')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    started = time.monotonic()
    checks = []
    for log in sorted(args.results.rglob('joint_moves.jsonl')):
        task = json.loads((log.parent / 'task.json').read_text(encoding='utf-8'))
        if task['source_sha256'] != core.sha256_file(Path(core.__file__)):
            raise ValueError('Joint audit requires the exact recorded V21 source.')
        input_path = args.data / (task['instance'] + '.json')
        if core.sha256_file(input_path) != task['instance_sha256']:
            raise ValueError('Joint audit input identity differs.')
        oracle = core.ExactOracle(core.load_instance(input_path))
        for line_number, line in enumerate(log.read_text(encoding='utf-8').splitlines(), 1):
            event = json.loads(line)
            center = oracle.evaluate(event['center_orientation'], use_cache=False)
            if core.hashlib.sha256(center.orientation.tobytes()).hexdigest() != event['center_orientation_sha256']:
                raise ValueError('Center orientation digest differs.')
            paths = tuple(core.ServicePath(r['source'], r['target'], tuple(r['edges'])) for r in event['paths'])
            indices = core.validate_service_bundle(oracle, center, paths)
            x = center.orientation.copy()
            x[list(indices)] = 1 - x[list(indices)]
            final = oracle.evaluate(x, use_cache=False)
            actual = final.scaled_extra_cost - center.scaled_extra_cost
            if actual != event['joint_delta_scaled'] or final.total_cost != event['cost_after'] or center.total_cost != event['cost_before']:
                raise ValueError('Joint recorded improvement differs from independent cold reoptimization.')
            candidate = log.parent / event['candidate_file']
            if core.sha256_file(candidate) != event['candidate_sha256']:
                raise ValueError('Accepted joint checkpoint digest differs.')
            with core.np.load(candidate, allow_pickle=False) as data:
                if not core.np.array_equal(x, data['orientation']) or float(data['total_cost']) != final.total_cost:
                    raise ValueError('Accepted joint checkpoint does not match the logged move.')
            individual = []
            for path in paths:
                x1 = center.orientation.copy()
                x1[list(path.edges)] = 1 - x1[list(path.edges)]
                individual.append(oracle.evaluate(x1, use_cache=False).scaled_extra_cost - center.scaled_extra_cost)
            reported = event['individual_deltas_scaled']
            if individual[:len(reported)] != reported:
                raise ValueError('Reported individual path deltas differ from cold reoptimization.')
            checks.append({'instance': task['instance'], 'method': task['method'], 'seed': task['seed'],
                'log': str(log.relative_to(args.results)), 'line': line_number,
                'joint_delta_scaled': actual, 'individual_deltas_scaled': individual,
                'individual_nonimproving_joint_improving': actual < 0 and all(d >= 0 for d in individual),
                'passed': True})
    report = {'passed': True, 'recorded_joint_moves': len(checks),
        'barrier_crossing_moves': sum(c['individual_nonimproving_joint_improving'] for c in checks),
        'audit_wall_seconds': time.monotonic() - started,
        'scope': 'Fresh cold-flow validation of logged moves, outside optimizer budget; not a performance or novelty result.',
        'checks': checks}
    destination = args.output or args.results / 'joint_move_cold_audit.json'
    destination.parent.mkdir(parents=True, exist_ok=True)
    core.atomic_json(destination, report)
    print('[joint-audit] PASS moves=', len(checks), 'barrier_crossings=', report['barrier_crossing_moves'], flush=True)


if __name__ == '__main__':
    main()
