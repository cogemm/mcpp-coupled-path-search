"""Verify all delivered code/data files; generated result folders are excluded."""
from pathlib import Path
import hashlib

ROOT = Path(__file__).resolve().parent


def main():
    count = 0
    failures = []
    for line in (ROOT / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
        digest, name = line.split('  ', 1)
        path = ROOT / name
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            failures.append(name)
        count += 1
    if failures:
        raise SystemExit('[package] FAILED files: ' + ', '.join(failures))
    print(f'[package] PASS: {count} delivered files match SHA256', flush=True)


if __name__ == '__main__':
    main()
