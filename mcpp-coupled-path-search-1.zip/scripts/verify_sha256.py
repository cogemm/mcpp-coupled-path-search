from pathlib import Path
import hashlib
import sys

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "SHA256SUMS.txt"
errors = []
checked = 0
for line in MANIFEST.read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    expected, rel = line.split("  ", 1)
    path = ROOT / rel
    if not path.is_file():
        errors.append(f"MISSING {rel}")
        continue
    h = hashlib.sha256(path.read_bytes()).hexdigest()
    checked += 1
    if h != expected:
        errors.append(f"MISMATCH {rel}")
if errors:
    print("SHA256 verification FAILED")
    print("\n".join(errors))
    sys.exit(1)
print(f"SHA256 verification PASS: {checked} files")
