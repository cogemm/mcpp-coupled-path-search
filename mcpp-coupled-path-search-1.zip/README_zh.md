# 混合中国邮差问题：Coupled-Path Search 研究复现仓库

**论文题目：** Coupled-Path Search for the Mixed Chinese Postman Problem: Algorithm Design and Verifiable Evaluation  
**期刊：** Algorithms  
**稿件编号：** algorithms-4755266

本仓库整理 V21 CPRNPS 算法实现、冻结的 OpenStreetMap 派生图实例、三城市主实验、六城市配对路径机制审计、路线与检查点验证记录、重新审计结果、论文图件，以及选定的开发诊断实验。

> **证据边界：** 三城市实验在原始完整性文件中被标记为探索性开发实验，而非未触碰的确认性测试。统计推断单位是图实例/城市簇，随机种子是嵌套重复。仓库不证明普遍优越性、整个 MCPP 启发式的全局最优性，也不证明与已发表方法作者官方软件的数值完全等价。

## 目录结构

- `main_algorithm/`：V20/V21 源码、运行入口、三城市冻结 OSM 图、正式实验协议、运行结果、检查点、候选记录、Euler 路线和独立审计记录。
- `mechanism_audit/`：六城市配对路径审计代码、冻结图、完整 `pair_audit.csv`、中心级记录、运行清单和路线见证。
- `results/reanalysis/`：提供的重新审计表、审计摘要、检查点审计、来源记录和日志。
- `results/development_diagnostics/`：五种子大图消融和独立单种子诊断；这些不是主文献比较表。
- `figures/`：提供的 Fig.1–Fig.6 PNG/TIFF 图件。
- `analysis/`：审计复算和图件重绘脚本。

## 已归档实验概况

### 三城市主实验

九个 OSM 派生图实例来自北京、上海、重庆，每个城市三个目标规模标签：100、300、1000。实际顶点数为 103–1,341；目标标签是提取目标，不保证等于实际节点数。

正式实验档案包含 180 行方法/种子标签和 108 次实际执行：

- CPRNPS：45 次实际执行；
- GRASP 重实现：45 次实际执行；
- Frederickson 重实现：9 次实际执行，其确定性结果在五个种子标签间复用；
- Modified Mixed 重实现：9 次实际执行，其确定性结果在五个种子标签间复用。

论文摘要中的 99 次主要比较执行是 CPRNPS 45 次 + GRASP 45 次 + Frederickson 9 次。额外 9 次 Modified Mixed 实际执行也保留在完整实验档案和汇总表中。不能把确定性结果复用的标签当作新的物理运行。辅助 Modified Mixed 比较为九图 9 胜，描述性宏平均成本降低率为 2.03662%。摘要所述的 99 次比较没有列出该方法，作者应在最终投稿前核对摘要和论文表格是否一致。提供的重新审计中，99 次主要比较实际执行均有可行路线。该审计报告这 99 次运行共 2,012 个检查点候选和 131,861 个 Euler 路线步。

重新审计中的描述性平均成本降低率为：相对于 Frederickson 重实现 1.70263%，相对于 GRASP 重实现 0.22652%。相对于 GRASP 的九图结果为 4 胜、4 平、1 负。这些是三个城市簇上的描述性结果，不代表广泛或普遍的算法优势。对比算法是独立重实现，不是原作者官方软件；细节见 `main_algorithm/results/v21_formal/experiment/literature_fidelity_manifest.json`。

归档的资格时间分析报告最大合格 incumbent 时间戳为 59.23485 秒。部分工作进程由于 watchdog/监督器延迟，在名义 60 秒窗口之后才退出；候选资格时间戳与进程退出时间是不同字段。不能声称所有进程退出时间都严格小于 60 秒。

### 六城市配对路径机制审计

独立审计使用成都、广州、杭州、南京、武汉、厦门六个城市。每个阶段有 30 个中心（6 城市 × 5 个种子），每阶段审计 61,440 对路径；初始和单路径下降后两个阶段合计 122,880 行。

经过有界单路径下降后，61,440 对审计路径中有 23 对满足严格配对改进条件：两条组成路径单独反转均不能改善 incumbent，但联合反转可以改善。在 24 个采样单路径池停滞且存在合格配对的中心中，10 个中心被配对反转改善。这是有界、采样邻域的机制审计，不意味着穷尽所有可能的单路径移动，也不是完全独立的确认性测试。具体采样和计时范围见 `mechanism_audit/` 中的运行清单和说明。

### 开发诊断结果

五种子大图消融记录保存在 `results/development_diagnostics/`，其中包括不利或不确定结果。讨论联合搜索调度的局限性时不得选择性删除。这些结果与主 99 次比较实验分开。

## 复现方式

原始正式实验协议记录的环境为 Windows 11、Python 3.13.13，具体依赖版本见 `main_algorithm/results/v21_formal/protocol.json` 和 `plan.json`。V21 工程中的 `requirements-tested.txt` 对应另一个 Linux/Python 3.12.14 交付验证环境；二者不是同一环境。

在仓库根目录安装组合依赖：

```bash
python -m pip install -r requirements.txt
```

从 `main_algorithm/` 运行包检查和短时测试：

```bash
python Check_Environment.py
python Verify_Package.py
python Run_V21_Mechanism_Tests.py
python Run_V21_Smoke.py
```

Smoke test 是新的短时测试，不是对归档 60 秒正式实验的复现。重新运行正式实验请使用 `Run_V21_ThreeCity_60s.py`，并生成新的结果目录，不要覆盖归档证据。

在仓库根目录重新计算提供的审计和图件：

```bash
python analysis/recompute_audit.py
python analysis/make_figures.py
```

六城市配对审计重新运行：

```bash
cd mechanism_audit
python -m pip install -r requirements.txt
python run_postman_experiment.py --self-test
python run_postman_experiment.py
```

重新运行会生成新的时间戳结果目录，不覆盖已归档实验。

## 许可

- 原创算法源代码：MIT，见 `LICENSE` 和 `LICENSE_SCOPE.md`。
- 作者原创的非代码研究材料（实验结果表、运行日志、路线/检查点记录、审计输出、绘图和图件）：CC BY 4.0；具体范围及混合文件的例外见 `LICENSE-CC-BY-4.0.md` 和 `LICENSE_SCOPE.md`。
- OSM 派生道路网络数据库，以及其他文件中嵌入的 OSM 派生数据库内容：ODbL 1.0，见 `OSM_DATA_LICENSE.md`。
- 原始 PBF 文件不在本仓库中重新分发；仓库包含实验使用的冻结图实例、几何、来源元数据和哈希。

## 许可范围

本仓库采用分层许可：原创算法代码为 MIT；作者原创非代码实验材料为 CC BY 4.0；OSM 派生图数据库及实验文件中提取的 OSM 数据内容为 ODbL 1.0。混合文件中，CC BY 4.0 仅覆盖作者拥有权利的原创贡献，不取代 ODbL。详见 `LICENSE_SCOPE.md`、`LICENSE-CC-BY-4.0.md` 和 `OSM_DATA_LICENSE.md`。

## 来源与限制

`PROVENANCE_RECONCILIATION.md` 记录两个上传压缩包的实际 SHA-256，并解释旧来源记录中的哈希不匹配。来源文件还引用了一份未包含在两个压缩包中的论文 DOCX。这里保留并披露差异，不静默修改。此外，保留的交付范围说明称 V21 九图 60 秒实验尚未执行，但同一发布包中的 `results/v21_formal/` 包含 108 个实际运行目录，并已通过本次独立重新审计。这些说明可能来自不同交付快照，需作者在公开前核实，详见 `PROVENANCE_RECONCILIATION.md`。

本仓库不声称算法普遍优越、启发式全局最优，或与已发表方法的原作者软件数值完全等价。路线可行性结论仅限于所提供的独立审计及其范围。
