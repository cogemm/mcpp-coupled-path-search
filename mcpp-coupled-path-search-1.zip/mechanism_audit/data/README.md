# Frozen OpenStreetMap road extracts

© OpenStreetMap contributors. The six graph JSON files are derived data under the [Open Database License 1.0](https://opendatacommons.org/licenses/odbl/1-0/). See [OpenStreetMap copyright and attribution](https://www.openstreetmap.org/copyright). Each graph contains its source bounding box, retrieval time, and input SHA-256.

`nodes` contains stable OSM node IDs. Each entry in `links` records a physical road link ID, two endpoint IDs, its static direction, and its integer length in centimetres. A one-way link may be traversed from `u` to `v`. A two-way link may be traversed in either direction.

The original releases or coordinates may change at the source URLs. Use these included snapshots to reproduce the experiment.
