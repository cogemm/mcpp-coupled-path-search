#!/usr/bin/env python3
"""Matched single-path vs coupled-path reversal experiment for mixed postman routing."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
from itertools import combinations, zip_longest
import json
from math import asin, cos, radians, sin, sqrt
from pathlib import Path
import platform
import random
from statistics import mean, median
from time import perf_counter_ns
from typing import Iterable, Iterator, Sequence
from urllib.parse import urlencode
import xml.etree.ElementTree as ET

import numpy as np
import ortools
from ortools.graph.python import min_cost_flow


# PyCharm defaults. Change here or pass flags in Run Configuration.
PROJECT = Path(__file__).resolve().parent
DEFAULT_BUDGET_SECONDS = 60.0  # per arm, per frozen centre
DEFAULT_SEEDS = (180201, 180202, 180203, 180204, 180205)
DEFAULT_DESCENT_STEPS = 20
DEFAULT_MAX_PATH_EDGES = 4
DEFAULT_MAX_PATHS = 96
DEFAULT_PATH_EXPANSIONS = 768  # extension attempts; length-one candidates separate
DEFAULT_MAX_PAIRS = 2048
MAX_PATHS_PER_TERMINALS = 2
OSM_ATTRIBUTION = "© OpenStreetMap contributors, ODbL 1.0"
OSM_COPYRIGHT = "https://www.openstreetmap.org/copyright"


@dataclass(frozen=True)
class Link:
    id: str
    u: int
    v: int
    cost: int
    one_way: bool


@dataclass(frozen=True)
class Drive:
    link: int
    u: int
    v: int
    cost: int
    reverse: bool


@dataclass
class RoadGraph:
    name: str
    nodes: tuple[str, ...]
    links: tuple[Link, ...]
    source: dict

    def __post_init__(self) -> None:
        self.drives: list[Drive] = []
        self.reference_drive: list[int] = []
        self.reverse_drive: dict[int, int] = {}
        for link_id, link in enumerate(self.links):
            self.reference_drive.append(len(self.drives))
            self.drives.append(Drive(link_id, link.u, link.v, link.cost, False))
            if not link.one_way:
                self.reverse_drive[link_id] = len(self.drives)
                self.drives.append(Drive(link_id, link.v, link.u, link.cost, True))
        self.service_cost = sum(link.cost for link in self.links)

    @classmethod
    def from_json(cls, path: Path) -> RoadGraph:
        raw = json.loads(path.read_text(encoding="utf-8-sig"))
        if raw["schema"] != "mixed-postman-graph-v1":
            raise ValueError(f"{path}: unsupported graph schema")
        nodes = tuple(raw["nodes"])
        if not nodes or any(not isinstance(node, str) or not node for node in nodes):
            raise ValueError(f"{path}: nodes must be nonempty string IDs")
        node_index = {label: idx for idx, label in enumerate(nodes)}
        if len(node_index) != len(nodes):
            raise ValueError(f"{path}: duplicate node IDs")
        links = []
        for edge in raw["links"]:
            if edge["direction"] not in {"oneway", "twoway"}:
                raise ValueError(f"{path}: bad direction on {edge['id']}")
            cost = edge["cost_cm"]
            if type(cost) is not int or cost < 0:
                raise ValueError(f"{path}: road lengths must be nonnegative integer cm")
            links.append(
                Link(
                    edge["id"], node_index[edge["u"]], node_index[edge["v"]], cost,
                    edge["direction"] == "oneway",
                )
            )
        if not links or any(not isinstance(edge.id, str) or not edge.id for edge in links):
            raise ValueError(f"{path}: links must have nonempty string IDs")
        if len({edge.id for edge in links}) != len(links):
            raise ValueError(f"{path}: duplicate physical link IDs")
        graph = cls(raw["city"], nodes, tuple(links), raw.get("source", {}))
        edges = [(drive.u, drive.v) for drive in graph.drives]
        if len(largest_scc(len(nodes), edges)) != len(nodes):
            raise ValueError(f"{path}: permitted traversals must be strongly connected")
        return graph


@dataclass(frozen=True)
class ServicePath:
    nodes: tuple[int, ...]
    links: tuple[int, ...]
    link_set: frozenset[int]

    @property
    def terminals(self) -> tuple[int, int]:
        return self.nodes[0], self.nodes[-1]

    @property
    def delta(self) -> tuple[tuple[int, int], ...]:
        origin, destination = self.terminals
        return tuple(sorted(((origin, 2), (destination, -2))))


Pair = tuple[int, int]
Delta = tuple[tuple[int, int], ...]


@dataclass(frozen=True)
class Limits:
    max_edges: int
    max_paths: int
    path_expansions: int
    max_pairs: int


@dataclass
class TimedResult:
    best_cm: int
    best_move: tuple[int, ...]
    best_at_s: float
    wall_s: float
    singles_done: int
    pairs_done: int
    search_exhausted: bool


def current_direction(graph: RoadGraph, link_id: int, flipped: frozenset[int]) -> Drive:
    drive_id = (
        graph.reverse_drive[link_id] if link_id in flipped else graph.reference_drive[link_id]
    )
    return graph.drives[drive_id]


def orientation_supply(graph: RoadGraph, flipped: frozenset[int]) -> np.ndarray:
    supply = np.zeros(len(graph.nodes), dtype=np.int64)
    for link_id in range(len(graph.links)):
        drive = current_direction(graph, link_id, flipped)
        supply[drive.u] -= 1
        supply[drive.v] += 1
    return supply


class FlowOracle:
    def __init__(self, graph: RoadGraph) -> None:
        self.graph = graph
        self.tails = np.array([arc.u for arc in graph.drives], dtype=np.int32)
        self.heads = np.array([arc.v for arc in graph.drives], dtype=np.int32)
        self.costs = np.array([arc.cost for arc in graph.drives], dtype=np.int64)
        self.node_ids = np.arange(len(graph.nodes), dtype=np.int32)
        self.service_tails = np.array([edge.u for edge in graph.links], dtype=np.int32)
        self.service_heads = np.array([edge.v for edge in graph.links], dtype=np.int32)

    def solve(self, supply: np.ndarray, *, flows: bool = False) -> tuple[int, np.ndarray | None]:
        positive_supply = int(supply[supply > 0].sum())
        if positive_supply == 0:
            return self.graph.service_cost, (np.zeros(len(self.tails), dtype=np.int64) if flows else None)
        model = min_cost_flow.SimpleMinCostFlow()
        # Nonnegative costs allow an optimum without circulation. No arc then needs
        # more than the total source supply, including on graphs with parallel links.
        capacities = np.full(len(self.tails), positive_supply, dtype=np.int64)
        arc_ids = model.add_arcs_with_capacity_and_unit_cost(
            self.tails, self.heads, capacities, self.costs
        )
        model.set_nodes_supplies(self.node_ids, supply)
        status = model.solve()
        if status != model.OPTIMAL:
            raise RuntimeError(f"Minimum-cost flow returned {status.name} on {self.graph.name}")
        cost = self.graph.service_cost + int(model.optimal_cost())
        return cost, (model.flows(arc_ids) if flows else None)


def score_delta(
    oracle: FlowOracle, supply: np.ndarray, delta: Delta, cache: dict[Delta, int]
) -> int:
    if delta in cache:
        return cache[delta]
    changed = supply.copy()
    for node, amount in delta:
        changed[node] += amount
    value, _ = oracle.solve(changed)
    cache[delta] = value
    return value


def initial_orientation(graph: RoadGraph, seed: int) -> frozenset[int]:
    rng = random.Random(seed)
    supply = [0] * len(graph.nodes)
    for edge in graph.links:
        if edge.one_way:
            supply[edge.u] -= 1
            supply[edge.v] += 1
    movable = [i for i, edge in enumerate(graph.links) if not edge.one_way and edge.u != edge.v]
    rng.shuffle(movable)
    flipped = set()
    for i in movable:
        edge = graph.links[i]
        u, v = edge.u, edge.v
        reference = abs(supply[u] - 1) + abs(supply[v] + 1)
        reverse = abs(supply[u] + 1) + abs(supply[v] - 1)
        if reverse < reference or (reverse == reference and rng.getrandbits(1)):
            flipped.add(i)
            u, v = v, u
        supply[u] -= 1
        supply[v] += 1
    return frozenset(flipped)


def extend_paths(
    frontier: Sequence[ServicePath],
    edges_from: Sequence[list[tuple[int, int]]],
    maximum_attempts: int,
) -> Iterator[ServicePath]:
    attempts = 0
    for path in frontier:
        for v, link in edges_from[path.nodes[-1]]:
            if attempts >= maximum_attempts:
                return
            attempts += 1
            if v not in path.nodes:
                yield ServicePath(path.nodes + (v,), path.links + (link,), path.link_set | {link})


def sample_paths(
    graph: RoadGraph, flipped: frozenset[int], seed: int, limits: Limits
) -> list[ServicePath]:
    rng = random.Random(seed)
    edges_from: list[list[tuple[int, int]]] = [[] for _ in graph.nodes]
    starters = []
    for link_id in graph.reverse_drive:
        drive = current_direction(graph, link_id, flipped)
        if drive.u != drive.v:
            edges_from[drive.u].append((drive.v, link_id))
            starters.append(ServicePath(
                (drive.u, drive.v), (link_id,), frozenset((link_id,))
            ))
    rng.shuffle(starters)
    for outgoing in edges_from:
        rng.shuffle(outgoing)

    layers = [starters]
    for depth in range(1, limits.max_edges):
        base, remainder = divmod(limits.path_expansions, limits.max_edges - 1)
        layer = list(extend_paths(layers[-1], edges_from, base + (depth <= remainder)))
        rng.shuffle(layer)
        layers.append(layer)

    selected: list[ServicePath] = []
    count_by_endpoint: Counter[tuple[int, int]] = Counter()
    for row in zip_longest(*layers):
        for path in row:
            if path is None or count_by_endpoint[path.terminals] >= MAX_PATHS_PER_TERMINALS:
                continue
            selected.append(path)
            count_by_endpoint[path.terminals] += 1
            if len(selected) == limits.max_paths:
                rng.shuffle(selected)
                return selected
    rng.shuffle(selected)
    return selected


def pair_delta(paths: Sequence[ServicePath], pair: Pair) -> Delta:
    left, right = pair
    return tuple(sorted(paths[left].delta + paths[right].delta))


def sample_pairs(
    paths: Sequence[ServicePath], seed: int, cap: int
) -> tuple[list[Pair], int]:
    pairs = [
        (i, j)
        for i, j in combinations(range(len(paths)), 2)
        if paths[i].link_set.isdisjoint(paths[j].link_set)
        and len({*paths[i].terminals, *paths[j].terminals}) == 4
    ]
    eligible = len(pairs)
    random.Random(seed ^ 0x8C71).shuffle(pairs)
    return pairs[:cap], eligible


def move_links(paths: Sequence[ServicePath], move: tuple[int, ...]) -> frozenset[int]:
    return frozenset(link for path_idx in move for link in paths[path_idx].links)


def shared_descent(
    graph: RoadGraph,
    oracle: FlowOracle,
    initial: frozenset[int],
    seed: int,
    limits: Limits,
    steps: int,
) -> tuple[frozenset[int], int, str]:
    current = initial
    for step in range(steps):
        paths = sample_paths(graph, current, seed, limits)
        supply = orientation_supply(graph, current)
        cost, _ = oracle.solve(supply)
        best_cost = cost
        best_path = None
        cache: dict[Delta, int] = {}
        for path in paths:
            candidate = score_delta(oracle, supply, path.delta, cache)
            if candidate < best_cost:
                best_cost, best_path = candidate, path
        if best_path is None:
            return current, step, "sampled_single_pool_stalled"
        current = current ^ best_path.link_set
    return current, steps, "step_cap"


def timed_scan(
    oracle: FlowOracle,
    supply: np.ndarray,
    base_cost: int,
    paths: Sequence[ServicePath],
    pairs: Sequence[Pair],
    budget_ns: int,
) -> TimedResult:
    cache: dict[Delta, int] = {}
    best_cost = base_cost
    best_move: tuple[int, ...] = ()
    best_at_ns = 0
    singles_done = pairs_done = 0
    start = perf_counter_ns()
    deadline = start + budget_ns

    def candidates() -> Iterator[tuple[tuple[int, ...], Delta]]:
        for idx, path in enumerate(paths):
            yield (idx,), path.delta
        for pair in pairs:
            yield pair, pair_delta(paths, pair)

    for move, delta in candidates():
        if perf_counter_ns() > deadline:
            break
        cost = score_delta(oracle, supply, delta, cache)
        completed_at = perf_counter_ns()
        if completed_at > deadline:
            break
        if len(move) == 1:
            singles_done += 1
        else:
            pairs_done += 1
        if cost < best_cost:
            best_cost, best_move, best_at_ns = cost, move, completed_at - start

    return TimedResult(
        best_cm=best_cost, best_move=best_move, best_at_s=best_at_ns / 1e9,
        wall_s=(perf_counter_ns() - start) / 1e9, singles_done=singles_done,
        pairs_done=pairs_done, search_exhausted=(singles_done + pairs_done == len(paths) + len(pairs)),
    )


def exact_move_cost(
    graph: RoadGraph, oracle: FlowOracle, base: frozenset[int],
    paths: Sequence[ServicePath], move: tuple[int, ...],
) -> int:
    orientation = base ^ move_links(paths, move)
    cost, _ = oracle.solve(orientation_supply(graph, orientation))
    return cost


def audit_cost(oracle: FlowOracle, reversed_links: np.ndarray) -> int:
    # Rebuild the supply from every service copy, without using any path endpoint delta.
    u = np.where(reversed_links, oracle.service_heads, oracle.service_tails)
    v = np.where(reversed_links, oracle.service_tails, oracle.service_heads)
    n = len(oracle.node_ids)
    supply = np.bincount(v, minlength=n) - np.bincount(u, minlength=n)
    cost, _ = oracle.solve(supply)
    return cost


def percent(numerator: int, denominator: int) -> float | str:
    return 100.0 * numerator / denominator if denominator else ""


PAIR_COLUMNS = [
    "city", "seed", "stage", "pool_sha256", "path_a", "path_b", "effect",
    "base_cm", "single_a_cm", "single_b_cm", "best_single_or_base_cm", "pair_cm",
    "pair_gain_cm", "pair_gain_pct_of_base", "gain_over_best_pool_single_cm",
    "interaction_cm", "strict_constituent_gain", "beyond_best_pool_single",
]


def audit_pool(
    graph: RoadGraph,
    oracle: FlowOracle,
    base: frozenset[int],
    base_cost: int,
    paths: Sequence[ServicePath],
    pairs: Sequence[Pair],
    context: dict,
) -> tuple[dict, list[dict], Pair | None]:
    """Recompute supplies from physically flipped links. Audit every sampled pair."""
    base_mask = np.zeros(len(graph.links), dtype=bool)
    base_mask[list(base)] = True
    path_links = [list(path.links) for path in paths]
    singles = []
    for links in path_links:
        mask = base_mask.copy()
        mask[links] ^= True
        singles.append(audit_cost(oracle, mask))
    best_single = min([base_cost, *singles])
    rows = []
    effects = set()
    strict_effects = set()
    strict_gains = []
    best_pair_cost: int | None = None
    best_strict_pair: Pair | None = None
    best_strict_gain = 0
    for i, j in pairs:
        mask = base_mask.copy()
        mask[path_links[i]] ^= True
        mask[path_links[j]] ^= True
        cost = audit_cost(oracle, mask)
        effect = pair_delta(paths, (i, j))
        effects.add(effect)
        strict = singles[i] >= base_cost and singles[j] >= base_cost and cost < base_cost
        gain = base_cost - cost
        if strict:
            strict_effects.add(effect)
            if gain > best_strict_gain:
                best_strict_pair, best_strict_gain = (i, j), gain
            strict_gains.append(gain)
        if best_pair_cost is None or cost < best_pair_cost:
            best_pair_cost = cost
        rows.append({
            **context,
            "path_a": i,
            "path_b": j,
            "effect": "|".join(f"{graph.nodes[node]}:{amount}" for node, amount in effect),
            "base_cm": base_cost,
            "single_a_cm": singles[i],
            "single_b_cm": singles[j],
            "best_single_or_base_cm": best_single,
            "pair_cm": cost,
            "pair_gain_cm": gain,
            "pair_gain_pct_of_base": percent(gain, base_cost),
            "gain_over_best_pool_single_cm": best_single - cost,
            "interaction_cm": singles[i] + singles[j] - base_cost - cost,
            "strict_constituent_gain": int(strict),
            "beyond_best_pool_single": int(cost < best_single),
        })

    stats = {
        "exact_best_single_or_base_cm": best_single,
        "exact_best_pair_cm": best_pair_cost if best_pair_cost is not None else "",
        "sampled_single_pool_stalled": int(bool(paths) and best_single == base_cost),
        "audited_pairs": len(rows),
        "audited_effects": len(effects),
        "strict_pairs": len(strict_gains),
        "strict_effects": len(strict_effects),
        "strict_pair_rate_pct": percent(len(strict_gains), len(rows)),
        "strict_effect_rate_pct": percent(len(strict_effects), len(effects)),
        "strict_gain_median_cm": median(strict_gains) if strict_gains else "",
        "strict_gain_max_cm": best_strict_gain if strict_gains else "",
        "strict_gain_median_pct_of_base": percent(median(strict_gains), base_cost)
        if strict_gains else "",
        "strict_gain_max_pct_of_base": percent(best_strict_gain, base_cost)
        if strict_gains else "",
        "positive_interaction_pairs": sum(row["interaction_cm"] > 0 for row in rows),
        "beyond_best_single_pairs": sum(row["beyond_best_pool_single"] for row in rows),
        "best_pair_extra_gain_vs_single_cm": (
            max(0, best_single - best_pair_cost) if best_pair_cost is not None else ""
        ),
        "best_pair_extra_gain_vs_single_pct": (
            percent(max(0, best_single - best_pair_cost), best_single)
            if best_pair_cost is not None else ""
        ),
    }
    return stats, rows, best_strict_pair


def reconstruct_route(
    graph: RoadGraph, oracle: FlowOracle, flipped: frozenset[int]
) -> tuple[int, list[list[str | int]]]:
    cost, flow = oracle.solve(orientation_supply(graph, flipped), flows=True)
    if flow is None:
        raise RuntimeError("Missing optimal flow for route reconstruction")
    counts = [int(number) for number in flow]
    for link_id, forward in enumerate(graph.reference_drive):
        drive_idx = graph.reverse_drive[link_id] if link_id in flipped else forward
        counts[drive_idx] += 1

    adj: list[list[int]] = [[] for _ in graph.nodes]
    for i, drive in enumerate(graph.drives):
        adj[drive.u].extend([i] * counts[i])
    first = next(idx for idx, outgoing in enumerate(adj) if outgoing)
    stack = [(first, None)]
    reverse_walk = []
    while stack:
        node, entered = stack[-1]
        if adj[node]:
            i = adj[node].pop()
            stack.append((graph.drives[i].v, i))
        else:
            stack.pop()
            if entered is not None:
                reverse_walk.append(entered)
    walk = [graph.drives[i] for i in reversed(reverse_walk)]

    # Verify the route from its walks and physical IDs, independent of flow balances.
    covered = set()
    at = first
    total = 0
    for drive in walk:
        edge = graph.links[drive.link]
        expected = (edge.v, edge.u) if drive.reverse else (edge.u, edge.v)
        if drive.u != at or (drive.u, drive.v) != expected or (edge.one_way and drive.reverse):
            raise RuntimeError("Route direction or continuity check failed")
        covered.add(drive.link)
        total += edge.cost
        at = drive.v
    if (at != first or len(covered) != len(graph.links)
            or len(walk) != sum(counts) or total != cost):
        raise RuntimeError("Route closure, coverage or exact cost check failed")
    return cost, [[graph.links[arc.link].id, -1 if arc.reverse else 1] for arc in walk]


def timed_columns(prefix: str, result: TimedResult) -> dict:
    return {
        f"{prefix}_cost_cm": result.best_cm,
        f"{prefix}_move": "+".join(map(str, result.best_move)),
        f"{prefix}_best_at_s": result.best_at_s,
        f"{prefix}_wall_s": result.wall_s,
        f"{prefix}_singles_done": result.singles_done,
        f"{prefix}_pairs_done": result.pairs_done,
        f"{prefix}_pool_exhausted": int(result.search_exhausted),
    }


def one_stage(
    graph: RoadGraph,
    oracle: FlowOracle,
    base: frozenset[int],
    seed: int,
    limits: Limits,
    stage: str,
    budget_s: float,
    single_first: bool,
    shared_info: dict,
    folder: Path,
) -> tuple[dict, list[dict]]:
    prep_start = perf_counter_ns()
    supply = orientation_supply(graph, base)
    base_cost, _ = oracle.solve(supply)
    paths = sample_paths(graph, base, seed, limits)
    pairs, eligible = sample_pairs(paths, seed, limits.max_pairs)
    pool = {
        "base_reversed_link_ids": [graph.links[i].id for i in sorted(base)],
        "paths": [
            {"path_id": idx, "nodes": [graph.nodes[i] for i in path.nodes],
             "links": [graph.links[i].id for i in path.links]}
            for idx, path in enumerate(paths)
        ],
        "pairs": pairs,
    }
    pool_id = sha256(json.dumps(pool, separators=(",", ":")).encode()).hexdigest()
    shared_prep_s = (perf_counter_ns() - prep_start) / 1e9

    # Hold both arms at the same incumbent, using identical singles in the same
    # order. Each arm starts with a fresh cache and gets its own full time window.
    arms = (("single", ()), ("coupled", pairs))
    if not single_first:
        arms = arms[::-1]
    budget_ns = max(1, round(budget_s * 1e9))
    timed = {
        arm: timed_scan(oracle, supply, base_cost, paths, arm_pairs, budget_ns)
        for arm, arm_pairs in arms
    }
    single, coupled = timed["single"], timed["coupled"]

    context = {"city": graph.name, "seed": seed, "stage": stage, "pool_sha256": pool_id}
    stats, pair_rows, best_strict = audit_pool(graph, oracle, base, base_cost, paths, pairs, context)
    exact_pair = stats["exact_best_pair_cm"]
    if single.search_exhausted and single.best_cm != stats["exact_best_single_or_base_cm"]:
        raise RuntimeError("Timed single score disagrees with the exhaustive audit")
    if coupled.search_exhausted:
        exact_combined = min(
            stats["exact_best_single_or_base_cm"],
            exact_pair if isinstance(exact_pair, int) else base_cost,
        )
        if coupled.best_cm != exact_combined:
            raise RuntimeError("Timed coupled score disagrees with the exhaustive audit")

    check = {"base": ((), base_cost), "single": (single.best_move, single.best_cm),
             "coupled": (coupled.best_move, coupled.best_cm)}
    if best_strict is not None:
        best = next(row for row in pair_rows if (row["path_a"], row["path_b"]) == best_strict)
        check["best_strict_pair"] = (best_strict, best["pair_cm"])
        check["best_strict_constituent_a"] = ((best_strict[0],), best["single_a_cm"])
        check["best_strict_constituent_b"] = ((best_strict[1],), best["single_b_cm"])
    witnesses = {}
    route_by_move = {}
    for label, (move, expected_cost) in check.items():
        if move not in route_by_move:
            orientation = base ^ move_links(paths, move)
            route_by_move[move] = reconstruct_route(graph, oracle, orientation)
        cost, walk = route_by_move[move]
        if cost != expected_cost:
            raise RuntimeError(f"Audit mismatch for {label} on {graph.name}")
        witnesses[label] = {"path_ids": move, "cost_cm": cost, "route": walk}

    stage_file = folder / f"{stage}.json"
    stage_file.write_text(json.dumps({
        **context, "nodes": len(graph.nodes), "required_links": len(graph.links),
        **pool, "route_witnesses": witnesses,
    }, ensure_ascii=False, separators=(",", ":")) + "\n", encoding="utf-8")
    row = {
        **context, **shared_info,
        "vertices": len(graph.nodes), "required_links": len(graph.links),
        "oneway_share_pct": percent(len(graph.links) - len(graph.reverse_drive), len(graph.links)),
        "base_cm": base_cost, "sampled_paths": len(paths),
        "eligible_pairs_before_cap": eligible,
        "budget_per_arm_s": budget_s, "shared_prep_s": shared_prep_s,
        "timing_order": "single_first" if single_first else "coupled_first",
        **timed_columns("single", single), **timed_columns("coupled", coupled),
        "timed_gain_vs_single_cm": single.best_cm - coupled.best_cm,
        "timed_gain_vs_single_pct": percent(single.best_cm - coupled.best_cm, single.best_cm),
        **stats,
    }
    return row, pair_rows


def largest_scc(n: int, edges: Iterable[tuple[int, int]]) -> set[int]:
    forwards: list[list[int]] = [[] for _ in range(n)]
    backwards: list[list[int]] = [[] for _ in range(n)]
    for u, v in edges:
        forwards[u].append(v)
        backwards[v].append(u)

    seen = set()
    finished = []
    for start in range(n):
        if start in seen:
            continue
        seen.add(start)
        stack = [(start, iter(forwards[start]))]
        while stack:
            u, next_child = stack[-1]
            v = next(next_child, None)
            if v is None:
                stack.pop()
                finished.append(u)
            elif v not in seen:
                seen.add(v)
                stack.append((v, iter(forwards[v])))

    seen.clear()
    largest: set[int] = set()
    for start in reversed(finished):
        if start in seen:
            continue
        component = {start}
        seen.add(start)
        frontier = [start]
        while frontier:
            u = frontier.pop()
            for v in backwards[u]:
                if v not in seen:
                    seen.add(v)
                    component.add(v)
                    frontier.append(v)
        if len(component) > len(largest) or (
            len(component) == len(largest) and min(component) < min(largest)
        ):
            largest = component
    return largest


ROAD_CLASSES = {
    "motorway", "motorway_link", "trunk", "trunk_link", "primary", "primary_link",
    "secondary", "secondary_link", "tertiary", "tertiary_link", "unclassified",
    "residential", "living_street", "service",
}


def osm_direction(tags: dict[str, str]) -> int | None:
    if tags.get("highway") not in ROAD_CLASSES or tags.get("area") == "yes":
        return None
    if tags.get("service") in {"parking_aisle", "driveway", "drive-through", "emergency_access"}:
        return None
    access = next((tags[key] for key in ("motorcar", "motor_vehicle", "vehicle", "access")
                   if key in tags), "")
    if access in {"no", "private", "customers", "agricultural", "forestry", "permit", "delivery"}:
        return None
    if any(key in tags for key in (
        "oneway:conditional", "oneway:motorcar:conditional", "oneway:motor_vehicle:conditional",
        "access:conditional", "vehicle:conditional", "motor_vehicle:conditional", "motorcar:conditional",
    )):
        return None
    explicit = next((tags[key] for key in ("oneway:motorcar", "oneway:motor_vehicle", "oneway")
                     if key in tags), "")
    if explicit in {"-1", "reverse"}:
        return -1
    if explicit in {"yes", "true", "1"}:
        return 1
    if explicit in {"no", "false", "0"}:
        return 0
    if explicit:
        return None
    return int(tags.get("junction") in {"roundabout", "circular"} or tags["highway"] == "motorway")


def length_cm(geometry: Sequence[str], coordinates: dict[str, tuple[float, float]]) -> int:
    length = 0.0
    for u, v in zip(geometry, geometry[1:]):
        lat_u, lon_u = map(radians, coordinates[u])
        lat_v, lon_v = map(radians, coordinates[v])
        a = sin((lat_v - lat_u) / 2) ** 2 + cos(lat_u) * cos(lat_v) * sin((lon_v - lon_u) / 2) ** 2
        length += 2 * 6_371_008.8 * asin(sqrt(min(1.0, a)))
    return round(100 * length)


def import_osm(raw_path: Path, city: str, target: Path, retrieved_utc: str = "") -> None:
    if target.exists():
        raise FileExistsError(f"Graph output already exists: {target}")
    raw_bytes = raw_path.read_bytes()
    root = ET.fromstring(raw_bytes)
    bounds = root.find("bounds")
    if root.tag != "osm" or bounds is None:
        raise ValueError("Expected an OSM 0.6 XML map file with bounds")
    west, south, east, north = [
        float(bounds.attrib[key]) for key in ("minlon", "minlat", "maxlon", "maxlat")
    ]
    coordinates = {
        node.attrib["id"]: (float(node.attrib["lat"]), float(node.attrib["lon"]))
        for node in root.iter("node")
    }
    inside = {i for i, (lat, lon) in coordinates.items()
              if south <= lat <= north and west <= lon <= east}

    runs = []
    occurrences: Counter[str] = Counter()
    for way in sorted(root.iter("way"), key=lambda elem: int(elem.attrib["id"])):
        tags = {tag.attrib["k"]: tag.attrib["v"] for tag in way.iter("tag")}
        direction = osm_direction(tags)
        if direction is None:
            continue
        current: list[tuple[int, str]] = []
        nds = [nd.attrib["ref"] for nd in way.iter("nd")]
        for i, node in enumerate([*nds, ""]):
            if node in inside:
                current.append((i, node))
            else:
                if len(current) >= 2:
                    runs.append((way.attrib["id"], direction, current))
                    occurrences.update(vertex for _, vertex in current)
                current = []

    edges = []
    for way_id, direction, run in runs:
        base = 0
        for stop in range(1, len(run)):
            v = run[stop][1]
            if stop != len(run) - 1 and occurrences[v] == 1:
                continue
            geometry = [vertex for _, vertex in run[base:stop + 1]]
            u = geometry[0]
            if direction == -1:
                u, v = v, u
            edges.append(
                {"id": f"osm:{way_id}:{run[base][0]}-{run[stop][0]}",
                 "u": u, "v": v, "cost_cm": length_cm(geometry, coordinates),
                 "direction": "oneway" if direction else "twoway"}
            )
            base = stop

    nodes = sorted({edge[key] for edge in edges for key in ("u", "v")}, key=int)
    idx = {node: i for i, node in enumerate(nodes)}
    drives = [(idx[e["u"]], idx[e["v"]]) for e in edges]
    drives += [(idx[e["v"]], idx[e["u"]]) for e in edges if e["direction"] == "twoway"]
    component = largest_scc(len(nodes), drives)
    selected = [node for i, node in enumerate(nodes) if i in component]
    kept = set(selected)
    edges = [e for e in edges if e["u"] in kept and e["v"] in kept]
    if len(selected) < 4 or not any(e["direction"] == "twoway" for e in edges):
        raise ValueError(f"No usable mixed road network in {raw_path}")
    bbox_text = ",".join(bounds.attrib[key] for key in ("minlon", "minlat", "maxlon", "maxlat"))
    source = {
        "provider": "OpenStreetMap", "attribution": OSM_ATTRIBUTION,
        "license_url": OSM_COPYRIGHT,
        "raw_sha256": sha256(raw_bytes).hexdigest(),
        "bbox_west_south_east_north": [west, south, east, north],
        "raw_map_url": "https://api.openstreetmap.org/api/0.6/map?" + urlencode({"bbox": bbox_text}),
        "retrieved_utc": retrieved_utc,
        "extraction": "inside-bbox road runs; compress same-way geometry vertices; largest SCC",
    }
    graph = {
        "schema": "mixed-postman-graph-v1", "city": city, "source": source,
        "nodes": selected, "links": edges,
    }
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(graph, ensure_ascii=False, separators=(",", ":")) + "\n",
                      encoding="utf-8")
    print(f"{city}: {len(selected)} nodes, {len(edges)} required links -> {target}")


def summary_row(
    stage: str, city: str, rows: Sequence[dict], gains: Sequence[tuple[int, float]]
) -> dict:
    observed = [row for row in rows if row["audited_pairs"]]
    n_pairs = sum(row["audited_pairs"] for row in rows)
    n_effects = sum(row["audited_effects"] for row in rows)
    n_strict = sum(row["strict_pairs"] for row in rows)
    n_strict_effects = sum(row["strict_effects"] for row in rows)
    strict_centres = sum(bool(row["strict_pairs"]) for row in observed)
    better_than_single = sum(bool(row["beyond_best_single_pairs"]) for row in observed)
    stalled = [row for row in observed if row["sampled_single_pool_stalled"]]
    timed_differences = [row["timed_gain_vs_single_cm"] for row in rows]
    return {
        "stage": stage, "city": city, "cities": len({row["city"] for row in rows}),
        "centres": len(rows), "centres_with_pairs": len(observed),
        "audited_pairs": n_pairs, "strict_pairs": n_strict,
        "strict_pair_rate_pct": percent(n_strict, n_pairs),
        "audited_effects": n_effects, "strict_effects": n_strict_effects,
        "strict_effect_rate_pct": percent(n_strict_effects, n_effects),
        "centres_with_strict_pairs": strict_centres,
        "strict_centre_rate_pct": percent(strict_centres, len(observed)),
        "centres_beyond_best_pool_single": better_than_single,
        "above_best_single_centre_rate_pct": percent(better_than_single, len(observed)),
        "stalled_centres_with_pairs": len(stalled),
        "escaped_stalled_centres": sum(bool(row["strict_pairs"]) for row in stalled),
        "escape_rate_pct": percent(sum(bool(row["strict_pairs"]) for row in stalled), len(stalled)),
        "strict_gain_median_cm": median(cm for cm, _ in gains) if gains else "",
        "strict_gain_max_cm": max(cm for cm, _ in gains) if gains else "",
        "strict_gain_median_pct_of_base": median(pct for _, pct in gains) if gains else "",
        "strict_gain_max_pct_of_base": max(pct for _, pct in gains) if gains else "",
        "max_extra_vs_best_pool_single_cm": max(
            (row["best_pair_extra_gain_vs_single_cm"] for row in observed), default=""
        ),
        "timed_coupled_wins": sum(gain > 0 for gain in timed_differences),
        "timed_ties": sum(gain == 0 for gain in timed_differences),
        "timed_coupled_losses": sum(gain < 0 for gain in timed_differences),
        "timed_gain_median_cm": median(timed_differences),
        "single_full_pool_centres": sum(row["single_pool_exhausted"] for row in rows),
        "coupled_full_pool_centres": sum(row["coupled_pool_exhausted"] for row in rows),
    }


def write_rows(path: Path, rows: Sequence[dict]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_manifest(path: Path, manifest: dict) -> None:
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def run_experiment(
    graph_files: Sequence[tuple[Path, RoadGraph]], seeds: Sequence[int], limits: Limits,
    budget_s: float, steps: int, output: Path, quick: bool,
) -> None:
    output.mkdir(parents=True, exist_ok=False)
    manifest = {
        "status": "running", "start_utc": datetime.now(timezone.utc).isoformat(),
        "script_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "python": platform.python_version(), "ortools": ortools.__version__, "numpy": np.__version__,
        "environment": platform.platform(), "cpu": platform.processor(),
        "attribution": OSM_ATTRIBUTION, "osm_copyright": OSM_COPYRIGHT,
        "budget_s_per_arm_per_centre": budget_s, "ordered_seeds": list(seeds),
        "sampling_limits": {**vars(limits), "max_paths_per_ordered_terminals": MAX_PATHS_PER_TERMINALS},
        "shared_single_descent_step_cap": steps, "quick_run": quick,
        "clock_scope": "candidate scoring and incumbent comparisons at each frozen centre",
        "paired_design": "equal limits and candidate order; fresh cache; no timed centre updates",
        "audit_scope": "complete capped pool, outside arm clocks; recompute every flipped orientation",
        "graphs": [
            {"file": path.name, "graph_sha256": sha256(path.read_bytes()).hexdigest(),
             "city": graph.name, "nodes": len(graph.nodes), "links": len(graph.links),
             "source": graph.source} for path, graph in graph_files
        ],
    }
    manifest_path = output / "run_manifest.json"
    write_manifest(manifest_path, manifest)

    rows = []
    gains = defaultdict(list)
    stages = ("initial", "after_single_descent") if steps else ("initial",)
    with (output / "pair_audit.csv").open("w", encoding="utf-8-sig", newline="") as detail:
        writer = csv.DictWriter(detail, fieldnames=PAIR_COLUMNS)
        writer.writeheader()
        for graph_index, (_, graph) in enumerate(graph_files):
            oracle = FlowOracle(graph)
            for seed_index, seed in enumerate(seeds):
                initial_start = perf_counter_ns()
                initial = initial_orientation(graph, seed)
                initial_s = (perf_counter_ns() - initial_start) / 1e9
                current = initial
                shared = {"greedy_s": initial_s, "descent_s": 0.0, "descent_steps": 0,
                          "descent_stop": "not_applied"}
                folder = output / "evidence" / graph.name / str(seed)
                folder.mkdir(parents=True)
                for stage_index, stage in enumerate(stages):
                    if stage_index:
                        descent_start = perf_counter_ns()
                        current, n_steps, reason = shared_descent(
                            graph, oracle, initial, seed, limits, steps
                        )
                        shared.update(descent_s=(perf_counter_ns() - descent_start) / 1e9,
                                      descent_steps=n_steps, descent_stop=reason)
                    row, pair_rows = one_stage(
                        graph, oracle, current, seed, limits, stage, budget_s,
                        (graph_index + seed_index + stage_index) % 2 == 0, shared, folder,
                    )
                    writer.writerows(pair_rows)
                    detail.flush()
                    gains[stage, graph.name].extend(
                        (pair["pair_gain_cm"], pair["pair_gain_pct_of_base"])
                        for pair in pair_rows if pair["strict_constituent_gain"]
                    )
                    rows.append(row)
                    print(f"[{graph.name} {seed} {stage}] "
                          f"strict={row['strict_pairs']}/{row['audited_pairs']}  "
                          f"timed={row['timed_gain_vs_single_cm']:+,d} cm  "
                          f"scored={row['single_singles_done']} / "
                          f"{row['coupled_singles_done']}+{row['coupled_pairs_done']}", flush=True)

    city_rows = []
    stage_rows = []
    for stage in stages:
        stage_gains = []
        stage_cities = []
        these_rows = [row for row in rows if row["stage"] == stage]
        for _, graph in graph_files:
            current_rows = [row for row in these_rows if row["city"] == graph.name]
            current_gains = gains[stage, graph.name]
            summary = summary_row(stage, graph.name, current_rows, current_gains)
            city_rows.append(summary)
            stage_cities.append(summary)
            stage_gains.extend(current_gains)

        summary = summary_row(stage, "ALL", these_rows, stage_gains)
        rates = [row["strict_pair_rate_pct"] for row in stage_cities if row["audited_pairs"]]
        summary["mean_city_strict_pair_rate_pct"] = mean(rates) if rates else ""
        stage_rows.append(summary)
        print(f"{stage}: {summary['strict_pairs']}/{summary['audited_pairs']} strict pairs; "
              f"{summary['centres_with_strict_pairs']}/{summary['centres_with_pairs']} centres; "
              f"median strict gain {summary['strict_gain_median_cm']} cm")

    write_rows(output / "centres.csv", rows)
    write_rows(output / "city_summary.csv", city_rows)
    write_rows(output / "stage_summary.csv", stage_rows)
    manifest["status"] = "complete"
    manifest["finish_utc"] = datetime.now(timezone.utc).isoformat()
    write_manifest(manifest_path, manifest)
    print(f"Done -> {output}")


def self_test() -> None:
    # Hand-checkable positive control with parallel links and four distinct terminals.
    rows = [
        (4, 5, 7, False), (5, 1, 7, False), (1, 2, 9, False), (2, 3, 4, False),
        (3, 0, 11, False), (2, 3, 7, True), (0, 1, 21, True), (4, 2, 7, False),
        (0, 3, 6, True), (0, 5, 23, False), (1, 2, 8, False), (1, 0, 13, False),
        (3, 4, 10, False), (5, 4, 13, True), (3, 5, 22, True),
    ]
    graph = RoadGraph(
        "synthetic_check", tuple(map(str, range(6))),
        tuple(Link(str(i), *row) for i, row in enumerate(rows)), {},
    )
    oracle = FlowOracle(graph)
    base = frozenset()
    supply = orientation_supply(graph, base)
    cost, _ = oracle.solve(supply)
    limits = Limits(1, 100, 0, 1000)
    paths = sample_paths(graph, base, 7, limits)
    pairs, _ = sample_pairs(paths, 7, limits.max_pairs)
    stats, records, _ = audit_pool(graph, oracle, base, cost, paths, pairs, {})
    target = next(
        row for row in records
        if move_links(paths, (row["path_a"], row["path_b"])) == {2, 9}
    )
    expected = (190, 195, 195, 185, 1)
    actual = (cost, target["single_a_cm"], target["single_b_cm"], target["pair_cm"],
              target["strict_constituent_gain"])
    if actual != expected or stats["sampled_single_pool_stalled"] != 1:
        raise AssertionError(f"Known pair-only improvement failed: {actual}")
    for pair in pairs:
        if score_delta(oracle, supply, pair_delta(paths, pair), {}) != exact_move_cost(
            graph, oracle, base, paths, pair
        ):
            raise AssertionError("Sparse endpoint delta disagrees with direct link reversal")
    cost_pair, _ = reconstruct_route(graph, oracle, frozenset({2, 9}))
    if cost_pair != 185:
        raise AssertionError("Route reconstruction disagrees with the positive control")
    zero = RoadGraph("zero", ("a", "b"), (Link("a-b", 0, 1, 0, False),), {})
    if reconstruct_route(zero, FlowOracle(zero), frozenset())[0] != 0 or percent(0, 0) != "":
        raise AssertionError("Zero-cost support check failed")
    print("Self-test passed for a length-one candidate pool: "
          "incumbent 190, two singles 195/195, joint 185; route audited.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=PROJECT / "data")
    parser.add_argument("--out", type=Path, help="A new output directory")
    parser.add_argument("--cities", nargs="+", help="E.g. chengdu wuhan")
    parser.add_argument("--seeds", type=int, nargs="+", default=DEFAULT_SEEDS)
    parser.add_argument("--budget", type=float, default=DEFAULT_BUDGET_SECONDS)
    parser.add_argument("--descent-steps", type=int, default=DEFAULT_DESCENT_STEPS)
    parser.add_argument("--max-path-edges", type=int, default=DEFAULT_MAX_PATH_EDGES)
    parser.add_argument("--paths", type=int, default=DEFAULT_MAX_PATHS)
    parser.add_argument("--path-expansions", type=int, default=DEFAULT_PATH_EXPANSIONS)
    parser.add_argument("--pairs", type=int, default=DEFAULT_MAX_PAIRS)
    parser.add_argument("--quick", action="store_true", help="Small smoke run with both centres")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--self-test", action="store_true")
    mode.add_argument("--import-osm", type=Path, help="Convert local map XML to graph JSON")
    parser.add_argument("--city-name", help="City slug for --import-osm, e.g. suzhou")
    parser.add_argument("--retrieved-utc", default="", help="OSM source retrieval timestamp")
    args = parser.parse_args()

    if args.self_test:
        self_test()
        return
    if args.import_osm:
        if not args.city_name or any(ch not in "abcdefghijklmnopqrstuvwxyz0123456789_-" for ch in args.city_name):
            parser.error("--import-osm requires a lowercase ASCII --city-name")
        import_osm(args.import_osm, args.city_name, args.data / f"{args.city_name}.json",
                   args.retrieved_utc)
        return
    if not 0 < args.budget < float("inf"):
        parser.error("--budget must be a positive finite number")
    if not (1 <= args.max_path_edges <= 12 and 1 <= args.paths <= 512 and
            args.path_expansions >= 0 and args.pairs >= 0 and args.descent_steps >= 0):
        parser.error("Invalid sampling limits; see --help and README")
    if len(args.seeds) != len(set(args.seeds)):
        parser.error("--seeds must be distinct")

    files = []
    requested = set(args.cities or ())
    for path in sorted(args.data.glob("*.json")):
        if requested and path.stem not in requested:
            continue
        graph = RoadGraph.from_json(path)
        if graph.name != path.stem:
            parser.error(f"{path.name}: city field must match the filename")
        files.append((path, graph))
    missing = requested - {graph.name for _, graph in files}
    if missing:
        parser.error("No frozen file for: " + ", ".join(sorted(missing)))
    if not files:
        parser.error(f"No graph JSON files found in {args.data}")

    output = args.out or PROJECT / "results" / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    if args.quick:
        if not requested:
            files = files[:1]
        args.seeds = args.seeds[:1]
        args.paths = min(args.paths, 24)
        args.pairs = min(args.pairs, 48)
        args.descent_steps = min(args.descent_steps, 4)
        args.budget = min(args.budget, 2.0)
    limits = Limits(args.max_path_edges, args.paths, args.path_expansions, args.pairs)
    run_experiment(files, args.seeds, limits, args.budget, args.descent_steps, output, args.quick)


if __name__ == "__main__":
    main()
