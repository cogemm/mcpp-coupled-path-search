# Release scope

Included: the main V21 source and formal result archive identified by the supplied provenance; the six-city paired-path audit code/data/results; the independent reanalysis outputs and figure assets; the five-seed large-graph ablation diagnostic and separate one-seed diagnostic.

Excluded: unrelated project folders; alternate ACO and other published-comparison kits not used in the abstract's stated 99-run comparison; the separate Corberan benchmark package; duplicate V20/V21 copies; Python bytecode/cache; temporary files; raw PBF files; and unreferenced historical runs. The source archives remain the complete historical backup.

The release preserves adverse and inconclusive diagnostics. It does not relabel development diagnostics as primary results or claim that all historical experiments are part of the manuscript.

License assignment: original source code is MIT; authors' original non-code research materials are CC BY 4.0 subject to OSM/third-party exclusions; OSM-derived graph databases and extracted OSM content remain ODbL 1.0. See `LICENSE_SCOPE.md`.
